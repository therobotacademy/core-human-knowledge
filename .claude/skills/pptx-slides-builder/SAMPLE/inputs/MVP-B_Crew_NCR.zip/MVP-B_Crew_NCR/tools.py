"""Tools del Crew NCR · catálogos de dominio en data/*.csv

Cada tool es un punto de consulta factual fuera del LLM:
- lookup_tipo_nc:    catálogo AS9100 de tipos de NC (severidad, cláusula, contención)
- lookup_causas_raiz: catálogo 8D de causas frecuentes por área

La lógica vive en funciones privadas `_lookup_*_impl` para que sea testeable
sin invocar el wrapper @tool de CrewAI. Los wrappers @tool son las que
los agentes utilizan en el Crew.
"""
import csv
import json
from pathlib import Path

from crewai.tools import tool

DATA_DIR = Path(__file__).parent / "data"

_AREAS_VALIDAS = {"material", "proceso", "humano", "proveedor", "documental"}
_ORDEN_FRECUENCIA = {"Alta": 0, "Media": 1, "Baja": 2}


def _cargar_tipos_nc() -> list[dict]:
    with open(DATA_DIR / "tipos_nc.csv", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _cargar_causas_raiz() -> list[dict]:
    with open(DATA_DIR / "causas_raiz.csv", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _lookup_tipo_nc_impl(tipo: str) -> str:
    tipos = _cargar_tipos_nc()
    tipo_norm = tipo.strip().lower()

    match = next((t for t in tipos if t["tipo_nc"].lower() == tipo_norm), None)
    if match is None:
        match = next(
            (
                t
                for t in tipos
                if tipo_norm in t["tipo_nc"].lower() or t["tipo_nc"].lower() in tipo_norm
            ),
            None,
        )

    if match is None:
        return json.dumps(
            {
                "severidad": "Major",
                "clausula_as9100": "8.7",
                "requiere_contencion": True,
                "aviso": "tipo no en catálogo",
            },
            ensure_ascii=False,
        )

    return json.dumps(
        {
            "severidad": match["severidad_default"],
            "clausula_as9100": match["clausula_as9100"],
            "requiere_contencion": match["requiere_contencion_default"].strip().lower() == "true",
        },
        ensure_ascii=False,
    )


def _lookup_causas_raiz_impl(area: str) -> str:
    area_norm = area.strip().lower()
    if area_norm not in _AREAS_VALIDAS:
        return json.dumps(
            {"error": f"area '{area}' no válida", "areas_validas": sorted(_AREAS_VALIDAS)},
            ensure_ascii=False,
        )

    causas = _cargar_causas_raiz()
    filtradas = [c for c in causas if c["area"].lower() == area_norm]
    filtradas.sort(key=lambda c: _ORDEN_FRECUENCIA.get(c["frecuencia"], 99))

    return json.dumps(
        [{"causa": c["causa"], "frecuencia": c["frecuencia"]} for c in filtradas[:3]],
        ensure_ascii=False,
    )


@tool("lookup_tipo_nc")
def lookup_tipo_nc(tipo: str) -> str:
    """Busca un tipo de no conformidad en el catálogo AS9100.

    Args:
        tipo: descripción libre del tipo de NC (ej. "Defecto dimensional",
              "no conformidad documental"). Búsqueda case-insensitive con
              coincidencia parcial.

    Returns:
        JSON string con `severidad` (Minor/Major/Critical), `clausula_as9100`
        y `requiere_contencion` (bool). Si el tipo no está en catálogo,
        devuelve valores por defecto conservadores y un campo `aviso`.
    """
    return _lookup_tipo_nc_impl(tipo)


@tool("lookup_causas_raiz")
def lookup_causas_raiz(area: str) -> str:
    """Devuelve hasta 3 causas raíz frecuentes para un área 8D.

    Args:
        area: una de `material`, `proceso`, `humano`, `proveedor`, `documental`.

    Returns:
        JSON array con las causas más frecuentes (frecuencia Alta primero,
        luego Media, luego Baja). Máximo 3 elementos. Cada elemento tiene
        `causa` y `frecuencia`.
    """
    return _lookup_causas_raiz_impl(area)
