"""Runner del test set · ejecuta los 5 NCRs del ncr_test_set.json y valida criterios C1-C8.

Uso:
    python run_test_set.py

Salida:
    - stdout: tabla de resultados por caso + resumen final
    - test_results.json: dump de los outputs reales (JSON del schema §4) por caso
"""
import json
import sys
import traceback
from pathlib import Path

from main import run

ROOT = Path(__file__).parent
TEST_SET_PATH = ROOT / "ncr_test_set.json"
RESULTS_PATH = ROOT / "test_results.json"


def validar(actual: dict, expected: dict) -> list[tuple[str, bool, str]]:
    """Valida un output actual contra su bloque expected.

    Returns: lista de (criterio, pass, detalle)
    """
    checks = []

    if "severidad" in expected:
        ok = actual["clasificacion"]["severidad"] == expected["severidad"]
        checks.append((f"severidad={expected['severidad']}", ok, actual["clasificacion"]["severidad"]))

    if "clausula_as9100" in expected:
        ok = actual["clasificacion"]["clausula_as9100"] == expected["clausula_as9100"]
        checks.append((f"clausula={expected['clausula_as9100']}", ok, actual["clasificacion"]["clausula_as9100"]))

    if "requiere_contencion_inmediata" in expected:
        ok = actual["clasificacion"]["requiere_contencion_inmediata"] == expected["requiere_contencion_inmediata"]
        checks.append((f"contencion={expected['requiere_contencion_inmediata']}", ok, actual["clasificacion"]["requiere_contencion_inmediata"]))

    if "tipo_nc_catalogo" in expected:
        ok = actual["clasificacion"]["tipo_nc"] == expected["tipo_nc_catalogo"]
        checks.append((f"tipo_nc={expected['tipo_nc_catalogo']}", ok, actual["clasificacion"]["tipo_nc"]))

    # 8D 5 campos no vacíos
    a8d = actual.get("analisis_8d", {})
    campos_8d = ["D1_equipo", "D2_descripcion", "D3_contencion", "D4_causa_raiz", "D5_accion_correctiva"]
    full_8d = all(a8d.get(c) for c in campos_8d)
    checks.append(("8D D1-D5 no vacios", full_8d, sum(bool(a8d.get(c)) for c in campos_8d)))

    if "plan_acciones_min" in expected:
        n = len(actual.get("plan_acciones", []))
        ok = n >= expected["plan_acciones_min"] and all(a["plazo_dias"] > 0 for a in actual["plan_acciones"])
        checks.append((f"plan_acciones>={expected['plan_acciones_min']}", ok, f"n={n}"))

    if "confianza_min" in expected:
        c = actual.get("confianza", 0.0)
        ok = c >= expected["confianza_min"]
        checks.append((f"confianza>={expected['confianza_min']}", ok, c))

    if "confianza_max" in expected:
        c = actual.get("confianza", 1.0)
        ok = c <= expected["confianza_max"]
        checks.append((f"confianza<={expected['confianza_max']}", ok, c))

    if "alertas_vacio" in expected and expected["alertas_vacio"] is True:
        ok = len(actual.get("alertas", [])) == 0
        checks.append(("alertas vacio", ok, len(actual.get("alertas", []))))

    if "alertas_no_vacio" in expected and expected["alertas_no_vacio"] is True:
        ok = len(actual.get("alertas", [])) >= 1
        checks.append(("alertas no vacio", ok, len(actual.get("alertas", []))))

    return checks


def main():
    with open(TEST_SET_PATH, encoding="utf-8") as f:
        test_set = json.load(f)

    results = []
    summary = []

    for caso in test_set["casos"]:
        cid = caso["case_id"]
        print(f"\n{'=' * 70}")
        print(f"CASO: {cid}  ·  {caso['descripcion_corta']}")
        print(f"{'=' * 70}")

        try:
            actual = run(caso["ncr_text"])
            error = None
        except Exception as e:
            actual = None
            error = f"{type(e).__name__}: {e}"
            traceback.print_exc()

        results.append({
            "case_id": cid,
            "descripcion_corta": caso["descripcion_corta"],
            "actual": actual,
            "error": error,
            "expected": caso["expected"],
        })

        if error:
            print(f"\n[FAIL kickoff] {error}")
            summary.append((cid, 0, 0, error))
            continue

        checks = validar(actual, caso["expected"])
        passed = sum(1 for _, ok, _ in checks if ok)
        total = len(checks)
        for criterio, ok, detalle in checks:
            badge = "PASS" if ok else "FAIL"
            print(f"  {badge}  {criterio:30}  (actual: {detalle})")

        summary.append((cid, passed, total, None))

    # Persistir resultados
    with open(RESULTS_PATH, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)

    print(f"\n\n{'=' * 70}")
    print("RESUMEN")
    print(f"{'=' * 70}")
    total_pass = 0
    total_checks = 0
    crews_ok = 0
    for cid, p, t, err in summary:
        if err:
            print(f"  {cid}  EXCEPTION: {err}")
        else:
            crews_ok += 1
            total_pass += p
            total_checks += t
            mark = "OK" if p == t else "PARCIAL"
            print(f"  {cid}  {mark:7}  {p}/{t}")
    print(f"\nC6 (5/5 sin excepcion):  {crews_ok}/5  {'PASS' if crews_ok == 5 else 'FAIL'}")
    print(f"Sub-criterios validados: {total_pass}/{total_checks}")
    print(f"\nResultados crudos guardados en: {RESULTS_PATH}")

    sys.exit(0 if crews_ok == 5 else 1)


if __name__ == "__main__":
    main()
