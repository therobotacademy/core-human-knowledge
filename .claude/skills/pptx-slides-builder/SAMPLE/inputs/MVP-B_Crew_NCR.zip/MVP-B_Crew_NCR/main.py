"""Entry point del Crew NCR.

Uso:
    echo "NCR-2026-VBX-0101 ..." | python main.py

stdin   → texto libre del NCR
stdout  → JSON con el análisis completo (schema §4 del PLAN.md)

El Crew se ejecuta en modo verbose (Process.sequential) para que en clase
se vea el razonamiento de los 3 agentes. El JSON final aparece al final,
precedido por una línea de separador, para facilitar parseo automatizado:

    === NCR ANALYSIS RESULT ===
    {... JSON ...}
"""
import json
import sys

from crewai import Crew, Process

from agents import causas, clasificador, planes
from tasks import build_tasks


RESULT_MARKER = "=== NCR ANALYSIS RESULT ==="


def run(ncr_text: str) -> dict:
    """Ejecuta el Crew sobre un NCR y devuelve el JSON del schema §4."""
    tasks = build_tasks(clasificador, causas, planes, ncr_text)
    crew = Crew(
        agents=[clasificador, causas, planes],
        tasks=tasks,
        process=Process.sequential,
        verbose=True,
    )
    result = crew.kickoff()

    clasif = result.tasks_output[0].pydantic.model_dump()
    ncr_id = clasif.pop("ncr_id")
    plan_final = result.tasks_output[2].pydantic.model_dump()

    return {
        "ncr_id": ncr_id,
        "clasificacion": clasif,
        "analisis_8d": result.tasks_output[1].pydantic.model_dump(),
        **plan_final,
    }


def main():
    ncr_text = sys.stdin.read().strip()
    if not ncr_text:
        print(
            json.dumps(
                {
                    "error": "no_ncr",
                    "mensaje": "Introduce el texto del NCR por stdin",
                }
            )
        )
        sys.exit(1)

    output = run(ncr_text)

    print()
    print(RESULT_MARKER)
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
