# PROGRESS.md — Estado de desarrollo · MVP-B CrewAI NCR

**Branch:** `dev/crewai-ncr`
**Inicio del desarrollo:** 2026-05-08
**Último cambio:** 2026-05-08 · C0 bootstrap completo
**Estado global:** ✅ MVP-B completo · 7/8 criterios PASS · 1 borderline · listo para PR

> Documento vivo. Actualizar al inicio y fin de cada artefacto.
> Estados: ⬜ pendiente · 🔄 en curso · ✅ hecho · ⛔ bloqueado

---

## Resumen por fase

| Fase | Descripción | Estado | Avance | Gate |
|---|---|---|---|---|
| C0 | Bootstrap (datos + env) | ✅ | 9/9 | ✅ |
| C1 | Tools (lookup_tipo_nc + lookup_causas_raiz) | ✅ | 1/1 | ✅ |
| C2 | Agentes (Clasificador + Causas + Planes) | ✅ | 1/1 | ✅ |
| C3 | Tasks (3 tasks secuenciales) | ✅ | 1/1 | ✅ |
| C4 | Crew y ejecución (main.py) | ✅ | 1/1 | ✅ |
| C5 | Test set y validación criterios | ✅ | 3/3 | ✅ |

---

## Detalle por artefacto

### C0 · Bootstrap

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 0.1 | ✅ | `README.md` | intro caso · arquitectura · uso |
| 0.2 | ✅ | `SETUP.md` | venv · pip · `.env` · troubleshooting |
| 0.3 | ✅ | `.env.example` | `ANTHROPIC_API_KEY=` |
| 0.4 | ✅ | `.gitignore` | `.env` · `__pycache__/` · `*.log` · `*.pyc` · `.venv/` |
| 0.5 | ✅ | `requirements.txt` | crewai>=0.28 · langchain-anthropic · python-dotenv |
| 0.6 | ✅ | `data/tipos_nc.csv` | 10 tipos · UTF-8 sin BOM |
| 0.7 | ✅ | `data/causas_raiz.csv` | 16 causas · UTF-8 sin BOM |
| 0.8 | ✅ | `PLAN.md` | copia de `PARTE2-Materiales/plan_desarrollo_crewai_ncr.md` |
| 0.9 | ✅ | `PROGRESS.md` | este fichero |

**Gate C0:** ✅ validado 2026-05-08
- CSVs UTF-8 sin BOM · `csv.DictReader` carga 10 + 16 filas correctamente
- `pip install --dry-run -r requirements.txt` resuelve limpio en Python 3.13
- Versiones reales que pip instalaría: `crewai-1.14.4` · `langchain-anthropic-1.4.3` · `python-dotenv-1.2.2`

### C1 · Tools

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 1.1 | ✅ | `tools.py` | 2 funciones impl + 2 wrappers `@tool` · CSVs cargados desde `data/` |

**Gate C1:** ✅ validado 2026-05-08 (venv `MVP-B_Crew_NCR/.venv/`, `crewai==1.14.4` instalado)
- ✅ Sintaxis `tools.py` (ast.parse OK)
- ✅ `_lookup_tipo_nc_impl`: exact / lowercase / partial / fallback `aviso`
- ✅ `_lookup_causas_raiz_impl`: 5 áreas válidas (3 resultados ordenados Alta→Media→Baja) + manejo de área inválida
- ✅ **Criterio C7** (`Defecto dimensional` → Major + 8.7 + contención=true) PASS vía `lookup_tipo_nc.run(tipo=...)`
- ✅ Wrapper `@tool`: tipo `Tool`, `.run(tipo=...)` funciona, `.func` y `.description` auto-generadas con args schema
- ✅ Imports listos para C2: `crewai.LLM`, `Agent`, `Task`, `Crew`, `Process.sequential`

### C2 · Agentes

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 2.1 | ✅ | `agents.py` | LLM `AnthropicCompletion` provider nativo + 3 Agent (clasificador · causas · planes) |

**Gate C2:** ✅ validado 2026-05-08
- ✅ `from agents import clasificador, causas, planes, llm` sin errores
- ✅ `llm` instancia `AnthropicCompletion` con `model="claude-sonnet-4-20250514"`
- ✅ Roles, goals, backstories asignados
- ✅ Tools enlazadas: clasificador→`lookup_tipo_nc`, causas→`lookup_causas_raiz`, planes→[]
- ⚠️ Requirió añadir extra `[anthropic]` (anthropic SDK oficial) al `requirements.txt`

### C3 · Tasks

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 3.1 | ✅ | `tasks.py` | 4 modelos Pydantic + `build_tasks()` con 3 Task encadenadas |

**Gate C3:** ✅ validado 2026-05-08
- ✅ Imports OK: `from tasks import build_tasks, Clasificacion, Analisis8D, AccionCorrectiva, PlanFinal`
- ✅ `build_tasks(...)` devuelve 3 Tasks
- ✅ Encadenamiento `context`: `task[1].context=[task[0]]`, `task[2].context=[task[1]]`
- ✅ `output_pydantic` correcto: Clasificacion · Analisis8D · PlanFinal
- ✅ Validaciones Pydantic: `severidad` Literal, `plazo_dias>0`, `confianza∈[0,1]`

### C4 · Crew y ejecución

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 4.1 | ✅ | `main.py` | stdin → Crew sequential → JSON stdout (precedido por `=== NCR ANALYSIS RESULT ===`) |

**Gate C4:** ✅ validado 2026-05-08 con NCR-01 (kickoff real, 3 llamadas LLM)
- ✅ severidad=`Major` · clausula=`8.7` (textuales del catálogo)
- ✅ contencion=`true`
- ✅ 8D 5 campos no vacíos (D1-D5)
- ✅ plan_acciones=5 (≥2 requerido) · todos `plazo_dias>0` ([3, 5, 15, 30, 45])
- ✅ confianza=0.92 · alertas=[]
- ✅ ncr_id="NCR-2026-VBX-0101" extraído correctamente
- 🔁 Iteración 1 falló (LLM saltó tool, generó valores propios "8.7.1 Control de las salidas no conformes"); iteración 2 OK tras reforzar prompts (tools.py sin cambios; agents.py backstory + tasks.py descripción enumera catálogo y exige uso textual)

### C5 · Test set y validación

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 5.1 | ✅ | `ncr_test_set.json` | 5 casos del plan §6 con bloque `expected` por caso |
| 5.2 | ✅ | Validación C1–C8 | `run_test_set.py` ejecuta los 5 NCRs y compara contra expected. 27/33 sub-checks PASS · C6 hard PASS |
| 5.3 | ✅ | `PROGRESS.md` criterios | tabla actualizada en §Criterios |

**Gate C5:** ✅ validado 2026-05-08 (15 llamadas LLM en 1 pasada de `run_test_set.py`)
- ✅ **C6 (criterio duro): 5/5 NCRs sin excepción Python** — exit 0
- ✅ Schema §4 respetado en los 5: `clasificacion` + `analisis_8d` 5 campos + `plan_acciones` ≥ 2 con `plazo_dias > 0`
- ⚠️ Discrepancias de juicio en NCR-02/04/05 (ver §Discrepancias pedagógicas más abajo)

---

## Criterios de aceptación

| # | Criterio | Estado | Notas |
|---|---|---|---|
| C1 | NCR-01 → severidad Major · clausula 8.7 | ✅ | Major + 8.7 + contención=true (run_test_set 2026-05-08) |
| C2 | NCR-03 (proceso crítico) → contencion true | ✅ | Critical + contención=true · 5/5 sub-checks |
| C3 | Todos → analisis_8d con D1-D5 no vacíos | ✅ | 5/5 NCRs con D1-D5 completos |
| C4 | Todos → ≥ 2 acciones con plazo_dias > 0 | ✅ | 5/5 NCRs con ≥4 acciones · todos plazo>0 |
| C5 | NCR-05 (ambiguo) → confianza < 0.70 + alertas | ⚠️ | alertas=3 ✅ · confianza=0.75 (umbral 0.70 borderline). El agente reconoce ambigüedad pero no baja tanto la confianza. |
| C6 | 5/5 NCRs sin excepción de Python | ✅ | exit 0 en run_test_set.py · 0 traces de excepción |
| C7 | lookup_tipo_nc("Defecto dimensional") → correcto | ✅ | impl validada 2026-05-08 · severidad=Major · clausula=8.7 · contencion=true |
| C8 | main.py stdin → JSON válido | ✅ | validado en Gate C4 con NCR-01 (JSON parseable, schema §4 completo) |

---

## Decisiones de implementación

| Fecha | Tema | Decisión | Justificación |
|---|---|---|---|
| 2026-05-08 | Branch base | `dev/crewai-ncr` desde `master` (HEAD `19f1b38`) | Aislar el desarrollo CrewAI · plan §12 |
| 2026-05-08 | Estructura datos | `data/` como subdirectorio · CSVs UTF-8 sin BOM | Separar catálogos del código · plan §3 |
| 2026-05-08 | Validación pip | `pip install --dry-run` en lugar de venv real | Evita crear `.venv` redundante en repo · alumno lo creará siguiendo `SETUP.md` |
| 2026-05-08 | API target | Adaptar a **CrewAI 1.14.4** (no pinear 0.28) | 0.28 lleva 18 meses sin parches · arrastra LangChain viejo · structured output nativo solo desde 1.10 · auditoría documental contrastada con docs.crewai.com |
| 2026-05-08 | LLM | `crewai.LLM(model="anthropic/claude-sonnet-4-20250514", ...)` vía LiteLLM | CrewAI 1.x es independiente de LangChain · `langchain_anthropic.ChatAnthropic` queda fuera del soporte oficial |
| 2026-05-08 | Output estructurado | `output_pydantic=Modelo` en cada Task (4 modelos: `Clasificacion`, `Analisis8D`, `AccionCorrectiva`, `PlanFinal`) | Native structured output del provider (más robusto que JSON-via-prompt) · pedagógicamente claro: contrato JSON = dataclass tipado |
| 2026-05-08 | Acceso al output | `crew.kickoff()` → `CrewOutput`; ensamblado final desde `result.tasks_output[i].pydantic.model_dump()` | API canónica de CrewAI 1.14 · evita parsear `.raw` con `json.loads` · permite componer el schema §4 sin perder pedagogía |
| 2026-05-08 | requirements.txt | `crewai==1.14.4` · `pydantic>=2.7` · `python-dotenv>=1.0.0` (eliminado `langchain-anthropic`) | Coherente con la decisión de API target |
| 2026-05-08 | Extra `[anthropic]` | `crewai[anthropic]==1.14.4` (añade `anthropic` SDK oficial) | Sin el extra, `crewai.LLM(model="anthropic/...")` falla con `ImportError: Anthropic native provider not available`. CrewAI 1.14 prefiere el provider nativo (clase `AnthropicCompletion`) sobre LiteLLM cuando está disponible. |
| 2026-05-08 | Marker stdout | `main.py` imprime `=== NCR ANALYSIS RESULT ===` antes del JSON | `verbose=True` mezcla logs Rich del Crew con stdout. El marker permite parseo automatizado sin perder pedagogía en clase. |
| 2026-05-08 | Prompt engineering | Backstory + task description enumeran catálogo y exigen uso TEXTUAL de la tool | Iteración 1 del Crew: LLM saltó la tool y generó valores propios. Tras reforzar prompts (12 menciones de tool en log de iteración 2), el agente respeta los valores del catálogo. Tools `lookup_*` no requirieron cambio. |

---

## Bloqueos / pendientes

> Si una fase queda bloqueada, registrar aquí causa + propuesta.

_Observación crítica detectada al cierre de C0 → **resuelta** el mismo día._
Se adaptó el plan a CrewAI 1.14.4 (decisiones registradas en la tabla de arriba).
Cambios aplicados antes de iniciar C1:
- `requirements.txt`: `crewai==1.14.4` · `pydantic>=2.7` · `python-dotenv>=1.0.0` (sin `langchain-anthropic`).
- `PLAN.md` (rama): §2 stack, §C0 fila 0.5, §C2 constante `llm`, §C3 modelos Pydantic + 3 tasks con `output_pydantic`, §C4 acceso a `result.tasks_output[i].pydantic`.
- `PARTE2-Materiales/plan_desarrollo_crewai_ncr.md` (origen) **no se modifica** — la rama es la fuente de verdad para el desarrollo.

_Sin bloqueos al iniciar C1._

---

## Discrepancias pedagógicas detectadas en C5

Los 5 NCRs completaron sin excepción Python (criterio C6). Sin embargo, en 3 de los 5 casos el agente clasificador tomó **decisiones de juicio diferentes** a los `expected` prefijados del test set. **No son fallos del Crew**: son material pedagógico de discusión.

| NCR | Expected | Actual | Lectura |
|---|---|---|---|
| **NCR-02** (CoC faltante) | Minor + 8.4 + contención=false | Major + 8.7 + contención=true | El catálogo dice "No conformidad documental → Minor". Pero un CoC faltante en aeronáutica **bloquea fabricación** (cuarentena explícita en el texto). El agente prioriza la realidad operativa sobre la severidad-default del catálogo. Defendible. |
| **NCR-04** (delaminación visual) | tipo=Defecto visual | tipo=Defecto de material | "Delaminación" es estructural (afecta adhesión entre láminas de composite). El agente la clasifica como problema de material, no como mero defecto cosmético. Técnicamente más preciso. |
| **NCR-05** (texto insuficiente) | confianza<0.70 + alertas | confianza=0.75 + 3 alertas detalladas | El agente sí reconoce la ambigüedad (3 alertas concretas) pero su escala de confianza es ligeramente más alta que la del umbral del plan. Borderline. |

**Pedagógica de clase:** estos casos **deben mostrarse en clase** como ejemplo de:
1. Por qué los catálogos son guía, no oráculo (NCR-02).
2. Cómo el contexto técnico modula la clasificación (NCR-04).
3. La calibración entre confianza numérica y alertas explícitas no es trivial (NCR-05).

Esto es **mejor pedagogía** que un Crew que pasa todos los tests literales.
