# Plan de desarrollo · MVP-B CrewAI NCR
# Análisis de Non-Conformance Reports aeronáuticos con sistema multi-agente

**Branch a crear:** `dev/crewai-ncr`
**Base:** `master` actual
**Directorio destino:** `CONTENT/MVP-B_Crew_NCR/`
**Sesiones del curso:** 2 últimas sesiones Parte 2 · Módulo extra CrewAI
**Bloqueante que resuelve:** CrewAI-0 en `plan_first-code-then-learn.md`

---

## 1 · Contexto y objetivo

Este módulo introduce a los alumnos a sistemas multi-agente con **CrewAI**, framework Python open-source donde múltiples agentes con roles especializados colaboran hacia un objetivo común. Es el único punto de entrada a código Python obligatorio en la Parte 2 (distinto del Nanobot opcional de II5).

**Caso de uso:** VERBEX COMPOSITES S.L. recibe Non-Conformance Reports (NCR) de su sistema de calidad. Un técnico pega el texto libre del NCR en el sistema y el Crew produce automáticamente:
- Clasificación de severidad (Minor / Major / Critical) con cláusula AS9100 afectada
- Análisis de causa raíz mediante metodología 8D (disciplinas D1–D5)
- Plan de acciones correctivas con responsable y plazo en días

**Por qué CrewAI y no n8n aquí:** la coordinación entre agentes especializados (clasificador → causas → planes) es inherente al dominio. Cada agente necesita razonar sobre el output del anterior, no solo enrutar datos. n8n con LLM haría lo mismo en un único nodo, sin los beneficios pedagógicos de ver la delegación explícita entre roles.

**Por qué dominio nuevo (no VERBEX POs):** separar los dominios evita que los alumnos confundan esta implementación CrewAI con el MVP-A VERBEX que ya construyeron. El contexto AS9100 / NCR es familiar para el sector aeronáutico andaluz y no requiere datos adicionales complejos.

---

## 2 · Arquitectura del sistema

```
stdin (texto NCR)
        │
        ▼
  ┌─────────────────────────────────────────────────────┐
  │                  Crew NCR (sequential)              │
  │                                                     │
  │  Agente Clasificador  ──tool→  lookup_tipo_nc       │
  │         │                                           │
  │         ▼ context                                   │
  │  Agente Causas        ──tool→  lookup_causas_raiz   │
  │         │                                           │
  │         ▼ context                                   │
  │  Agente Planes        (sin tool · razonamiento)     │
  └─────────────────────────────────────────────────────┘
        │
        ▼
  JSON output (stdout)
```

**Stack técnico:**
- `crewai[anthropic] == 1.14.4` (estable mayo 2026 · extra `anthropic` aporta el SDK oficial para el provider nativo)
- `pydantic >= 2.7` (structured output nativo vía `output_pydantic`)
- Modelo: `claude-sonnet-4-20250514 · temperature 0.1` (vía `crewai.LLM` → `AnthropicCompletion` provider nativo)
- `python-dotenv` para `ANTHROPIC_API_KEY`
- Python 3.10+ · compatible Daytona sandbox

> **Nota de versión:** este plan se redactó originalmente contra `crewai>=0.28` (API LangChain). Adaptado a la API nativa de CrewAI 1.14 antes de iniciar C1 (decisión registrada en `PROGRESS.md § Decisiones`). Cambios principales: `crewai.LLM` reemplaza a `langchain_anthropic.ChatAnthropic`, `output_pydantic` reemplaza al *prompt-engineering* de JSON, `crew.kickoff()` retorna `CrewOutput`.

---

## 3 · Estructura de directorios objetivo

```
CONTENT/MVP-B_Crew_NCR/
├── README.md                  # intro caso, arquitectura, cómo ejecutar
├── SETUP.md                   # instalación paso a paso (Python, venv, API key)
├── PLAN.md                    # este documento (copia de referencia en la rama)
├── PROGRESS.md                # tracker vivo del desarrollo
├── .env.example               # ANTHROPIC_API_KEY=
├── .gitignore                 # .env, __pycache__, *.log
├── requirements.txt           # dependencias
│
├── data/
│   ├── tipos_nc.csv           # 10 tipos de NC · severidad · cláusula AS9100
│   └── causas_raiz.csv        # catálogo 16 causas raíz por área (8D)
│
├── ncr_test_set.json          # 5 NCRs de prueba con expected output
├── run_test_set.py            # runner reproducible: itera test set + valida criterios
├── test_results.json          # output de la última corrida (gitignored · regenerable)
│
├── agents.py                  # definición de los 3 Agent()
├── tasks.py                   # definición de las 3 Task()
├── tools.py                   # 2 @tool: lookup_tipo_nc · lookup_causas_raiz
└── main.py                    # Crew assembly + kickoff + JSON stdout
```

---

## 4 · Schema JSON de salida

El Crew produce un único JSON por NCR. Es la fuente de verdad para M2 y M3.

```json
{
  "ncr_id": "NCR-2026-VBX-0101",
  "clasificacion": {
    "severidad": "Major",
    "tipo_nc": "Defecto dimensional",
    "clausula_as9100": "8.7",
    "requiere_contencion_inmediata": true,
    "descripcion_breve": "string"
  },
  "analisis_8d": {
    "D1_equipo": "string",
    "D2_descripcion": "string",
    "D3_contencion": "string",
    "D4_causa_raiz": "string",
    "D5_accion_correctiva": "string"
  },
  "plan_acciones": [
    {
      "id": "AC-001",
      "descripcion": "string",
      "responsable": "string",
      "plazo_dias": 30,
      "estado": "Abierta"
    }
  ],
  "confianza": 0.85,
  "alertas": []
}
```

**Reglas de confianza:**
- `>= 0.90`: NCR con campos completos y tipo reconocido en catálogo
- `0.70–0.89`: un campo ambiguo o tipo no exacto en catálogo
- `< 0.70`: descripción incompleta · causa no determinable · alerta de revisión manual

---

## 5 · Datos de dominio

### `data/tipos_nc.csv`

```csv
tipo_nc,severidad_default,clausula_as9100,requiere_contencion_default
Defecto dimensional,Major,8.7,true
Defecto de material,Major,8.4,true
Defecto de proceso,Major,8.5.1,true
Defecto visual,Minor,8.7,false
No conformidad documental,Minor,8.4,false
Defecto de proveedor,Major,8.4,true
Error de trazabilidad,Minor,8.5.2,false
Defecto de acabado superficial,Minor,8.7,false
No conformidad crítica,Critical,8.7,true
Incumplimiento de especificación,Major,8.5.1,true
```

### `data/causas_raiz.csv`

```csv
area,causa,frecuencia
material,Certificado de material caducado,Alta
material,Material incorrecto recibido del proveedor,Alta
material,Almacenamiento incorrecto temperatura o humedad,Media
proceso,Temperatura de curado fuera de parámetros,Alta
proceso,Tiempo de curado incorrecto,Alta
proceso,Utillaje desgastado o mal calibrado,Media
proceso,Procedimiento de trabajo desactualizado,Media
humano,Formación insuficiente del operario,Alta
humano,Error de lectura de plano,Media
humano,Fatiga o turno nocturno,Baja
proveedor,Inspección de entrada no realizada,Alta
proveedor,No conformidad no detectada en origen,Alta
proveedor,Cambio de proveedor sin validación,Media
documental,Trazabilidad de lote incompleta,Alta
documental,CoC o EASA Form 1 no adjunto,Alta
documental,Registro de proceso no firmado,Media
```

---

## 6 · NCR test set (5 casos de prueba)

Guardados en `ncr_test_set.json`. Cubren el rango de severidades y áreas de causa raíz.

### NCR-01 · Defecto dimensional (camino feliz)

**Texto:**
```
NCR-2026-VBX-0101
Fecha detección: 2026-05-15
Pieza: Costilla HTP VBX-COMP-4471-B · Lote L-2026-047
Descripción: Cuerda de costilla fuera de tolerancia. Medida real: 487.4 mm.
Tolerancia especificada: 490.0 ± 0.3 mm. Desviación: -2.3 mm.
Inspector: María Luisa Fernández · Control Calidad
```

**Expected:** `severidad: "Major"` · `clausula: "8.7"` · `contencion: true` · `confianza ≥ 0.90`

---

### NCR-02 · Documental (CoC faltante)

**Texto:**
```
NCR-2026-VBX-0102
Fecha detección: 2026-05-15
Descripción: Lote de resina epoxi EP-2026-M recibido sin Certificado de Conformidad.
Proveedor: ChemComp Iberia S.L. Albarán: ALB-7731.
El material está en cuarentena en almacén B-3. No se puede iniciar fabricación.
Inspector: Carlos Ruiz · Recepción
```

**Expected:** `severidad: "Minor"` · `clausula: "8.4"` · `contencion: false` · `confianza ≥ 0.85`

---

### NCR-03 · Proceso crítico (pieza de vuelo)

**Texto:**
```
NCR-2026-VBX-0103
Fecha detección: 2026-05-16
Pieza: Panel fuselaje VBX-COMP-3301-A · Programa HX-7 · Lote L-2026-051 (CRÍTICO: pieza de vuelo)
Descripción: Durante el ciclo de curado, la temperatura del autoclave superó el rango especificado.
Rango nominal: 180 ± 5°C. Temperatura registrada: 192°C durante 22 minutos (minuto 45 al 67 del ciclo).
Potencial efecto: degradación propiedades mecánicas. Pieza debe someterse a ensayo de ultrasonidos.
Responsable ciclo: Operario OP-14
```

**Expected:** `severidad: "Critical"` · `contencion: true` · D4 causa área `proceso` · `confianza ≥ 0.85`

---

### NCR-04 · Defecto visual (delaminación)

**Texto:**
```
NCR-2026-VBX-0104
Fecha: 2026-05-16
Referencia: VBX-COMP-5501-A · Borde de ataque ala · Lote L-2026-049
Defecto: Delaminación superficial detectada en inspección visual post-desmoldeo.
Área afectada: aprox. 12 cm² en zona posterior a nervio 3.
Se retiene la pieza. No requiere contención inmediata de línea.
```

**Expected:** `severidad: "Minor"` · `clausula: "8.7"` · `contencion: false` · `confianza ≥ 0.80`

---

### NCR-05 · Ambiguo (baja confianza)

**Texto:**
```
NCR-2026-VBX-0105
Problema en pieza. No cumple. Pendiente de investigar.
Visto por Juan.
```

**Expected:** `confianza < 0.70` · `alertas` con aviso de descripción insuficiente · análisis 8D con D2 incompleto · plan con acción "obtener más información"

---

## 7 · Criterios de aceptación (equivalente a spec §8 del MVP-A)

| # | Criterio | Gate |
|---|---|---|
| C1 | NCR-01 produce `severidad: "Major"` y `clausula_as9100: "8.7"` | C4 |
| C2 | NCR-03 (proceso · pieza de vuelo) produce `requiere_contencion_inmediata: true` | C4 |
| C3 | Todos los NCRs producen análisis 8D con D1–D5 no vacíos | C4 |
| C4 | Todos los NCRs producen ≥ 2 acciones en `plan_acciones` con `plazo_dias > 0` | C4 |
| C5 | NCR-05 produce `confianza < 0.70` y `alertas[]` no vacío | C4 |
| C6 | Los 5 NCRs del test set completan el Crew sin excepción de Python | C5 |
| C7 | `lookup_tipo_nc("Defecto dimensional")` devuelve `severidad: Major, clausula: 8.7` | C3 |
| C8 | `main.py` acepta texto libre por stdin y produce JSON válido contra el schema de §4 | C5 |

---

## 8 · Fases de desarrollo

Las fases son **secuenciales**. No pasar a la siguiente sin gate verde.

### C0 · Bootstrap (~30 min)

Sin dependencias. Crea los cimientos y los datos.

| # | Artefacto | Cómo construirlo |
|---|---|---|
| 0.1 | `README.md` | Nuevo · describe caso NCR, arquitectura Crew, cómo ejecutar |
| 0.2 | `SETUP.md` | Paso a paso: Python venv · `pip install -r requirements.txt` · `.env` con API key |
| 0.3 | `.env.example` | Una línea: `ANTHROPIC_API_KEY=` |
| 0.4 | `.gitignore` | `.env` · `__pycache__/` · `*.log` · `*.pyc` |
| 0.5 | `requirements.txt` | `crewai[anthropic]==1.14.4` · `pydantic>=2.7` · `python-dotenv>=1.0.0` |
| 0.6 | `data/tipos_nc.csv` | Contenido exacto de §5 de este documento |
| 0.7 | `data/causas_raiz.csv` | Contenido exacto de §5 de este documento |
| 0.8 | `PLAN.md` | Copia de este documento (referencia en la rama) |
| 0.9 | `PROGRESS.md` | Inicializar desde plantilla (ver §10) |

**Gate C0:** los 2 CSV son UTF-8 sin BOM y abren correctamente en Python con `csv.DictReader`. `requirements.txt` instala sin errores en un venv limpio.

---

### C1 · Tools (~45 min)

Depende de C0. Los tools primero porque los agentes los referencian.

| # | Artefacto | Cómo construirlo |
|---|---|---|
| 1.1 | `tools.py` | 2 funciones decoradas con `@tool` de `crewai.tools` |

**`lookup_tipo_nc(tipo: str) → str`**
- Carga `data/tipos_nc.csv` como mirror dict en memoria
- Busca `tipo` (case-insensitive, acepta coincidencia parcial)
- Devuelve string JSON: `{"severidad": "Major", "clausula_as9100": "8.7", "requiere_contencion": true}`
- Si no encuentra: `{"severidad": "Major", "clausula_as9100": "8.7", "requiere_contencion": true, "aviso": "tipo no en catálogo"}`

**`lookup_causas_raiz(area: str) → str`**
- Carga `data/causas_raiz.csv`
- Filtra por `area` (acepta: `material` · `proceso` · `humano` · `proveedor` · `documental`)
- Devuelve las causas frecuencia Alta primero, máximo 3 resultados, como string JSON array

**Gate C1:** cada tool funciona correctamente con una llamada directa en Python (`python -c "from tools import lookup_tipo_nc; print(lookup_tipo_nc('Defecto dimensional'))"`). Sin errores de import.

---

### C2 · Agentes (~45 min)

Depende de C1.

| # | Artefacto | Cómo construirlo |
|---|---|---|
| 2.1 | `agents.py` | 3 instancias `Agent()` · importa tools de `tools.py` |

**Instrucciones para cada agente:**

**`clasificador`**
```python
Agent(
    role="Clasificador de No Conformidades AS9100",
    goal="Determinar la severidad (Minor/Major/Critical) y cláusula AS9100 de la NCR recibida",
    backstory="""Auditor de calidad con 15 años en manufactura aeronáutica andaluza.
    Conoces AS9100 Rev D de memoria. Usas el catálogo de tipos para clasificar con precisión.
    Siempre indicas si se requiere contención inmediata de la línea de producción.""",
    tools=[lookup_tipo_nc],
    llm=llm,
    verbose=True
)
```

**`causas`**
```python
Agent(
    role="Analista de Causas Raíz 8D",
    goal="Realizar análisis 8D completo (D1-D5) identificando la causa raíz de la no conformidad",
    backstory="""Ingeniero de calidad especializado en metodología 8D y RCCA (Root Cause Corrective Action).
    Has procesado más de 500 NCRs en componentes aeroestructurales. Usas el catálogo de causas
    frecuentes como punto de partida, pero no te limitas a él si el contexto sugiere otra causa.""",
    tools=[lookup_causas_raiz],
    llm=llm,
    verbose=True
)
```

**`planes`**
```python
Agent(
    role="Gestor de Planes de Acción Correctiva",
    goal="Definir acciones correctivas (CAPA) con responsable, plazo y criterio de cierre",
    backstory="""Responsable de CAPA en una Tier 2 aeronáutica. Generas planes realistas:
    plazos en días hábiles, responsables por área (no personas concretas por privacidad),
    mínimo 2 acciones por NCR: una inmediata y una preventiva estructural.""",
    tools=[],
    llm=llm,
    verbose=True
)
```

**Constante `llm` (al inicio del fichero):**
```python
import os
from dotenv import load_dotenv
from crewai import LLM

load_dotenv()
llm = LLM(
    model="anthropic/claude-sonnet-4-20250514",  # prefijo provider/ requerido por LiteLLM
    temperature=0.1,
    api_key=os.getenv("ANTHROPIC_API_KEY")
)
```

> CrewAI 1.x es independiente de LangChain. La interfaz canónica con Claude es `crewai.LLM` enrutada por LiteLLM. No se importa `langchain_anthropic`.

**Gate C2:** `python -c "from agents import clasificador, causas, planes; print('OK')"` sin errores de import.

---

### C3 · Tasks (~45 min)

Depende de C2.

| # | Artefacto | Cómo construirlo |
|---|---|---|
| 3.1 | `tasks.py` | 4 modelos Pydantic + función `build_tasks(clasificador, causas, planes, ncr_text)` → lista de 3 `Task()` |

**Modelos Pydantic (al inicio del fichero):**

CrewAI 1.14 enruta `output_pydantic` a *structured output nativo* del provider. Cada Task produce un objeto tipado, no un string que haya que parsear.

```python
from typing import Literal
from pydantic import BaseModel, Field

class Clasificacion(BaseModel):
    ncr_id: str
    severidad: Literal["Minor", "Major", "Critical"]
    tipo_nc: str
    clausula_as9100: str
    requiere_contencion_inmediata: bool
    descripcion_breve: str

class Analisis8D(BaseModel):
    D1_equipo: str
    D2_descripcion: str
    D3_contencion: str
    D4_causa_raiz: str
    D5_accion_correctiva: str

class AccionCorrectiva(BaseModel):
    id: str
    descripcion: str
    responsable: str
    plazo_dias: int = Field(gt=0)
    estado: str = "Abierta"

class PlanFinal(BaseModel):
    plan_acciones: list[AccionCorrectiva]
    confianza: float = Field(ge=0.0, le=1.0)
    alertas: list[str] = []
```

**Task 1 — Clasificación:**
```python
Task(
    description=f"""Analiza el siguiente texto de NCR y clasifícalo:

{ncr_text}

Usa la herramienta lookup_tipo_nc para confirmar la severidad y cláusula AS9100.
Extrae el ncr_id del texto (formato NCR-YYYY-VBX-NNNN).""",
    expected_output="Clasificación AS9100 estructurada según el modelo Clasificacion",
    agent=clasificador,
    output_pydantic=Clasificacion
)
```

**Task 2 — Análisis 8D:**
```python
Task(
    description="""Basándote en la clasificación anterior, realiza el análisis 8D (D1-D5).
Usa lookup_causas_raiz con el área que corresponda al tipo de NC identificado
(material · proceso · humano · proveedor · documental).
Sé concreto: 1-2 frases por disciplina.""",
    expected_output="Análisis 8D estructurado según el modelo Analisis8D",
    agent=causas,
    context=[task_clasificacion],
    output_pydantic=Analisis8D
)
```

**Task 3 — Plan de acciones:**
```python
Task(
    description="""Genera el plan de acciones correctivas (CAPA) basándote en el análisis 8D.
Define mínimo 2 acciones: una inmediata (plazo ≤ 7 días) y una preventiva (plazo 15-90 días).
Asigna responsables por área (no nombres propios: 'Calidad', 'Producción', 'Compras').
Incluye una confianza global (0.0-1.0) y alertas si la NCR está incompleta
o la causa no es determinable.""",
    expected_output="Plan CAPA + confianza + alertas según el modelo PlanFinal",
    agent=planes,
    context=[task_causas],
    output_pydantic=PlanFinal
)
```

**Gate C3:** `python -c "from tasks import build_tasks, Clasificacion, Analisis8D, PlanFinal; from agents import clasificador, causas, planes; t=build_tasks(clasificador, causas, planes, 'test'); print(len(t))"` imprime `3` sin errores.

---

### C4 · Crew y ejecución (~45 min)

Depende de C3.

| # | Artefacto | Cómo construirlo |
|---|---|---|
| 4.1 | `main.py` | Entry point: stdin → Crew → JSON stdout |

**Estructura de `main.py`:**
```python
import sys, json
from crewai import Crew, Process
from agents import clasificador, causas, planes
from tasks import build_tasks

def run(ncr_text: str) -> dict:
    tasks = build_tasks(clasificador, causas, planes, ncr_text)
    crew = Crew(
        agents=[clasificador, causas, planes],
        tasks=tasks,
        process=Process.sequential,
        verbose=True
    )
    result = crew.kickoff()  # → CrewOutput

    # Cada task tiene output_pydantic, así que .pydantic devuelve un modelo tipado.
    clasif = result.tasks_output[0].pydantic.model_dump()
    ncr_id = clasif.pop("ncr_id")
    plan_final = result.tasks_output[2].pydantic.model_dump()

    return {
        "ncr_id": ncr_id,
        "clasificacion": clasif,
        "analisis_8d": result.tasks_output[1].pydantic.model_dump(),
        **plan_final,  # plan_acciones, confianza, alertas
    }

def main():
    ncr_text = sys.stdin.read().strip()
    if not ncr_text:
        print(json.dumps({"error": "no_ncr", "mensaje": "Introduce el texto del NCR por stdin"}))
        sys.exit(1)
    output = run(ncr_text)
    print(json.dumps(output, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
```

**Nota:** `crew.kickoff()` retorna un `CrewOutput`. Cada `result.tasks_output[i]` expone `.pydantic` (modelo tipado), `.json_dict` (dict) y `.raw` (string crudo). Como cada Task tiene `output_pydantic`, el camino canónico es `.pydantic.model_dump()`. El `main.py` compone el JSON final del schema §4 a partir de los 3 outputs intermedios — esto mantiene la separación pedagógica entre fases del Crew y deja el ensamblado final en una sola línea legible.

**Prueba manual de C4** (con NCR-01):
```powershell
$ncr = @"
NCR-2026-VBX-0101
Pieza: Costilla HTP VBX-COMP-4471-B
Defecto: cuerda fuera de tolerancia. Real: 487.4mm. Nominal: 490.0 ± 0.3mm
Inspector: María Luisa Fernández
"@
$ncr | python main.py
```

**Gate C4:** la salida es JSON válido. `severidad` es `"Major"`. `clausula_as9100` es `"8.7"`. `analisis_8d` tiene 5 campos. `plan_acciones` tiene ≥ 2 elementos. Sin excepción de Python.

---

### C5 · Test set y validación (~45 min)

Depende de C4.

| # | Artefacto | Cómo construirlo |
|---|---|---|
| 5.1 | `ncr_test_set.json` | 5 casos del §6 con `ncr_text` e `expected` |
| 5.2 | Validación manual C1–C8 | Pasar los 5 NCRs por `main.py` y comparar con `expected` |
| 5.3 | `PROGRESS.md` actualizado | Criterios C1–C8 marcados con resultado real |

**Estructura de `ncr_test_set.json`:**
```json
{
  "casos": [
    {
      "case_id": "NCR-2026-VBX-0101",
      "descripcion": "Defecto dimensional costilla HTP",
      "ncr_text": "...",
      "expected": {
        "severidad": "Major",
        "clausula_as9100": "8.7",
        "requiere_contencion_inmediata": true,
        "confianza_min": 0.85,
        "analisis_8d_campos": ["D1_equipo", "D2_descripcion", "D3_contencion", "D4_causa_raiz", "D5_accion_correctiva"],
        "plan_acciones_min": 2
      }
    }
  ]
}
```

**Gate C5:** 8/8 criterios de §7 verificados. Al menos C6 (5/5 NCRs sin excepción) es requisito duro para cerrar la fase.

---

## 9 · Mapa de dependencias

```
C0 (bootstrap · datos)
 └─→ C1 (tools · importan CSVs de C0)
      └─→ C2 (agentes · importan tools de C1)
           └─→ C3 (tasks · importan agentes de C2)
                └─→ C4 (main.py · importa tasks + agentes)
                     └─→ C5 (test set + validación criterios)

Ruta crítica: C0 → C1 → C2 → C3 → C4 → C5 (~4 horas estimadas)
```

---

## 10 · Convenciones operativas

- **Una sola variable de entorno:** `ANTHROPIC_API_KEY`. Sin Telegram, Sheets ni SMTP en este módulo.
- **Modelo:** `claude-sonnet-4-20250514 · temperature 0.1` (igual que MVP-A).
- **Idioma de logs y agentes:** español. Backstories en español. Tasks en español.
- **JSON keys:** `snake_case` español (igual que MVP-A: `causa_raiz`, `plazo_dias`).
- **Commits granulares por fase:** `feat(C0): bootstrap datos NCR` · `feat(C1): tools lookup` · etc.
- **PROGRESS.md:** actualizar al inicio (⬜→🔄) y al fin (🔄→✅) de cada artefacto.
- **Sin secrets en código:** el API key sólo en `.env` (gitignoreado). `.env.example` sin valor.
- **verbose=True en producción del código**, para que el alumno vea el razonamiento de cada agente en clase.

---

## 11 · PROGRESS.md — plantilla inicial

Copiar este bloque como contenido de `PROGRESS.md` al iniciar la sesión:

```markdown
# PROGRESS.md — Estado de desarrollo · MVP-B CrewAI NCR

**Branch:** `dev/crewai-ncr`
**Inicio del desarrollo:** YYYY-MM-DD
**Último cambio:** —
**Estado global:** 🔄 en curso

> Documento vivo. Actualizar al inicio y fin de cada artefacto.
> Estados: ⬜ pendiente · 🔄 en curso · ✅ hecho · ⛔ bloqueado

---

## Resumen por fase

| Fase | Descripción | Estado | Avance | Gate |
|---|---|---|---|---|
| C0 | Bootstrap (datos + env) | ⬜ | 0/9 | ⬜ |
| C1 | Tools (lookup_tipo_nc + lookup_causas_raiz) | ⬜ | 0/1 | ⬜ |
| C2 | Agentes (Clasificador + Causas + Planes) | ⬜ | 0/1 | ⬜ |
| C3 | Tasks (3 tasks secuenciales) | ⬜ | 0/1 | ⬜ |
| C4 | Crew y ejecución (main.py) | ⬜ | 0/1 | ⬜ |
| C5 | Test set y validación criterios | ⬜ | 0/3 | ⬜ |

---

## Detalle por artefacto

### C0 · Bootstrap

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 0.1 | ⬜ | `README.md` | |
| 0.2 | ⬜ | `SETUP.md` | |
| 0.3 | ⬜ | `.env.example` | |
| 0.4 | ⬜ | `.gitignore` | |
| 0.5 | ⬜ | `requirements.txt` | |
| 0.6 | ⬜ | `data/tipos_nc.csv` | |
| 0.7 | ⬜ | `data/causas_raiz.csv` | |
| 0.8 | ⬜ | `PLAN.md` | copia del plan en master |
| 0.9 | ⬜ | `PROGRESS.md` | este fichero |

**Gate C0:** ⬜

### C1 · Tools

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 1.1 | ⬜ | `tools.py` | |

**Gate C1:** ⬜

### C2 · Agentes

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 2.1 | ⬜ | `agents.py` | |

**Gate C2:** ⬜

### C3 · Tasks

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 3.1 | ⬜ | `tasks.py` | |

**Gate C3:** ⬜

### C4 · Crew y ejecución

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 4.1 | ⬜ | `main.py` | |

**Gate C4:** ⬜

### C5 · Test set y validación

| # | Estado | Artefacto | Nota |
|---|---|---|---|
| 5.1 | ⬜ | `ncr_test_set.json` | |
| 5.2 | ⬜ | Validación C1–C8 | |
| 5.3 | ⬜ | `PROGRESS.md` criterios | |

**Gate C5:** ⬜

---

## Criterios de aceptación

| # | Criterio | Estado | Notas |
|---|---|---|---|
| C1 | NCR-01 → severidad Major · clausula 8.7 | ⬜ | |
| C2 | NCR-03 (proceso crítico) → contencion true | ⬜ | |
| C3 | Todos → analisis_8d con D1-D5 no vacíos | ⬜ | |
| C4 | Todos → ≥ 2 acciones con plazo_dias > 0 | ⬜ | |
| C5 | NCR-05 (ambiguo) → confianza < 0.70 + alertas | ⬜ | |
| C6 | 5/5 NCRs sin excepción de Python | ⬜ | |
| C7 | lookup_tipo_nc("Defecto dimensional") → correcto | ⬜ | |
| C8 | main.py stdin → JSON válido | ⬜ | |

---

## Decisiones de implementación

| Fecha | Tema | Decisión | Justificación |
|---|---|---|---|
| | | | |

---

## Bloqueos / pendientes

> Si una fase queda bloqueada, registrar aquí causa + propuesta.
```

---

## 12 · Arranque de la sesión de desarrollo

```powershell
# 1. Situarse en master actualizado
git checkout master
git pull

# 2. Crear la rama
git checkout -b dev/crewai-ncr

# 3. Crear el directorio del proyecto
mkdir "CONTENT\MVP-B_Crew_NCR"
cd "CONTENT\MVP-B_Crew_NCR"

# 4. Decirle a Claude Code:
#    "Arranca el desarrollo siguiendo CONTENT/PARTE2-Materiales/plan_desarrollo_crewai_ncr.md.
#     Empieza por C0 (bootstrap). Lee el plan completo antes de escribir nada."
```

**Criterio de cierre de la rama:** 8/8 criterios de aceptación en verde en `PROGRESS.md`. PR a `master` con título `feat(MVP-B): código CrewAI NCR · módulo multi-agente`.

---

## 13 · Salida esperada al cerrar el desarrollo

- Árbol completo en `CONTENT/MVP-B_Crew_NCR/` con los 14 artefactos de §3.
- `PROGRESS.md` con C1–C8 en verde.
- `main.py` ejecutable: `echo "NCR texto..." | python main.py` produce JSON.
- Los 5 NCRs del test set pasan sin excepción.
- Rama `dev/crewai-ncr` lista para PR a `master`.
- Bloqueante `CrewAI-0` resuelto: M1–M4 del módulo extra desbloqueados.

---

*COIIAOC · Parte 2 · MVP-B CrewAI NCR · Plan operativo de desarrollo*
*Generado: 2026-05-08 · para rama `dev/crewai-ncr`*
