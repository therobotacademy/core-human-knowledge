# MVP-B · CrewAI NCR

Sistema multi-agente con [CrewAI](https://github.com/crewAIInc/crewAI) que analiza Non-Conformance Reports (NCR) aeronáuticos del sistema de calidad de **VERBEX COMPOSITES S.L.** (caso ficticio del curso COIIAOC, Parte 2).

A partir del texto libre de un NCR, el Crew produce automáticamente:

- **Clasificación** de severidad (`Minor` / `Major` / `Critical`) con la cláusula AS9100 afectada y aviso de contención inmediata.
- **Análisis 8D** de causa raíz (disciplinas D1–D5).
- **Plan de acciones correctivas** (CAPA) con responsable por área y plazo en días hábiles.

La salida es un único objeto JSON validable contra el schema documentado en `PLAN.md §4`.

---

## 1 · Arquitectura

```
stdin (texto NCR)
        │
        ▼
  ┌─────────────────────────────────────────────────────┐
  │                  Crew NCR (sequential)              │
  │                                                     │
  │  Agente Clasificador  ──tool→  lookup_tipo_nc       │
  │         │                                           │
  │         ▼ context                                   │
  │  Agente Causas        ──tool→  lookup_causas_raiz   │
  │         │                                           │
  │         ▼ context                                   │
  │  Agente Planes        (sin tool · razonamiento)     │
  └─────────────────────────────────────────────────────┘
        │
        ▼
  JSON output (stdout)
```

Tres agentes encadenados con `Process.sequential` de CrewAI. Cada agente recibe como `context` el output del anterior y, salvo el último, dispone de una *tool* específica que consulta los catálogos CSV en `data/`.

---

## 2 · Stack técnico

| Componente | Versión |
|---|---|
| Python | 3.10+ |
| crewai | `>= 0.28` |
| langchain-anthropic | última |
| python-dotenv | última |
| Modelo LLM | `claude-sonnet-4-20250514` · `temperature 0.1` |

Compatible con **Daytona sandbox**. Una sola variable de entorno: `ANTHROPIC_API_KEY`.

---

## 3 · Cómo ejecutar

> Requisitos previos: ver `SETUP.md` (Python 3.10+, venv activado, dependencias instaladas, `.env` con `ANTHROPIC_API_KEY`).

```powershell
# Desde el directorio MVP-B_Crew_NCR/
$ncr = @"
NCR-2026-VBX-0101
Pieza: Costilla HTP VBX-COMP-4471-B · Lote L-2026-047
Defecto: cuerda fuera de tolerancia. Real: 487.4mm. Nominal: 490.0 ± 0.3mm
Inspector: María Luisa Fernández
"@
$ncr | python main.py
```

Salida esperada: JSON con los bloques `clasificacion`, `analisis_8d`, `plan_acciones`, `confianza` y `alertas`.

---

## 4 · Estructura del proyecto

```
MVP-B_Crew_NCR/
├── README.md                  # este fichero
├── SETUP.md                   # instalación paso a paso
├── PLAN.md                    # plan de desarrollo (referencia)
├── PROGRESS.md                # tracker vivo
├── .env.example
├── .gitignore
├── requirements.txt
│
├── data/
│   ├── tipos_nc.csv           # 10 tipos de NC · severidad · cláusula AS9100
│   └── causas_raiz.csv        # 16 causas raíz por área (8D)
│
├── ncr_test_set.json          # 5 NCRs de prueba con expected output
│
├── agents.py                  # 3 Agent() · Clasificador · Causas · Planes
├── tasks.py                   # 3 Task() encadenados con context
├── tools.py                   # @tool: lookup_tipo_nc · lookup_causas_raiz
└── main.py                    # entry point: stdin → Crew → JSON stdout
```

---

## 5 · Test set

Cinco NCRs de prueba en `ncr_test_set.json` cubren el rango de severidades y áreas de causa raíz (dimensional, documental, proceso crítico, visual y un caso ambiguo de baja confianza). Los criterios de aceptación C1–C8 están en `PLAN.md §7`.

---

## 6 · Por qué CrewAI y no n8n

La coordinación entre agentes especializados (clasificador → causas → planes) es inherente al dominio. Cada agente **razona sobre el output del anterior**, no solo enruta datos. n8n con un único nodo LLM resolvería el caso, pero el alumno no vería la **delegación explícita entre roles** ni el efecto de las *tools* específicas. Este módulo es el único punto de entrada a Python obligatorio en la Parte 2.

---

*COIIAOC · Parte 2 · MVP-B CrewAI NCR · módulo multi-agente*
