"""Agentes del Crew NCR · 3 roles especializados encadenados secuencialmente.

- clasificador: severidad AS9100 + cláusula + contención.   tool: lookup_tipo_nc
- causas:      análisis 8D D1-D5.                            tool: lookup_causas_raiz
- planes:      plan CAPA + confianza + alertas.              sin tool (razonamiento puro)

LLM canónico CrewAI 1.x: `crewai.LLM` enrutado por LiteLLM al provider Anthropic.
"""
import os

from crewai import LLM, Agent
from dotenv import load_dotenv

from tools import lookup_causas_raiz, lookup_tipo_nc

load_dotenv()

llm = LLM(
    model="anthropic/claude-sonnet-4-20250514",
    temperature=0.1,
    api_key=os.getenv("ANTHROPIC_API_KEY"),
)


clasificador = Agent(
    role="Clasificador de No Conformidades AS9100",
    goal=(
        "Determinar la severidad (Minor/Major/Critical) y cláusula AS9100 de "
        "la NCR recibida, e indicar si requiere contención inmediata."
    ),
    backstory=(
        "Auditor de calidad con 15 años en manufactura aeronáutica andaluza. "
        "Aunque conoces AS9100 Rev D, SIEMPRE confirmas la severidad y la "
        "cláusula con el catálogo del sistema (herramienta `lookup_tipo_nc`) "
        "para mantener consistencia con la base de datos de la empresa. "
        "Devuelves los valores textuales que la tool retorna, sin añadir "
        "descripciones ni sufijos. Cuando el texto es ambiguo, prefieres la "
        "severidad más conservadora."
    ),
    tools=[lookup_tipo_nc],
    llm=llm,
    verbose=True,
)


causas = Agent(
    role="Analista de Causas Raíz 8D",
    goal=(
        "Realizar análisis 8D completo (D1-D5) identificando la causa raíz "
        "de la no conformidad y el área a la que pertenece "
        "(material · proceso · humano · proveedor · documental)."
    ),
    backstory=(
        "Ingeniero de calidad especializado en metodología 8D y RCCA "
        "(Root Cause Corrective Action). Has procesado más de 500 NCRs en "
        "componentes aeroestructurales. Antes de identificar la causa raíz, "
        "SIEMPRE consultas la herramienta `lookup_causas_raiz` con el área 8D "
        "que corresponda (material · proceso · humano · proveedor · documental). "
        "Usas las causas del catálogo como base, pero puedes refinar la "
        "redacción si el texto del NCR aporta detalle específico."
    ),
    tools=[lookup_causas_raiz],
    llm=llm,
    verbose=True,
)


planes = Agent(
    role="Gestor de Planes de Acción Correctiva",
    goal=(
        "Definir acciones correctivas (CAPA) con responsable por área, plazo en "
        "días hábiles y criterio de cierre. Indicar también la confianza global "
        "del análisis y alertas si la NCR está incompleta."
    ),
    backstory=(
        "Responsable de CAPA en una Tier 2 aeronáutica. Generas planes realistas: "
        "plazos en días hábiles, responsables por área (Calidad · Producción · "
        "Compras · Ingeniería) sin nombrar personas concretas por privacidad. "
        "Mínimo 2 acciones por NCR: una inmediata y una preventiva estructural."
    ),
    tools=[],
    llm=llm,
    verbose=True,
)
