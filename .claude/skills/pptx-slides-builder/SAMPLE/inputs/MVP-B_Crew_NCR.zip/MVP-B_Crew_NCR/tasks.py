"""Tasks del Crew NCR · 3 Task encadenadas con context + structured output.

Cada Task expone `output_pydantic=Modelo` para enrutar la salida al
*native structured output* del provider (Anthropic). El acceso desde
main.py es `result.tasks_output[i].pydantic.model_dump()`.

Modelos:
- Clasificacion:    output del clasificador
- Analisis8D:       output del analista 8D
- AccionCorrectiva: elemento del plan CAPA
- PlanFinal:        output del gestor de planes (lista CAPA + confianza + alertas)
"""
from typing import Literal

from crewai import Task
from pydantic import BaseModel, Field


class Clasificacion(BaseModel):
    ncr_id: str
    severidad: Literal["Minor", "Major", "Critical"]
    tipo_nc: str
    clausula_as9100: str
    requiere_contencion_inmediata: bool
    descripcion_breve: str


class Analisis8D(BaseModel):
    D1_equipo: str
    D2_descripcion: str
    D3_contencion: str
    D4_causa_raiz: str
    D5_accion_correctiva: str


class AccionCorrectiva(BaseModel):
    id: str
    descripcion: str
    responsable: str
    plazo_dias: int = Field(gt=0)
    estado: str = "Abierta"


class PlanFinal(BaseModel):
    plan_acciones: list[AccionCorrectiva]
    confianza: float = Field(ge=0.0, le=1.0)
    alertas: list[str] = []


def build_tasks(clasificador, causas, planes, ncr_text: str) -> list[Task]:
    """Construye las 3 Task del Crew secuencial con el texto del NCR inyectado."""

    task_clasificacion = Task(
        description=(
            "Analiza el siguiente texto de NCR y clasifícalo según AS9100:\n\n"
            f"{ncr_text}\n\n"
            "Pasos OBLIGATORIOS en este orden:\n"
            "1. Extrae el `ncr_id` del texto (formato típico `NCR-YYYY-VBX-NNNN`).\n"
            "2. Identifica el tipo del catálogo del sistema que mejor encaja. "
            "Tipos válidos del catálogo:\n"
            "   - Defecto dimensional\n"
            "   - Defecto de material\n"
            "   - Defecto de proceso\n"
            "   - Defecto visual\n"
            "   - No conformidad documental\n"
            "   - Defecto de proveedor\n"
            "   - Error de trazabilidad\n"
            "   - Defecto de acabado superficial\n"
            "   - No conformidad crítica\n"
            "   - Incumplimiento de especificación\n"
            "3. LLAMA OBLIGATORIAMENTE a la herramienta `lookup_tipo_nc` con el nombre "
            "exacto del tipo elegido (p. ej. `lookup_tipo_nc(tipo='Defecto dimensional')`). "
            "Esto NO es opcional: el sistema exige consistencia con el catálogo.\n"
            "4. Devuelve los campos `severidad`, `clausula_as9100` y "
            "`requiere_contencion_inmediata` con los valores TEXTUALES que devuelve la tool. "
            "No añadas descripciones, sufijos ni texto adicional al valor de cláusula "
            "(la cláusula es solo el código numérico, p.ej. `8.7`, no `8.7 Control de salidas`).\n"
            "5. El campo `tipo_nc` debe contener el nombre del catálogo (ej. "
            "`Defecto dimensional`), no una descripción libre.\n"
            "6. Para piezas de vuelo, defectos críticos o cualquier riesgo de "
            "ensamblaje final, marca `requiere_contencion_inmediata` en `true`.\n"
            "7. Resume el defecto en una frase (`descripcion_breve`)."
        ),
        expected_output=(
            "Clasificación AS9100 estructurada con ncr_id, severidad, tipo_nc "
            "(nombre del catálogo), clausula_as9100 (solo código numérico), "
            "requiere_contencion_inmediata y descripcion_breve."
        ),
        agent=clasificador,
        output_pydantic=Clasificacion,
    )

    task_causas = Task(
        description=(
            "Basándote en la clasificación anterior, realiza el análisis 8D (D1-D5).\n\n"
            "Pasos OBLIGATORIOS:\n"
            "1. Determina el área 8D que corresponde al `tipo_nc` clasificado:\n"
            "   - `material` para Defecto de material, problemas con CoC o lotes.\n"
            "   - `proceso` para Defecto de proceso, Defecto dimensional, parámetros de fabricación.\n"
            "   - `humano` para errores de operario, formación, lectura de planos.\n"
            "   - `proveedor` para Defecto de proveedor, no conformidades en origen.\n"
            "   - `documental` para No conformidad documental, Error de trazabilidad.\n"
            "2. LLAMA OBLIGATORIAMENTE a `lookup_causas_raiz` con esa área "
            "(p. ej. `lookup_causas_raiz(area='proceso')`). El sistema exige consistencia.\n"
            "3. Selecciona la causa raíz más probable de las que devuelve la tool, "
            "o refínala con el detalle del NCR si el texto lo justifica.\n"
            "4. Rellena los 5 campos D1-D5:\n"
            "   - D1_equipo: equipo o área responsable de la investigación.\n"
            "   - D2_descripcion: descripción detallada del problema.\n"
            "   - D3_contencion: acciones de contención inmediata.\n"
            "   - D4_causa_raiz: causa raíz (basada en el catálogo o refinada).\n"
            "   - D5_accion_correctiva: acción correctiva específica.\n"
            "Sé concreto: 1-2 frases por disciplina."
        ),
        expected_output="Análisis 8D estructurado con los 5 campos D1_equipo a D5_accion_correctiva.",
        agent=causas,
        context=[task_clasificacion],
        output_pydantic=Analisis8D,
    )

    task_planes = Task(
        description=(
            "Genera el plan de acciones correctivas (CAPA) basándote en el análisis 8D.\n\n"
            "Reglas:\n"
            "- Mínimo 2 acciones: una inmediata (`plazo_dias` ≤ 7) y una "
            "preventiva estructural (`plazo_dias` 15-90).\n"
            "- Asigna `responsable` por área, no por persona "
            "(ej. 'Calidad', 'Producción', 'Compras', 'Ingeniería').\n"
            "- Cada acción tiene un `id` único (AC-001, AC-002, ...) y "
            "`estado` inicial 'Abierta'.\n"
            "- Indica una `confianza` global entre 0.0 y 1.0:\n"
            "  · ≥ 0.90 si el NCR está completo y el tipo es claro\n"
            "  · 0.70-0.89 si hay ambigüedad menor\n"
            "  · < 0.70 si el texto es incompleto o la causa no es determinable\n"
            "- Añade `alertas` con avisos cuando la NCR esté incompleta, "
            "la causa raíz no sea determinable o haga falta más información."
        ),
        expected_output="Plan CAPA con plan_acciones (≥ 2), confianza (0.0-1.0) y alertas (lista, vacía si no aplica).",
        agent=planes,
        context=[task_causas],
        output_pydantic=PlanFinal,
    )

    return [task_clasificacion, task_causas, task_planes]
