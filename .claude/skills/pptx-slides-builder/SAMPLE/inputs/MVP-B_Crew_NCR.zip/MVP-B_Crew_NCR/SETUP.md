# SETUP · MVP-B CrewAI NCR

Instalación paso a paso para ejecutar el Crew en local. Tiempo estimado: 10 min.

---

## 1 · Requisitos

- **Python 3.10 o superior** (`python --version`).
- **pip** actualizado (`python -m pip install --upgrade pip`).
- **API key de Anthropic** activa (https://console.anthropic.com/).
- Conexión a internet (las llamadas a Claude salen a la API de Anthropic).

> Compatible con Windows · macOS · Linux. Compatible con **Daytona sandbox**.

---

## 2 · Crear y activar el entorno virtual

Desde el directorio `MVP-B_Crew_NCR/`:

### Windows (PowerShell)

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Si PowerShell bloquea la activación por política de ejecución:

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Cuando el venv está activo, el prompt muestra `(.venv)` al inicio.

---

## 3 · Instalar dependencias

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

Esto instala:

- `crewai >= 0.28` — framework multi-agente.
- `langchain-anthropic` — cliente Claude para CrewAI.
- `python-dotenv` — carga del fichero `.env`.

> En Windows, si la instalación de `crewai` falla por compilación nativa, instala Microsoft C++ Build Tools (https://visualstudio.microsoft.com/visual-cpp-build-tools/).

---

## 4 · Configurar la API key

Copia el fichero de ejemplo y rellena tu key:

### Windows

```powershell
Copy-Item .env.example .env
notepad .env
```

### macOS / Linux

```bash
cp .env.example .env
nano .env
```

Contenido de `.env`:

```
ANTHROPIC_API_KEY=sk-ant-api03-XXXXXXXXXXXXXXXXXXXXXX
```

> El fichero `.env` está en `.gitignore`. **Nunca lo subas al repositorio.**

---

## 5 · Verificar la instalación

Comprueba que los CSVs de catálogo cargan correctamente:

```bash
python -c "import csv; print(list(csv.DictReader(open('data/tipos_nc.csv', encoding='utf-8')))[0])"
```

Debe imprimir el primer registro de `tipos_nc.csv`. Si falla con `UnicodeDecodeError`, el CSV no es UTF-8.

Comprueba que CrewAI importa:

```bash
python -c "from crewai import Crew, Agent, Task; print('crewai OK')"
```

Comprueba que la API key carga:

```bash
python -c "import os; from dotenv import load_dotenv; load_dotenv(); print('OK' if os.getenv('ANTHROPIC_API_KEY') else 'FALTA API KEY')"
```

---

## 6 · Primera ejecución

Cuando esté listo `main.py` (fase C4), arrancar con un NCR de prueba:

### Windows

```powershell
$ncr = "NCR-TEST · Pieza fuera de tolerancia · Inspector test"
$ncr | python main.py
```

### macOS / Linux

```bash
echo "NCR-TEST · Pieza fuera de tolerancia · Inspector test" | python main.py
```

La salida debe ser un JSON con los bloques `clasificacion`, `analisis_8d`, `plan_acciones`.

---

## 7 · Resolución de problemas

| Síntoma | Causa probable | Solución |
|---|---|---|
| `ModuleNotFoundError: crewai` | venv no activado | reactivar `.venv` |
| `AuthenticationError` | API key vacía o errónea | revisar `.env` |
| `UnicodeDecodeError` al leer CSV | CSV con BOM o encoding distinto | re-guardar como UTF-8 sin BOM |
| `pydantic` versión incompatible | conflicto con instalación previa | `pip install -r requirements.txt --force-reinstall` |
| `langchain_anthropic` no encuentra el modelo | nombre del modelo cambiado | usar `claude-sonnet-4-20250514` |

---

*COIIAOC · Parte 2 · MVP-B CrewAI NCR · guía de instalación*
