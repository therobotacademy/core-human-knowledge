# II1 — Ingesta y Conectividad de Canales

**Sesión:** Parte 2 · Módulo II1
**Idea fuerza del módulo:** *"El agente busca datos él solo."*
**PRDA:** Percibir
**Tiempo en clase:** 2,5 h

---

## ¿Qué se construye?

Un workflow n8n con **4 nodos** que recibe Purchase Orders por Telegram, filtra remitentes no autorizados, detecta el canal de origen del que viene la PO y devuelve un JSON normalizado de entrada.

**Sin LLM. Sin validación de catálogo. Sin Sheets.** Sólo limpia el texto y prepara el payload que entrará a II2.

```
Telegram → Filtro chat_id autorizado → Detectar canal + preprocesar → Stub salida (JSON)
```

### Nodos

| # | Nodo | Tipo | Función |
|---|---|---|---|
| 1 | `Ingesta · Telegram Trigger` | telegramTrigger | Escucha mensajes entrantes en el bot VERBEX |
| 2 | `Ingesta · Filtro chat_id autorizado` | filter v2 | Sólo continúa si `chat_id ∈ TELEGRAM_ALLOWED_CHAT_IDS` y el texto no está vacío |
| 3 | `Ingesta · Detectar canal y preprocesar` | code v2 | Lookup `chat_id → codigo_erp` + heurística de canal + limpieza |
| 4 | `Ingesta · Stub salida` | set v3.4 | Output limpio del módulo (contrato de datos para II2) |

---

## Heurística de detección de canal

El nodo Code identifica el canal de origen de la PO por estructura del texto:

| Estructura del mensaje | `canal_detectado` |
|---|---|
| Contiene `HELIONLINK` o ≥ 5 campos separados por `|` | `helionlink_csv` |
| Menciona "Kairos Defense" o "portal web" | `portal_web` |
| Cualquier otro caso (PO en texto libre) | `email_pdf` |

> Esta es una heurística simple, no una clasificación robusta. Se sostiene porque sólo hay 3 canales en VERBEX y son visualmente muy distintos. En II3 el LLM hará clasificación semántica fina.

---

## IO/RE de la sesión

| | |
|---|---|
| **Inputs** | Token Telegram bot · `clientes.csv` (mirror in-memory en el Code node) · payloads de prueba |
| **Outputs** | JSON normalizado: `{texto_limpio, chat_id, codigo_erp_detectado, canal_detectado, from_username, fecha_hoy, timestamp_recepcion}` |
| **Reglas** | Sólo `chat_id` autorizado · texto no vacío · trim a 4 000 chars · normalización de saltos de línea y espacios |
| **Excepciones** | `chat_id` desconocido → `codigo_erp_detectado: null` (no rompe, II2 lo trata como "cliente nuevo") · texto vacío → ignorar (Filter lo descarta) |

---

## Output del workflow (contrato para II2)

Tras el Set "Stub salida":

```json
{
  "texto_limpio": "Purchase Order PO-2025-STRA-0847. Stratos Systems. ...",
  "chat_id": "123456789",
  "codigo_erp_detectado": "STRA-001",
  "canal_detectado": "email_pdf",
  "from_username": "stratos_pedidos",
  "fecha_hoy": "2026-05-08",
  "timestamp_recepcion": "2026-05-08T11:50:34.123Z"
}
```

---

## Prerrequisitos (de `SETUP.md`)

- Bot Telegram creado con @BotFather + token en `TELEGRAM_BOT_TOKEN`.
- Tu propio `chat_id` añadido a `TELEGRAM_ALLOWED_CHAT_IDS` (CSV).
- n8n instalado y corriendo en `http://localhost:5678`.
- Credencial **Telegram Bot API** configurada en n8n con el token.

---

## Cómo correr esta sesión

### 1. Importar el workflow

En n8n: **Workflows** → **Import from File** → seleccionar `workflow_II1.json`.

### 2. Asignar credenciales

Abrir el nodo `Ingesta · Telegram Trigger` y asignar la credencial Telegram (`CREDENTIAL_TELEGRAM` es un placeholder — reemplazar por tu credencial real).

### 3. Activar variables de entorno

En **Settings** → **Environment Variables** verificar:

```
TELEGRAM_ALLOWED_CHAT_IDS=123456789,234567890,345678901,456789012,567890123
```

> Sustituir por los `chat_id` reales que vayan a usar tus alumnos.

### 4. Activar el workflow

Pulsar el toggle **Active** en la esquina superior derecha del editor.

### 5. Probar con los 4 payloads

Copiar el contenido de cada `payloads/payload_0X_*.txt` y enviarlo como mensaje al bot:

| Payload | Resultado esperado | `canal_detectado` |
|---|---|---|
| `payload_01_po_estandar.txt` | PO estándar de Stratos | `email_pdf` |
| `payload_02_helionlink_csv.txt` | CSV pipe-separated de HelionLink | `helionlink_csv` |
| `payload_03_aog_alert.txt` | Alerta AOG en texto libre | `email_pdf` |
| `payload_04_amendment.txt` | Revisión de PO existente | `email_pdf` |

> **Nota didáctica.** `payload_03` (AOG) se detecta como `email_pdf`. La detección semántica de "esto es una urgencia AOG" llegará en II3 con el LLM. II1 sólo identifica el **canal de origen**, no el contenido.

### 6. Verificar el JSON output

Tras cada ejecución, abrir el panel de **Executions** del workflow y comprobar que el output del nodo `Ingesta · Stub salida` contiene los 7 campos del contrato (§ "Output del workflow") con los valores correctos.

---

## Gate F1 (criterio de cierre de la sesión)

✅ El workflow procesa los 4 payloads y devuelve JSON con `{texto_limpio, chat_id, codigo_erp_detectado, canal_detectado, ...}` sin invocar al LLM.

---

## Lo que NO hace este workflow (queda para II2 e II3)

- ❌ Validar productos contra `catalogo.csv` → II2.
- ❌ Calcular fechas de urgencia → II2.
- ❌ Detectar AOG semánticamente → II3 (LLM).
- ❌ Mapear PN cliente a PN proveedor → II3 (LLM).
- ❌ Aplicar reglas R01–R09 → II2.
- ❌ Notificar por Telegram al operador → II4.
- ❌ Registrar en Sheets → II4.

II1 es deliberadamente mínimo. Sienta el contrato de datos sobre el que se construye todo lo demás.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Sesión II1*
