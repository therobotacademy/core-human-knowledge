# II3 — Capa Semántica (Claude API)

**Sesión:** Parte 2 · Módulo II3
**Idea fuerza del módulo:** *"El LLM recibe hechos verificables, no datos crudos."*
**PRDA:** Razonar (capa cognitiva)
**Tiempo en clase:** 2,5 h

---

## ¿Qué se construye?

Un workflow n8n con **11 nodos** que reemplaza la inyección simulada de II2 por una **llamada real a Claude API**. La PO en texto libre entra, el LLM la normaliza al schema VERBEX, un parser anti-alucinación valida el output, y las mismas reglas R01–R09 deterministas de II2 procesan la salida.

```
Manual Trigger → Texto PO → Construir body API → HTTP Request Claude
       → Validar JSON LLM → R04+R08 → R07 → R01+R02 → R05+R06 → R03 → R09
```

### Por qué importa

II2 demostró que las reglas funcionan con datos perfectos. II3 introduce el LLM y hace explícito que **el modelo es falible** (puede inventar PNs, devolver markdown, fallar el schema). El parser anti-alucinación es la barrera que impide que la falibilidad del LLM contamine las reglas deterministas.

---

## Anatomía del workflow

| # | Nodo | Tipo | Función |
|---|---|---|---|
| 1 | Manual Trigger | manualTrigger | Click en "Execute Workflow" |
| 2 | Texto de prueba (PO en bruto) | set | Pega aquí el texto de cualquier PO. Por defecto: ejemplo Stratos |
| 3 | Construir body API | code | Define el system prompt completo (SOUL + SKILL + 5 ejemplos) y el body para `/v1/messages` |
| 4 | Cognitivo · Llamada Claude API | httpRequest | POST a `https://api.anthropic.com/v1/messages` · `temperature: 0.1` · timeout 30 s |
| 5 | Validar JSON LLM (anti-alucinación) | code | Parser: extrae JSON, valida schema, fuerza `part_number_proveedor: null` si el LLM se inventó uno |
| 6 | R04 + R08 | code | Mismo nodo que II2 |
| 7 | R07 | code | Mismo nodo que II2 |
| 8 | R01 + R02 | code | Mismo nodo que II2 |
| 9 | R05 + R06 | code | Mismo nodo que II2 |
| 10 | R03 | code | Mismo nodo que II2 |
| 11 | R09 | code | Mismo nodo que II2 |

**Configuración técnica del LLM (spec § 7):**
- Modelo: `claude-sonnet-4-20250514`
- Temperature: `0.1` (extracción estructurada, no creativa)
- Max tokens: `1500`

---

## El system prompt (anatomía)

El prompt embebido en el nodo "Construir body API" condensa SOUL + SKILL + tablas + 5 ejemplos en ~6 KB:

1. **Identidad y reglas absolutas** (de [`prompts/SOUL_verbex.md`](prompts/SOUL_verbex.md)):
   - Eres VERBEX Tier 2 composites
   - Nunca calculas. Nunca inventas PNs. Detectas AOG y Amendment.
   - Devuelves SOLO JSON.

2. **Tablas autoritativas** (de [`prompts/SKILL_verbex.md`](prompts/SKILL_verbex.md)):
   - 5 clientes con `codigo_erp` y `tier`
   - 7 equivalencias PN cliente → PN proveedor
   - Unidades válidas
   - Banda de confianza por tipo de input

3. **Schema JSON estricto** (spec § 4.4)

4. **5 ejemplos few-shot:**
   - E1 PO estándar Stratos (email PDF)
   - E2 HelionLink CSV (Kairos)
   - E3 AOG alert (cliente sin identificar)
   - E4 Amendment (Rev. B)
   - E5 PN desconocido (confianza baja)

> Los ficheros [`SOUL_verbex.md`](prompts/SOUL_verbex.md) y [`SKILL_verbex.md`](prompts/SKILL_verbex.md) son la **fuente didáctica**: explican el rationale completo. El nodo "Construir body API" embebe la versión condensada que se envía a la API. Si quieres iterar el prompt, edita primero los .md y luego propaga al nodo.

---

## Parser anti-alucinación

El nodo "Validar JSON LLM" hace 4 cosas:

1. **Extrae el JSON** del response: `apiResp.content[0].text.trim()`. Limpia ` ```json ` fences si Claude se desvía y los añade.
2. **Maneja `error: no_pedido`**: si el LLM clasifica como no-PO, el output queda con `estado: "ERROR"` y alerta.
3. **Valida schema mínimo**: `lineas[]` no vacío.
4. **Verifica PN proveedor**: para cada línea, si `part_number_proveedor` no está en el catálogo VBX-COMP, lo fuerza a `null` y añade alerta `PARSER: PN proveedor inventado por el LLM...`.

**Por qué importa la verificación de PN:** los LLMs son creativos. Si el alumno cambia el SOUL y pone "tu objetivo es ser útil", Claude podría inventar un PN razonable cuando no lo encuentra. El parser bloquea esto sistemáticamente.

---

## IO/RE de la sesión

| | |
|---|---|
| **Inputs** | `texto_po` (PO en texto libre) · `ANTHROPIC_API_KEY` configurada como credencial HTTP Header Auth `x-api-key` · catálogo + equivalencias en mirror del prompt |
| **Outputs** | JSON validado contra schema VERBEX, enriquecido por reglas R01–R09 (mismo formato que la salida de II2) |
| **Reglas** | El LLM no calcula precios ni totales (E5) · output siempre JSON · cita obligatoria del PN existente en catálogo (parser bloquea inventos) |
| **Excepciones** | Texto fuera de JSON → parser rechaza · timeout API → `onError: continueErrorOutput` permite ruta de fallback (II4 la usará) · `error: no_pedido` → log + estado ERROR |

---

## Prerrequisitos

- **`ANTHROPIC_API_KEY`** activa con créditos en `.env`.
- Credencial **HTTP Header Auth** en n8n con:
  - Name: `x-api-key`
  - Value: tu `ANTHROPIC_API_KEY`
- Etiquétala con un nombre claro tipo `Anthropic API Key (x-api-key)`.

---

## Cómo correr esta sesión

### 1. Importar el workflow

n8n: **Workflows** → **Import from File** → `workflow_II3.json`.

### 2. Asignar credencial Anthropic

Abrir el nodo `Cognitivo · Llamada Claude API` y asignar la credencial creada (`CREDENTIAL_ANTHROPIC` es placeholder).

### 3. Probar con el caso por defecto

Click **Execute Workflow**. El texto por defecto es el ejemplo E1 (PO Stratos estándar). Output esperado tras pasar por todos los nodos:

```json
{
  "numero_pedido": "PO-2025-STRA-0847",
  "cliente": { "nombre": "Stratos Systems", "tier": "TIER_1", "codigo_erp": "STRA-001" },
  "lineas": [{
    ...
    "part_number_proveedor": "VBX-COMP-4471-B",
    "doc_requerida": ["CoC"],
    "prioridad": "NORMAL"
  }],
  "estado_normalizacion": "COMPLETO",
  "prioridad_calculada": "NORMAL",
  "duplicado": false,
  "alertas": []
}
```

### 4. Probar los otros 4 ejemplos del SKILL

Edita el Set node "Texto de prueba (PO en bruto)" y pega cualquiera de los INPUTs de los ejemplos del SKILL:

- **E2 HelionLink CSV**: `HELIONLINK|HX7-FUS-PNL-331|24|EA|2025-10-01|HX7|KAIRO-001|Normal`
- **E3 AOG**: `URGENT AOG - EC-MKL inmovilizado Aeropuerto Sevilla. Necesitamos HX7-FUS-PNL-332 x2 inmediatamente. Contacto: Juan García 654321098`
- **E4 Amendment**: `PO-2025-STRA-0847 Rev. B. Amendment: cantidad línea 1 cambia de 12 a 8 EA. Nueva Need Date: 30/09/2025.`
- **E5 PN desconocido**: `Pedido 5521. Componente ST9-HTP-RIB-999 x4 EA. Entrega: 01/11/2025.`

Cada uno debería producir un output que coincida con el `OUTPUT` documentado en [`prompts/SKILL_verbex.md`](prompts/SKILL_verbex.md), enriquecido por las reglas R01–R09.

---

## Gate F3 (criterio de cierre de la sesión)

✅ Los 5 ejemplos del SKILL producen el JSON esperado **sin modificación manual del prompt**:

- E1 PO estándar → `estado: COMPLETO`, `confianza ≥ 0.95`, `aog: false`
- E2 HelionLink CSV → `estado: COMPLETO`, `confianza ≥ 0.95`, `aog: false` (criterio 2 spec § 8)
- E3 AOG alert → `aog: true`, alerta AOG en `alertas[]` (criterio 3)
- E4 Amendment → alerta de amendment referenciando el `numero_pedido` original (criterio 4)
- E5 PN desconocido → `estado_normalizacion: "ERROR"` (R04 escala desde PARCIAL del LLM), no error fatal (criterio 5)

**Validación estructural ya realizada:** el JSON del workflow parsea correctamente; los 5 OUTPUTs embebidos en el system prompt parsean como JSON válido (validado en Python).

**Validación funcional pendiente:** ejecutar contra Anthropic API. Esto se hace en clase con la credencial real del alumno. Si un ejemplo no pasa, ajustar SOUL/SKILL es la primera vía (no el parser).

---

## Lo que NO hace este workflow (queda para II4, II5)

- ❌ Recibir input desde Telegram → ese flujo está en II1.
- ❌ Notificar resultado por Telegram → II4.
- ❌ Registrar en Sheets → II4.
- ❌ Enviar email confirmación → II4.
- ❌ Sub-workflows o Error Trigger global → II5.
- ❌ Lookup real de R09 contra Sheets `Pedidos` → II4.

II3 es la **capa cognitiva**: traduce texto libre a estructura validable. La parte de comunicación (qué se notifica y a quién) entra en II4.

---

## Coste por ejecución

Modelo `claude-sonnet-4-20250514` con system prompt de ~6 KB y respuesta de ~600 chars:

- Input tokens: ~1 800 (system) + ~80 (user) = ~1 900
- Output tokens: ~300

Coste aproximado: **~0.012 € por PO procesada**.

En clase con 5 ejemplos × 5 alumnos = ~0.30 € por sesión II3.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Sesión II3*
