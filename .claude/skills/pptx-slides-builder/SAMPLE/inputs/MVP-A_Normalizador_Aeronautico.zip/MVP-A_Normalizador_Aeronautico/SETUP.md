# SETUP.md — Configuración inicial · MVP-A aeronáutico VERBEX

Setup completo para todas las sesiones II1–II6. Ejecutar **una sola vez** antes de empezar.

---

## 1 · Python 3.10+

```powershell
python --version   # debe ser 3.10 o superior
```

Si no está instalado, descargar de [python.org](https://python.org) marcando **"Add Python to PATH"** durante la instalación.

---

## 2 · Node.js 18+ (para n8n)

```powershell
node --version    # debe ser 18 o superior
npm --version
```

Si no está, instalar desde [nodejs.org](https://nodejs.org) (LTS).

---

## 3 · Anthropic API Key

1. Cuenta en [console.anthropic.com](https://console.anthropic.com).
2. **API Keys** → **Create Key** → copiar la clave (`sk-ant-...`).
3. La clave irá en `.env` como `ANTHROPIC_API_KEY`.

Coste aproximado por PO normalizada: ~0.005 € con `claude-sonnet-4-20250514`.

---

## 4 · Bot de Telegram

1. Abrir Telegram, buscar [@BotFather](https://t.me/BotFather).
2. `/newbot` → seguir instrucciones → guardar el **token** (formato `12345:AAA...`).
3. Iniciar conversación con tu propio bot.
4. Obtener tu **chat_id** numérico:
   - Enviar un mensaje al bot
   - Visitar `https://api.telegram.org/bot<TU_TOKEN>/getUpdates`
   - Copiar el campo `chat.id`
5. Necesitas **dos chat_ids** distintos:
   - **`TELEGRAM_CHAT_ID_PRODUCCION`** — recibe alertas AOG y PRIORITARIO
   - **`TELEGRAM_CHAT_ID_CALIDAD`** — recibe alertas CoC y EASA Form 1
   - Para pruebas iniciales pueden ser el mismo (tu propio chat_id).
6. Definir la lista de chat_ids autorizados a enviar pedidos:
   - **`TELEGRAM_ALLOWED_CHAT_IDS`** — separados por comas, ej. `"123456789,234567890,345678901"`

---

## 5 · Google Sheets + Service Account

### 5.1 Crear el Sheet

1. En [Google Drive](https://drive.google.com) → **Nuevo** → **Hoja de cálculo**.
2. Crear **4 hojas** con estos nombres exactos:
   - `Pedidos`
   - `Lineas`
   - `Errores`
   - `Clientes`
3. Estructura de columnas en `II4-Routing_Notificacion/sheets-schema.md` (al cerrar F4).
4. Copiar el **`SHEET_ID`** de la URL: `https://docs.google.com/spreadsheets/d/[SHEET_ID]/edit`.

### 5.2 Service Account

1. Ir a [console.cloud.google.com](https://console.cloud.google.com).
2. Crear proyecto (o usar uno existente).
3. Habilitar **Google Sheets API** y **Google Drive API**.
4. **IAM & Admin** → **Service Accounts** → **Create Service Account**.
5. Tras crearla → **Keys** → **Add Key** → **JSON** → descargar.
6. Copiar el JSON descargado a una ruta segura (ej. `C:\verbex\service-account.json`).
7. **Compartir el Sheet con el email del Service Account** (formato `xxx@xxx.iam.gserviceaccount.com`) con permisos de **Editor**.

### 5.3 Variables de entorno

```
GOOGLE_SHEETS_ID=el_SHEET_ID_de_la_URL
GOOGLE_SERVICE_ACCOUNT_JSON=C:\verbex\service-account.json
```

---

## 6 · SMTP (para email de confirmación)

Cuenta SMTP cualquiera — Gmail con app password, Mailtrap para pruebas, SMTP corporativo, etc.

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=tu_email@gmail.com
SMTP_PASS=la_app_password   # NO la contraseña de Gmail directa
SMTP_FROM="VERBEX Composites <pedidos@verbex.example>"
```

Si usas **Gmail**: hay que crear una **App Password** en [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords) (requiere 2FA activado).

---

## 7 · Archivo `.env`

Desde la raíz del proyecto:

```powershell
copy .env.example .env
```

Editar `.env` y rellenar todas las variables. **Nunca subir este archivo a git** (`.gitignore` ya lo excluye).

---

## 8 · Instalar n8n

```powershell
npm install -g n8n
```

Lanzar:

```powershell
n8n start
```

Abrir [http://localhost:5678](http://localhost:5678) y crear cuenta local.

### Configurar variables de entorno en n8n

**Settings** → **Environment Variables** → añadir todas las del `.env`.

### Configurar credenciales en n8n

**Credentials** → **Add Credential**:

- **Telegram Bot API** → token de @BotFather
- **HTTP Header Auth (Anthropic)** → Name: `x-api-key` · Value: tu `ANTHROPIC_API_KEY`
- **Google Sheets Service Account** → subir el JSON descargado en § 5.2
- **SMTP** → host, puerto, user, pass

---

## 9 · Entornos virtuales Python (por sesión que use Python)

Cada sesión que requiere Python (II5 Nanobot, II6 dashboard) tiene su propio `requirements.txt`:

```powershell
# Desde la carpeta de la sesión, ej. II6-MVP_Completo/dashboard/
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

---

## 10 · Verificación rápida

```powershell
python -c "import streamlit; print('streamlit OK')"
python -c "import anthropic; print('anthropic OK')"
python -c "import gspread; print('gspread OK')"
node --version
n8n --version
```

Si todas las líneas imprimen OK / versión, el setup está completo.

---

## Nota sobre rutas en Windows

Las apps Python usan rutas relativas (`Path(__file__).parent`). Ejecutar siempre desde la carpeta del módulo:

```powershell
cd CONTENT\MVP-A_Normalizador_Aeronautico\II6-MVP_Completo\dashboard
streamlit run app.py
```

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Setup*
