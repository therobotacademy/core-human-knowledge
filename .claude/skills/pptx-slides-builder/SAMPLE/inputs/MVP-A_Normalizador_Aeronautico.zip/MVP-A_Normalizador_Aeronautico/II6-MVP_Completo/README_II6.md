# II6 — MVP Completo

**Sesión:** Parte 2 · Módulo II6
**Idea fuerza del módulo:** *"El MVP detecta + sintetiza + distribuye sin humano."*
**PRDA:** ciclo completo end-to-end
**Tiempo en clase:** 2,5 h

---

## ¿Qué se construye?

Cierre del proyecto vertebrador. Tres bloques:

1. **Workflow MVP final** importable en n8n (`workflow_II6_mvp.json`), con `errorWorkflow` configurado apuntando al Error Trigger de II5.
2. **Streamlit dashboard read-only** (`dashboard/app.py`) que muestra el estado del agente leyendo Google Sheets.
3. **Despliegue Windows** (`deploy/start_verbex.bat` + Task Scheduler) para que el MVP arranque automáticamente al iniciar sesión.
4. **Brief del proyecto del alumno** (`proyecto-alumno/`) — adaptar el patrón a otro dominio.

---

## Anatomía de la sesión (2,5 h)

| Bloque | Tiempo | Foco |
|---|---|---|
| 1. Demo del MVP completo | 30 min | El instructor lanza una PO real y muestra el ciclo end-to-end |
| 2. Importar y configurar el workflow MVP | 30 min | Cada alumno tiene el suyo en n8n con sus credenciales |
| 3. Lanzar Streamlit dashboard | 30 min | Setup gspread + verificar lectura de Sheets |
| 4. Deploy con Task Scheduler | 30 min | Configurar `start_verbex.bat` + arranque automático |
| 5. Brief del proyecto del alumno | 20 min | Lectura del [README del proyecto](proyecto-alumno/README.md) |
| 6. Cierre y siguientes pasos | 10 min | Q&A, calendario de entrega |

---

## Artefactos

### `workflow_II6_mvp.json`

Versión final del workflow. Equivalente a `workflow_II4.json` con dos diferencias:

1. **`errorWorkflow` setting** apunta a `workflow_II5_error_trigger.json` — fallos van a Sheets `Errores` + Telegram.
2. **Sticky note de cabecera** explicando que es el MVP final y cómo se diferencia del master refactorizado de II5.

Es el monolito runnable. El alumno que hizo el refactor de II5 puede usar `workflow_II5_master.json` en su lugar; el alumno que no lo hizo usa éste.

### `dashboard/app.py`

255 líneas. Streamlit dashboard read-only:

- **Header** branded VERBEX (paleta corporativa).
- **Sidebar** con filtros: programa (HX7/ST900/RT55/VX4) · estado · prioridad · solo AOG · solo POs de hoy.
- **5 KPIs**: POs totales · POs hoy · AOGs activos · tasa de éxito · errores 7 días.
- **Tab "Últimas POs"**: tabla con últimas 50 POs filtradas + selector para ver líneas de una PO concreta.
- **Tab "Top clientes & productos"**: top 5 clientes (por # POs) + top 5 productos (por cantidad total).
- **Tab "Errores recientes"**: tabla con los últimos errores registrados.

Cache de Sheets a 60s para reducir API calls. Lee con `gspread.service_account()` usando la ruta del JSON desde `.env`.

**No escribe en Sheets.** No permite confirmar pedidos manualmente (default D2 spec § 10).

### `dashboard/requirements.txt`

```
streamlit>=1.30.0
gspread>=6.0.0
pandas>=2.0.0
python-dotenv>=1.0.0
```

### `deploy/start_verbex.bat`

Lanza 3 procesos cada uno en su propia ventana cmd:

1. n8n (`http://localhost:5678`)
2. Streamlit dashboard (`http://localhost:8501`)
3. Nanobot opcional (Telegram nativo) — comentado por defecto, descomentar para activar.

Diseñado para ejecución desde Task Scheduler tras login.

### `deploy/task-scheduler.md`

Guía paso a paso para configurar Windows Task Scheduler:

- Crear tarea `VERBEX MVP arranque`
- Trigger: At log on, delay 30s
- Action: ejecutar `start_verbex.bat`
- Settings: reintento 3 veces, no duplicar instancia
- Sección de troubleshooting con problemas comunes (PATH distinto, n8n lento, dashboard error de Service Account)

### `deploy/README_deploy.md`

Guía operativa diaria:

- Estructura de carpetas en producción
- Setup inicial por máquina (clonar, .env, venv, n8n install, Task Scheduler)
- Workflows a importar **en orden**: Error Trigger primero (para tener su ID), luego MVP, opcionalmente master refactorizado.
- Operación diaria: mañana / cuando llega un pedido / final del día
- Troubleshooting frecuente
- Métricas a vigilar
- Procedimientos: añadir cliente, añadir PN, rotar credenciales
- Backup mínimo

### `proyecto-alumno/README.md`

Brief del proyecto del alumno con:

- 4 dominios sugeridos: mantenimiento programado · NCR (no conformidades) · stock crítico · dominio propio
- Entregables mínimos (7 obligatorios) y opcionales
- Cómo empezar (8 pasos)
- Tiempo estimado por etapa (~4–6 h)
- Patrones a reusar literal vs adaptar
- FAQs

### `proyecto-alumno/checklist.md`

Criterios de evaluación con pesos. Bloque obligatorio (mínimo aprobar) + bloque opcional (sube nota). Antipatrones que penalizan. Formato de entrega.

---

## IO/RE de la sesión

| | |
|---|---|
| **Inputs** | `workflow_II4.json` ya funcional (de F4) · `workflow_II5_error_trigger.json` (de F5) · entorno Windows · venv Python con `requirements.txt` instalado · Sheets pobladas con datos de test |
| **Outputs** | MVP corriendo autónomo · dashboard accesible en `localhost:8501` · `start_verbex.bat` arranca todo con doble clic · brief del proyecto entregado al alumno |
| **Reglas** | El MVP debe detectar + sintetizar + distribuir sin humano para ser válido (criterios spec § 8) |
| **Excepciones** | MVP parcial → documentar qué funciona y qué queda pendiente con criterios claros |

---

## Cómo correr esta sesión (paso a paso)

### Bloque 1 · Demo (30 min)

Instructor en pantalla compartida:

1. Abre n8n con el MVP activo.
2. Abre el dashboard.
3. Abre Telegram con el bot de demo.
4. Envía mensaje al bot: *"Purchase Order PO-2025-STRA-0847. Stratos Systems. ST9-HTP-RIB-047, 12 EA, Need Date 15/09/2025. CoC required."*
5. Muestra:
   - Mensaje aparece en n8n Executions (~3-5 s).
   - Telegram al canal calidad llega (CoC required).
   - Email al cliente Stratos llega.
   - Fila aparece en Sheets `Pedidos` y `Lineas`.
   - Dashboard se refresca y muestra la PO.
6. Envía mensaje AOG: *"URGENT AOG - EC-MKL inmovilizado..."*
7. Telegram producción llega < 5 s.
8. Cierra demo: "esto es lo que vais a tener corriendo en vuestro PC al final de la sesión".

### Bloque 2 · Importar workflow MVP (30 min)

1. Cada alumno importa `workflow_II5_error_trigger.json` y copia su ID.
2. Cada alumno importa `workflow_II6_mvp.json`.
3. Settings → Error Workflow → seleccionar el Error Trigger del paso 1.
4. Asignar 4 credenciales (Anthropic, Sheets Service Account, Telegram, SMTP).
5. Activar el workflow.
6. Test con un mensaje al bot.

### Bloque 3 · Streamlit dashboard (30 min)

1. Crear venv en `dashboard/`:
   ```powershell
   cd II6-MVP_Completo\dashboard
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Verificar `.env` raíz tiene `GOOGLE_SHEETS_ID` y `GOOGLE_SERVICE_ACCOUNT_JSON`.
3. Lanzar:
   ```powershell
   streamlit run app.py
   ```
4. Abrir `http://localhost:8501` y ver las POs procesadas en bloque 2.

### Bloque 4 · Deploy con Task Scheduler (30 min)

1. Probar `deploy/start_verbex.bat` con doble clic. Verificar que las 3 ventanas abren.
2. Seguir [`deploy/task-scheduler.md`](deploy/task-scheduler.md) paso a paso.
3. Cerrar sesión Windows y volver a iniciar. Esperar 30s. Verificar arranque automático.

### Bloque 5 · Brief proyecto alumno (20 min)

1. Lectura colectiva de [`proyecto-alumno/README.md`](proyecto-alumno/README.md).
2. Cada alumno declara su dominio elegido (puede cambiarlo después).
3. Q&A breve.

### Bloque 6 · Cierre (10 min)

- Recordatorio de plazo de entrega.
- Cómo contactar al instructor para dudas.
- Calendario de revisión de proyectos.

---

## Gate F6 (criterio de cierre del MVP)

✅ **Estructural:**
- `workflow_II6_mvp.json` parseable: 27 nodos (incluido sticky header), 20 conexiones, errorWorkflow setting.
- `dashboard/app.py` AST válido: 255 líneas.
- `start_verbex.bat`, `task-scheduler.md`, `README_deploy.md`, `proyecto-alumno/README.md`, `proyecto-alumno/checklist.md` completos.

✅ **Funcional (en clase con credenciales reales):**
- Bot Telegram dispara workflow MVP (criterio 1 spec § 8).
- POs registradas en Sheets `Pedidos` + `Lineas` (criterio 7).
- Dashboard muestra últimas 50 POs con filtros por programa y estado (criterio 10).
- `start_verbex.bat` arranca pipeline completo con doble clic (criterio 12).
- 14/14 criterios spec § 8 pasan en F7.

---

## Coste mensual estimado del MVP en producción

Con ratio 50 POs/día (~1500/mes):

| Componente | Coste mensual |
|---|---|
| Anthropic Claude API | ~20 € |
| Google Sheets | gratis |
| Telegram Bot | gratis |
| SMTP (Gmail / cuenta propia) | gratis |
| n8n self-hosted | gratis |
| **Total** | **~20 €/mes** |

A precio comercial de un servicio similar (Mailparser, etc.): 50–100 €/mes. **Margen ~3-5x para hacer el sistema rentable internamente.**

---

## Lo que viene después (post-curso)

El MVP-A es un punto de partida. Mejoras candidatas para v2:

1. **Cache LLM** para POs textualmente idénticas (~30% menos coste).
2. **Validación de fecha plausible** (R10): rechazar fechas en pasado o > 2 años en futuro.
3. **Detección de Amendment** con regex previo al LLM (~50% menos tokens en ese caso).
4. **Integración real con HelionLink** (no simulación por copy-paste).
5. **Webhook desde portal Kairos** en lugar de email manual.
6. **Métricas de rendimiento del agente**: precisión por cliente, latencia, tasa de errores.
7. **Migración de Sheets a base de datos** (Postgres/SQLite) si la cardinalidad supera 10K POs.
8. **Multi-tenant**: replicar el patrón para otras 3-4 empresas Tier 2 con mismas necesidades.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Sesión II6 · Cierre del proyecto vertebrador*
