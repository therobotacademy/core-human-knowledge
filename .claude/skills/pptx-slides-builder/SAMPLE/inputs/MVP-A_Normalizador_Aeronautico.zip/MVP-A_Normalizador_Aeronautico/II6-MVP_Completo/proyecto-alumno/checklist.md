# Checklist de Evaluación · Proyecto del Alumno

Para auto-evaluar antes de entregar y para que el instructor evalúe la entrega.

---

## Bloque obligatorio (mínimo para aprobar)

### 1. Schema JSON (15%)

- [ ] Schema documentado en README.
- [ ] Todos los campos del schema tienen tipo declarado (string, number, boolean, ISO date, etc.).
- [ ] Indica qué campos son obligatorios y cuáles opcionales (`null`).
- [ ] Diferenciación entre datos extraídos por el LLM y datos calculados por reglas (ej. `prioridad_calculada` vs `prioridad`).

### 2. Tablas del dominio

- [ ] `catalogo.csv` con ≥ 10 entradas.
- [ ] `actores.csv` (clientes / técnicos / usuarios autorizados) con ≥ 3 entradas.
- [ ] Encoding UTF-8 con BOM (Excel-friendly).
- [ ] Cabeceras claras y consistentes con lo que usa el SOUL.

### 3. SOUL.md (10%)

- [ ] Identidad del agente (quién es, para qué empresa).
- [ ] Lista numerada de reglas absolutas (mínimo 5).
- [ ] Schema JSON declarado dentro del SOUL.
- [ ] Manejo de "no pertinente" (qué hacer si el input no es del tipo esperado).

### 4. SKILL.md (10%)

- [ ] Pasos procedurales de extracción.
- [ ] Tablas del dominio (catálogo + actores) embebidas.
- [ ] **Mínimo 3 ejemplos few-shot** con INPUT y OUTPUT JSON completos.
- [ ] Los 3 ejemplos cubren casos distintos (no son variaciones del mismo).

### 5. Workflow n8n (25%)

- [ ] Importable en n8n local (JSON parseable).
- [ ] Trigger Telegram (o equivalente) configurado.
- [ ] Llamada al LLM con system prompt construido a partir de SOUL+SKILL.
- [ ] Parser anti-alucinación que valida el JSON output del LLM.
- [ ] Mínimo 3 reglas deterministas implementadas como Code nodes.
- [ ] Salida que escribe en Sheets, archivo, o sistema externo.
- [ ] El workflow se ejecuta sin error con al menos 1 ejemplo.

### 6. Reglas deterministas (15%)

- [ ] Reglas implementadas en Code nodes JS (no en el LLM).
- [ ] Cada regla tiene un nombre identificativo (R01, R02...).
- [ ] Documentadas en README: qué condición evalúan, qué hacen.
- [ ] Validable: una regla activa = output diferente.

### 7. Routing condicional (10%)

- [ ] Mínimo un Switch o Filter que ramifique según un campo del JSON.
- [ ] Resultado de cada rama es distinto (ej. notificar canal A vs canal B).
- [ ] Caso "no aplica" (ej. NORMAL) documentado y posiblemente sin acción.

### 8. README del proyecto (10%)

- [ ] Resumen del dominio elegido y por qué.
- [ ] Diagrama o lista de capas (Ingesta → Cognitivo → Lógica → Routing).
- [ ] **IO/RE de cada capa**:
  - Inputs (qué necesita)
  - Outputs (qué produce)
  - Reglas (condiciones invariantes)
  - Excepciones (qué hace si algo va mal)
- [ ] Cómo correr el proyecto (paso a paso).
- [ ] Qué decisiones tomaste y qué dejaste fuera.

---

## Bloque opcional (sube nota)

### 9. Polish técnico (3%)

- [ ] Naming consistente (snake_case o camelCase, no mezclado).
- [ ] Comentarios mínimos pero claros.
- [ ] Sin secrets en git (`.gitignore` correcto).
- [ ] Variables de entorno en `.env.example` documentadas.

### 10. Capa de notificación (2%)

- [ ] Mensaje Telegram con formato legible al usuario.
- [ ] Email (si aplica) con HTML básico.

### 11. Capa de observabilidad (extras)

- [ ] Streamlit dashboard que lea Sheets.
- [ ] Logs de errores capturados con Error Trigger.
- [ ] Alternativa Python (script standalone que reproduzca el flujo).

### 12. Deploy (extras)

- [ ] `start_*.bat` que arranque todo con doble clic.
- [ ] Task Scheduler configurado (capturas de pantalla).

---

## Antipatrones a EVITAR (penalizan)

❌ **El LLM calcula valores numéricos.** Si tu prompt pide "calcula el porcentaje de avance del proyecto", está mal. Eso lo hace código determinista. (-15%)

❌ **No hay parser anti-alucinación.** Si el LLM dice "el código es XYZ-9999" y tu workflow lo guarda sin validar contra catálogo, falla criterio E5. (-10%)

❌ **Schema JSON inconsistente.** Si los 3 ejemplos del SKILL no cumplen el schema declarado, los alumnos copian inconsistencias y el agente falla. (-10%)

❌ **Sin diferenciación capa cognitiva vs determinista.** Si todo está en un mega-prompt o todo en código sin LLM, no estás aplicando el patrón del curso. (-15%)

❌ **Documentación pobre.** Sin README claro, el evaluador no puede correr tu proyecto = no aprobado. (-20%)

---

## Criterio de polish (qué hace que un proyecto destaque)

✅ Caso de uso real, profesional, no inventado.
✅ El agente resuelve un problema concreto de tu día a día (o del de un colega).
✅ Las 3 ejemplos few-shot son del mundo real (anonimizados si es necesario).
✅ El SOUL tiene reglas absolutas que demuestran entendimiento del dominio (no copias VERBEX).
✅ La capa de routing tiene lógica de negocio justificada (no es un Switch genérico).
✅ El README explica el "por qué" además del "qué".
✅ Polish visual: diagrama, tabla de equivalencias, mock del email, etc.

---

## Formato de entrega

Opción A · **GitHub repo público o privado** (preferido):

- Estructura idéntica al MVP-A VERBEX.
- README en la raíz.
- Compartir enlace al repo + permiso de lectura al instructor.

Opción B · **ZIP**:

- Estructura completa.
- README en la raíz.
- Sin `__pycache__`, sin `.env`, sin `node_modules`.

Plazo: cierre del curso (ver calendario COIIAOC).

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Checklist de evaluación*
