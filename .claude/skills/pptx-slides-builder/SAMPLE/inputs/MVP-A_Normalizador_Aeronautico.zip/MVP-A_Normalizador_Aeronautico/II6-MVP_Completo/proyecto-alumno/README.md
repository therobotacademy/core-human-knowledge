# Proyecto del Alumno · MVP propio en otro dominio aeronáutico

**Curso:** Automatización de Procesos con Agentes Inteligentes · COIIAOC · Parte 2
**Entrega:** al cierre del curso
**Tiempo estimado:** 4–6 h fuera de clase

---

## Brief

Has construido el MVP-A para VERBEX (normalizador de POs Tier 2 composites). Ahora vas a **adaptar el mismo recetario a otro dominio** dentro del sector aeronáutico (o de otro sector industrial si te encaja mejor profesionalmente).

El objetivo no es construir algo distinto: es demostrar que **el patrón se transfiere**. Texto libre → LLM con SOUL/SKILL → JSON validado → reglas deterministas → notificación + registro.

---

## Dominios sugeridos

Elige uno (o propón el tuyo):

### A. Mantenimiento programado (preventive maintenance scheduling)

El técnico de mantenimiento envía partes por Telegram al final de cada intervención:

> *"Cambio de filtro hidráulico en máquina M-12 línea L-04. Tiempo: 2.5h. Pieza usada: FLT-HID-5210. Próxima revisión: en 200h o 30 días, lo que llegue antes."*

**Schema:** parte de mantenimiento estructurado con `equipo`, `tipo_intervencion`, `tiempo`, `pieza_usada`, `proxima_revision_horas`, `proxima_revision_dias`.

**Reglas R01-R09 candidatas:**
- R01 Si `prioridad: "URGENTE"` → notificar inmediato.
- R02 Si `proxima_revision_dias ≤ 7` → flag para programación.
- R03 Si `pieza_usada` no en catálogo → ERROR.
- R04 Si `tiempo > 8h` → revisar (intervención larga, posible problema).
- R05 Si requiere certificación de calibración → notificar.
- R09 Anti-spam por `numero_parte` repetido.

### B. Gestión de no conformidades (NCR · Non-Conformance Reports)

Inspector de calidad reporta hallazgos:

> *"NCR-2026-0457. Pieza VBX-COMP-3301-A lote L-2026-W14: porosidad en zona B mayor a tolerancia (0.8mm vs spec 0.5mm). 2 unidades afectadas. Severidad: alta. Notificar a producción y cliente."*

**Schema:** NCR estructurada con `lote`, `pieza_afectada`, `tipo_no_conformidad`, `severidad`, `cantidad_afectada`, `accion_recomendada`.

### C. Control de stock crítico (kanban-style alerts)

Operador reporta nivel de stock por Telegram:

> *"Stock RR-6205: 12 unidades. Consumo medio: 8/día. Estimación 1.5 días."*

**Schema:** alerta de stock con `referencia`, `stock_actual`, `consumo_medio`, `dias_estimados`.

**Reglas:**
- Si `dias_estimados < 3` → notificar AOG-equivalente.
- Si `dias_estimados < 7` → notificar PRIORITARIO.

### D. Tu propio dominio

Si trabajas en un sector distinto, propón tu caso. Criterios para que sea adecuado:

- Texto libre como entrada.
- Conjunto cerrado de "cosas" reconocibles (catálogo / lista finita).
- Reglas de negocio deterministas claras.
- Salida estructurada útil.
- Necesidad de notificación condicional.

---

## Entregables

Tu proyecto debe entregar como mínimo:

1. **`data/catalogo.csv`** — la lista finita de tu dominio (≥ 10 entradas).
2. **`data/clientes.csv`** o equivalente — los actores autorizados a enviar inputs (≥ 3 entradas).
3. **Schema JSON de salida** documentado (idem spec § 4.4 VERBEX).
4. **`SOUL.md` y `SKILL.md`** adaptados al dominio (con ≥ 3 ejemplos few-shot).
5. **`workflow.json`** importable en n8n que implemente el pipeline mínimo: trigger → LLM → reglas → registro.
6. **README con IO/RE de cada capa** (Ingesta · Cognitivo · Lógica · Routing).
7. **3 ejemplos de input + output esperado** para validar el agente.

Entregables opcionales (suben nota):

- 8. Reglas R01–Rxx implementadas como nodos deterministas.
- 9. Routing condicional (Switch o Filter).
- 10. Notificaciones por Telegram a 1+ canales.
- 11. Dashboard Streamlit.
- 12. Deploy Windows con `start_*.bat`.

---

## Cómo empezar

1. **Elige dominio** y escribe **una frase de input** que el agente recibirá. Ej: *"NCR-2026-0457. Pieza VBX-COMP-3301-A..."*
2. **Diseña el schema JSON** que tu agente debe extraer de esa frase.
3. **Crea las tablas** (catálogo + clientes/actores). Mínimo viable: 10 + 3 entradas.
4. **Adapta el SOUL** desde `II3-LLM_Semantico/prompts/SOUL_verbex.md`. Cambia el dominio, mantén la estructura (identidad + 7 reglas absolutas + manejo de no-pertinente).
5. **Adapta el SKILL** desde `II3-LLM_Semantico/prompts/SKILL_verbex.md`. Cambia tablas y crea **3 ejemplos few-shot** para tu dominio.
6. **Reusa el workflow_II3 o II4** y modifica los Code nodes para usar tus tablas en vez de las de VERBEX.
7. **Prueba con tus 3 ejemplos** y compara con el output esperado.
8. **Documenta** en README qué decisiones tomaste y qué quedó fuera.

---

## Criterios de evaluación

Ver [`checklist.md`](checklist.md). Resumen:

| Aspecto | Peso |
|---|---|
| Schema JSON bien definido | 15% |
| SOUL/SKILL adaptados con ejemplos few-shot | 20% |
| Workflow importable y funcional | 25% |
| Reglas deterministas separadas del LLM (E5) | 15% |
| Routing condicional implementado | 10% |
| README con IO/RE claro | 10% |
| Polish y extras | 5% |

**Mínimo para aprobar:** entregables 1–6 del listado arriba.

---

## Tiempo estimado por etapa

| Etapa | Tiempo |
|---|---|
| Elegir dominio + diseñar schema | 30–45 min |
| Crear tablas (catálogo + actores) | 30 min |
| Adaptar SOUL + SKILL con 3 ejemplos | 60–90 min |
| Adaptar workflow n8n | 60–90 min |
| Probar y iterar prompts | 30–60 min |
| Documentar README | 30 min |
| **Total** | **~4–6 h** |

---

## Patrones que debes reusar (no reinventar)

✅ **Reusar literal:**
- Estructura de `SOUL.md`: identidad + reglas absolutas + esquema + manejo de no-pertinente.
- Estructura de `SKILL.md`: pasos + tablas + ejemplos few-shot.
- Patrón "el LLM no calcula, las reglas R01–R09 son deterministas en n8n".
- Patrón Switch para routing por prioridad.
- Patrón Filter para condiciones independientes.
- Parser anti-alucinación (validar que `codigo` o `referencia` exista en catálogo).

❌ **Adaptar:**
- Tablas (catálogo, actores).
- Reglas concretas R01–R09.
- Schema JSON (campos del dominio).
- Nombres de canales Telegram.
- Plantilla de email.

---

## Inspiración: las 5 partes del MVP-A VERBEX como template

Tu proyecto puede tener (no es obligatorio) las mismas 5 capas que VERBEX:

```
Trigger Telegram → Ingesta + lookup actor → LLM con SOUL/SKILL → Reglas R01-Rxx → Routing condicional → Sheets + Notify + Email
```

O puede simplificar (omitir email, dashboard) según tu caso.

---

## Preguntas frecuentes

**P: ¿Puedo cambiar de Telegram a WhatsApp Business?**
R: Sí, pero más complejo (requiere cuenta WhatsApp Business y webhook). Para Parte 2 recomendado quedarse con Telegram. WhatsApp es candidato post-MVP.

**P: ¿Necesito Streamlit o me basta con Sheets?**
R: Sheets es suficiente para aprobar. Streamlit es bonus.

**P: ¿Pueden ser sólo 5 reglas en lugar de 9?**
R: Sí. Lo importante es que existan reglas deterministas separadas del LLM, no la cantidad.

**P: ¿Puedo usar Gemini o GPT-4 en lugar de Claude?**
R: Sí, lo importante es el patrón. Pero el system prompt y la API call cambian — más trabajo de adaptación.

**P: ¿Cuándo entregar?**
R: Al cierre del curso. Formato: enlace a tu repo GitHub o ZIP con los entregables.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Brief proyecto del alumno*
