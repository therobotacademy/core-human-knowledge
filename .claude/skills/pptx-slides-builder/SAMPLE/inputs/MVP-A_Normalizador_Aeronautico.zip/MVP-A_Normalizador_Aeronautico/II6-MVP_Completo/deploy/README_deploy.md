# Deploy · Operación diaria del MVP

Guía operativa para mantener el agente VERBEX corriendo en producción.

---

## Arquitectura desplegada

```
PC de back-office VERBEX (Windows 10/11)
│
├── Proceso 1: n8n           → http://localhost:5678   (motor de workflows)
├── Proceso 2: Streamlit     → http://localhost:8501   (dashboard read-only)
└── Proceso 3: Nanobot       → Telegram nativo         (opcional, alternativa Python)
```

Los 3 procesos se lanzan automáticamente al iniciar sesión vía Task Scheduler (ver [`task-scheduler.md`](task-scheduler.md)).

---

## Estructura de carpetas en producción

```
C:\verbex\MVP-A_Normalizador_Aeronautico\
│
├── .env                                ← credenciales reales (NUNCA en git)
├── data\
│   ├── catalogo.csv
│   ├── clientes.csv
│   └── equivalencias_pn.csv
│
├── II6-MVP_Completo\
│   ├── workflow_II6_mvp.json           ← workflow importado en n8n
│   ├── dashboard\
│   │   ├── app.py
│   │   ├── requirements.txt
│   │   └── venv\                       ← entorno virtual Python (creado en setup)
│   └── deploy\
│       ├── start_verbex.bat
│       ├── task-scheduler.md
│       └── README_deploy.md
│
└── II5-Resiliencia_Alternativas\nanobot\   (si se usa Nanobot opcional)
    ├── config.json                     ← config real (NUNCA en git)
    ├── nanobot_verbex.py
    └── workspace\
        └── ...
```

---

## Setup inicial (una sola vez por máquina)

1. Clonar el proyecto a `C:\verbex\MVP-A_Normalizador_Aeronautico\` (sin caracteres especiales en la ruta).
2. Crear `.env` desde `.env.example` y rellenar todas las variables (ver `SETUP.md` raíz).
3. Crear venv del dashboard:
   ```powershell
   cd C:\verbex\MVP-A_Normalizador_Aeronautico\II6-MVP_Completo\dashboard
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. Instalar n8n globalmente: `npm install -g n8n`.
5. Importar workflows en n8n (ver § "Workflows a importar" abajo).
6. Configurar Task Scheduler (ver `task-scheduler.md`).
7. Test manual: doble clic en `start_verbex.bat`. Verificar que las 3 ventanas abren correctamente.

---

## Workflows a importar en n8n

Importar **en este orden**:

1. **`II5-Resiliencia_Alternativas/workflow_II5_error_trigger.json`** primero
   → copiar el ID del workflow tras importar.

2. **`II6-MVP_Completo/workflow_II6_mvp.json`**
   → en Settings → Error Workflow, seleccionar el Error Trigger del paso 1.

3. (Opcional) **`II5-Resiliencia_Alternativas/workflow_II5_master.json`** y los 4 sub-workflows si has hecho el refactor de II5.

Para cada uno: asignar credenciales (Anthropic, Sheets, Telegram, SMTP) y activar el workflow (toggle Active).

---

## Operación diaria

### Mañana

1. Encender el PC → Task Scheduler arranca los 3 procesos en ~30 s.
2. Abrir el dashboard: [http://localhost:8501](http://localhost:8501).
3. Verificar que la **última PO** aparece con timestamp reciente.
4. Si lleva > 24 h sin POs, comprobar que el bot Telegram responde (ping de prueba).

### Cuando llega un pedido

1. El cliente envía mensaje al bot por Telegram.
2. n8n procesa automáticamente: parser → reglas → Sheets + notificaciones.
3. Si la PO es **AOG** o **PRIORITARIO**, llega Telegram al jefe de producción.
4. Si tiene **CoC** o **EASA Form 1**, llega Telegram al responsable de calidad.
5. El cliente recibe email de confirmación HTML.
6. Operador back-office abre dashboard cuando le interesa: ver últimas POs, top clientes, errores.

### Final del día

1. Revisar `Errores` en dashboard. Si > 5 errores/día, escalar.
2. Verificar tasa de éxito (% COMPLETO). Si < 90%, revisar SOUL/SKILL.
3. Backup manual de Sheets (descarga `.xlsx`) — opcional, recomendado los viernes.

---

## Troubleshooting frecuente

### "El bot Telegram no responde"

1. Comprobar ventana cmd `VERBEX n8n`: ¿hay errores en los últimos logs?
2. En n8n UI → workflow `VERBEX · II6 MVP` → ¿está Active (toggle verde)?
3. Test manual: enviar mensaje al bot. ¿Aparece la ejecución en n8n → Executions?

### "El dashboard muestra 'Sin datos'"

1. Comprobar Sheet manualmente: ¿hay filas en hoja `Pedidos`?
2. Comprobar `.env`: ¿`GOOGLE_SHEETS_ID` apunta al Sheet correcto?
3. Comprobar permisos: ¿el Service Account tiene Editor sobre el Sheet?

### "Anthropic devuelve 401"

API key caducada o sin créditos. Revisar [console.anthropic.com](https://console.anthropic.com) → API Keys.

### "SMTP error en email confirmación"

App password caducada (Gmail rota cada N días). Crear nueva en [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords) y actualizar `.env`.

### "Sheets API rate limit"

Demasiadas POs por minuto. Solución temporal: pausar 60 s. Si es persistente, considerar batch insert o migrar a base de datos.

### "n8n no arranca tras reinicio"

Comprobar Task Scheduler → `VERBEX MVP arranque` → última ejecución. Si dice "Task failed", revisar History tab para detalle.

---

## Métricas a vigilar

| Métrica | Valor target | Cómo medirla |
|---|---|---|
| **Tasa de éxito** | ≥ 90% | Dashboard KPI "Tasa de éxito" |
| **Latencia AOG** | < 5 s | Dashboard error log + timestamps Telegram |
| **Coste mensual Anthropic** | < 50 € | console.anthropic.com → Billing |
| **Errores 7 días** | < 5 | Dashboard tab "Errores" |
| **Tiempo respuesta dashboard** | < 3 s | Subjetivo, refresh manual |

---

## Escalado y mantenimiento

### Cuando añadir un cliente nuevo

1. Editar `data/clientes.csv` con la fila nueva.
2. Editar el Code node "R07" del workflow_II6 (o sub-workflow Logica) — añadir `codigo_erp` a `CLIENTES_REGISTRADOS`.
3. Editar el SOUL prompt en el Code node "Construir body API" — añadir el cliente a la tabla.
4. Si tiene chat_id distinto, añadir a `TELEGRAM_ALLOWED_CHAT_IDS` en `.env`.
5. Re-deploy: cerrar `VERBEX n8n` y relanzar `start_verbex.bat`.

### Cuando añadir un PN nuevo al catálogo

1. Editar `data/catalogo.csv`.
2. Si tiene equivalencia con un PN cliente, editar `data/equivalencias_pn.csv`.
3. Editar el system prompt (tabla EQUIVALENCIAS PN) y los Code nodes que validan PNs.
4. Re-deploy.

### Cuando rotar credenciales

1. Anthropic API key: cada 6 meses según gobernanza.
2. Telegram bot token: tras pruebas o ante sospecha de leak.
3. SMTP password: según política corporativa.
4. Service Account JSON: si se sospecha compromiso.

Para cada uno: actualizar `.env` y reiniciar el MVP. Las credenciales en n8n se actualizan vía UI (Credentials → Edit).

---

## Backup

Backup mínimo recomendado (semanal):

1. **Google Sheet `VERBEX-Pedidos`**: File → Download → `.xlsx`. Guardar en NAS o Drive personal.
2. **`.env`**: copia cifrada en password manager.
3. **`workflow_*.json`**: ya en git (`dev/mvp-a-code` branch).
4. **`config.json` Nanobot** (si se usa): copia cifrada.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Operación diaria*
