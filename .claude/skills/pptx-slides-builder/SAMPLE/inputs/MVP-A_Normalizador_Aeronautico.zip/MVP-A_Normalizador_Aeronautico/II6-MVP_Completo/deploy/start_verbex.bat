@echo off
REM ===================================================================
REM VERBEX MVP · Arranque del agente normalizador
REM ===================================================================
REM Lanza los 3 procesos del MVP:
REM   1. n8n  (motor de workflows)        → http://localhost:5678
REM   2. Streamlit dashboard (read-only)  → http://localhost:8501
REM   3. Nanobot agent (opcional)         → Telegram nativo
REM
REM Cada uno en su propia ventana cmd.exe para que el operador pueda
REM verlos y cerrarlos individualmente.
REM
REM Uso: doble clic sobre este .bat (o lanzado desde Task Scheduler).
REM ===================================================================

setlocal

set "PROYECTO_ROOT=%~dp0..\.."
set "DASHBOARD_DIR=%~dp0..\dashboard"
set "NANOBOT_DIR=%~dp0..\..\II5-Resiliencia_Alternativas\nanobot"

echo.
echo ===================================================================
echo   VERBEX MVP · arranque
echo   Proyecto root: %PROYECTO_ROOT%
echo ===================================================================
echo.

REM --- 1. n8n ---------------------------------------------------------
echo [1/3] Lanzando n8n...
start "VERBEX n8n" cmd /k "n8n start"
timeout /t 8 /nobreak > nul

REM --- 2. Streamlit dashboard -----------------------------------------
echo [2/3] Lanzando Streamlit dashboard...
start "VERBEX Dashboard" cmd /k "cd /d %DASHBOARD_DIR% && streamlit run app.py"
timeout /t 4 /nobreak > nul

REM --- 3. Nanobot (OPCIONAL — descomenta para activar) ----------------
REM echo [3/3] Lanzando Nanobot agent...
REM start "VERBEX Nanobot" cmd /k "cd /d %NANOBOT_DIR% && nanobot --config config.json"
REM timeout /t 4 /nobreak > nul

echo.
echo ===================================================================
echo   VERBEX MVP arrancado.
echo.
echo   - n8n:        http://localhost:5678
echo   - Dashboard:  http://localhost:8501
echo   - Nanobot:    desactivado (ver línea NANOBOT en este .bat)
echo ===================================================================
echo.
echo Pulsa una tecla para cerrar esta ventana de log
echo (los 3 procesos siguen corriendo en sus propias ventanas).
pause > nul
endlocal
