# Task Scheduler · Arranque automático del MVP en Windows

Configura Windows Task Scheduler para que el MVP arranque automáticamente al iniciar sesión. Permite que el agente esté operativo sin que nadie tenga que abrir n8n manualmente cada mañana.

---

## Pre-requisitos

- ✅ `start_verbex.bat` probado manualmente (doble clic) y los 3 procesos arrancan correctamente.
- ✅ n8n instalado globalmente (`npm install -g n8n`) — disponible en PATH.
- ✅ Streamlit instalado en venv del dashboard o globalmente.
- ✅ Python 3.10+ en PATH.
- ✅ `.env` con todas las variables de entorno completadas.

---

## Paso 1 · Abrir Task Scheduler

1. Pulsa **Windows + R** → escribe `taskschd.msc` → Enter.
2. Panel izquierdo: **Task Scheduler Library** (no carpeta concreta).

---

## Paso 2 · Crear nueva tarea

**Action** → **Create Task...** (NO "Create Basic Task" — la versión avanzada da más control).

### Pestaña **General**

- **Name:** `VERBEX MVP arranque`
- **Description:** `Lanza n8n + Streamlit + (opcional) Nanobot tras login.`
- **Run only when user is logged on** ✓ (recomendado)
- **Run with highest privileges** ⬜ (sólo si n8n requiere permisos especiales)
- **Configure for:** Windows 10/11

### Pestaña **Triggers** → **New...**

- **Begin the task:** *At log on*
- **Specific user:** tu usuario Windows
- **Delay task for:** `30 seconds` (deja que el SO termine de cargar)
- **Enabled** ✓

### Pestaña **Actions** → **New...**

- **Action:** *Start a program*
- **Program/script:** `C:\verbex\MVP-A_Normalizador_Aeronautico\II6-MVP_Completo\deploy\start_verbex.bat`
  > Sustituye por la ruta absoluta real en tu PC.
- **Start in (optional):** `C:\verbex\MVP-A_Normalizador_Aeronautico\II6-MVP_Completo\deploy`

### Pestaña **Conditions**

- **Start the task only if the computer is on AC power** ⬜ (desmarcar para que arranque también con batería en portátiles)
- **Stop if the computer switches to battery power** ⬜
- **Wake the computer to run this task** ⬜ (sólo si quieres que el equipo despierte para ejecutar)

### Pestaña **Settings**

- **Allow task to be run on demand** ✓
- **If the task fails, restart every:** `1 minute` · max **3** intentos
- **If the running task does not end when requested, force it to stop** ✓
- **If the task is already running, then the following rule applies:** *Do not start a new instance*

Click **OK** y vuelve al listado.

---

## Paso 3 · Probar la tarea

1. Click derecho en `VERBEX MVP arranque` → **Run**.
2. Deberían abrirse 3 ventanas cmd.exe (n8n, Dashboard, opcional Nanobot).
3. Abrir [http://localhost:5678](http://localhost:5678) y [http://localhost:8501](http://localhost:8501).

---

## Paso 4 · Probar tras login

1. Cerrar sesión Windows (`Win + L` o **Sign out**).
2. Volver a iniciar sesión.
3. Esperar 30 segundos: las 3 ventanas deberían abrirse solas.
4. Verificar que el bot de Telegram responde a un mensaje de prueba.

---

## Cómo PARAR el agente

Opción A · cerrar las 3 ventanas cmd.exe individualmente.

Opción B · script `stop_verbex.bat` (a crear, opcional):

```batch
@echo off
taskkill /F /FI "WINDOWTITLE eq VERBEX n8n*"
taskkill /F /FI "WINDOWTITLE eq VERBEX Dashboard*"
taskkill /F /FI "WINDOWTITLE eq VERBEX Nanobot*"
echo VERBEX MVP detenido.
pause
```

---

## Troubleshooting

### "El bat se ejecuta pero las ventanas se cierran inmediatamente"

Causa habitual: variable `PATH` distinta entre Task Scheduler y tu cmd interactivo. Solución: añadir rutas absolutas al `.bat`:

```batch
REM En lugar de: n8n start
REM usa: C:\Users\<USUARIO>\AppData\Roaming\npm\n8n.cmd start
```

### "n8n arranca pero no puedo conectarme"

Espera más tiempo en el arranque (n8n tarda 10–30 s la primera vez). Aumenta el `timeout /t 8` a `timeout /t 20` en `start_verbex.bat`.

### "El dashboard muestra error de Service Account"

Asegúrate de que la ruta absoluta de `GOOGLE_SERVICE_ACCOUNT_JSON` en `.env` es válida y accesible desde el contexto del Task Scheduler. Pon la `.env` y el JSON en una ruta sin caracteres especiales (no en `Mi unidad/...`).

### "Task Scheduler dice 'Task succeeded' pero nada se ve"

Marcar **Run only when user is logged on** (no la opción de fondo). Sin esto, los procesos arrancan en una sesión invisible.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Despliegue Windows*
