# II2 — Lógica Determinista (sin LLM)

**Sesión:** Parte 2 · Módulo II2
**Idea fuerza del módulo:** *"Los KPIs no los calcula el LLM (E5)."*
**PRDA:** Razonar (capa determinista)
**Tiempo en clase:** 2,5 h

---

## ¿Qué se construye?

Un workflow n8n con **8 nodos** que aplica las 7 reglas de negocio R01–R09 a una PO simulada (sin invocar al LLM). Sienta el principio E5: el cálculo de prioridad, validación de catálogo, asignación de certificaciones y anti-spam son **deterministas en n8n**, nunca responsabilidad del modelo.

```
Manual Trigger → Caso simulado → R04+R08 → R07 → R01+R02 → R05+R06 → R03 → R09
```

### Por qué importa

En II3 conectaremos el LLM real para extraer las líneas del texto de la PO. **Pero las reglas que decidimos hoy seguirán siendo deterministas.** El LLM dirá *qué* hay en el pedido; n8n decidirá *qué hacer con ello*.

Si una sesión futura intentara mover R02 ("¿está la fecha a 7 días?") al LLM, el código de hoy serviría de evidencia visible de por qué no se hace así.

---

## Las 7 reglas (spec § 4.5)

| ID | Regla | Implementación |
|---|---|---|
| **R01** | `aog: true` → `prioridad: "AOG"` (override absoluto) | nodo `R01 + R02` |
| **R02** | `fecha_entrega_requerida − hoy ≤ 7 días` → `prioridad: "PRIORITARIO"` (si no AOG) | nodo `R01 + R02` |
| **R03** | `confianza < 0.80` → `estado: "PARCIAL"` + alerta | nodo `R03` |
| **R04** | PN cliente no en `equivalencias_pn.csv` → `estado: "ERROR"` | nodo `R04 + R08` |
| **R05** | `requiere_coc: true` → `doc_requerida: ["CoC"]` | nodo `R05 + R06` |
| **R06** | `requiere_easa_form1: true` → `doc_requerida: [..., "EASA Form 1"]` | nodo `R05 + R06` |
| **R07** | Cliente no en `clientes.csv` → `estado: "PARCIAL"` + `cliente_no_registrado: true` (no rechaza) | nodo `R07` |
| **R08** | `cantidad ≤ 0` o `unidad` ∉ {EA, KG, ML, M2} → `estado: "ERROR"` | nodo `R04 + R08` |
| **R09** | `numero_pedido` en cache (Sheets en producción) → `duplicado: true` | nodo `R09` |

> Nota: R04+R08 y R05+R06 y R01+R02 se agrupan en un mismo Code node por afinidad temática. Son lógicamente independientes.

---

## Orden de aplicación

1. **R04 + R08** — primero. Si el PN no existe o la cantidad es inválida, el dato está corrupto: marcamos ERROR y el resto de reglas no rectifican.
2. **R07** — si el cliente no está registrado, escalamos a PARCIAL pero seguimos.
3. **R01 + R02** — calculamos prioridad. R01 (AOG) tiene prioridad sobre R02 (fecha).
4. **R05 + R06** — asignamos certificaciones documentales por línea.
5. **R03** — si la confianza del LLM es baja, escalamos COMPLETO → PARCIAL. No baja de PARCIAL a ERROR.
6. **R09** — al final, comprobamos si la PO ya está procesada (anti-spam).

---

## IO/RE de la sesión

| | |
|---|---|
| **Inputs** | PO simulada (mismo schema que el output de II3, spec § 4.4) · `catalogo.csv` · `equivalencias_pn.csv` · `clientes.csv` (mirrors in-memory en cada Code node) |
| **Outputs** | JSON enriquecido con `prioridad_calculada`, `doc_requerida` (por línea), `cliente_no_registrado`, `duplicado`, `estado_normalizacion` actualizado, `alertas[]` ampliadas |
| **Reglas** | R01–R09 explícitas en código JavaScript de n8n. **Ninguna llamada al LLM.** Cálculos deterministas y auditables |
| **Excepciones** | PN desconocido / cantidad inválida → ERROR · cliente desconocido → PARCIAL no rechaza · confianza baja → PARCIAL · PO duplicada → flag |

---

## Cómo correr esta sesión

### 1. Importar el workflow

En n8n: **Workflows** → **Import from File** → seleccionar `workflow_II2.json`.

No hace falta credencial Telegram para esta sesión: el trigger es manual.

### 2. Ejecutar el caso por defecto

Click en **Execute Workflow** (botón "Test workflow" en la UI). El caso por defecto es `01_estandar`:

- Input: PO Stratos · 12 unidades de costilla composite · CoC requerido · entrega Sept 2026.
- Output esperado: `estado: "COMPLETO"`, `prioridad_calculada: "NORMAL"`, `doc_requerida: ["CoC"]`, sin alertas.

### 3. Probar otros casos

Abrir el nodo `Caso simulado · case_01_estandar`. Sustituir la constante `CASO` por el campo `input_simulado` de cualquier caso del fichero [`datos_simulados/po_test_set.json`](datos_simulados/po_test_set.json). Ejecutar de nuevo y comparar con el campo `expected` del mismo caso.

### 4. Predicción esperada (validada en Python)

| caso | regla | estado | prioridad | duplicado |
|---|---|---|---|---|
| 01_estandar | (camino feliz) | COMPLETO | NORMAL | false |
| 02_aog | R01 | COMPLETO | **AOG** | false |
| 03_amendment | (alerta arrastrada) | COMPLETO | NORMAL | false |
| 04_pn_desconocido | R04 | **ERROR** | NORMAL | false |
| 05_cliente_nuevo | R07 | **PARCIAL** | NORMAL | false |
| 06_fecha_urgente | R02 | COMPLETO | **PRIORITARIO** | false |
| 07_cantidad_invalida | R08 | **ERROR** | NORMAL | false |
| 08_po_duplicada | R09 | COMPLETO | NORMAL | **true** |

> El caso 06 depende de la fecha de ejecución. La fecha de referencia de los test es **2026-05-08**. Si se ejecuta tras el 2026-05-13 (fecha del case_06), R02 ya no aplica porque la entrega está en el pasado.

---

## Mirrors in-memory (anti-patrón didáctico)

Cada Code node duplica datos del CSV (`equivalencias_pn`, `clientes`) como objetos JS hardcoded. **Es una decisión deliberada para esta sesión:**

- Mantiene el workflow **autónomo y portable** (no depende de Read CSV nodes ni de paths de archivo).
- Permite que el alumno ejecute la sesión sin haber preparado los CSVs.
- Hace explícito el coste del mirror: si cambian los CSVs, hay que tocar 7 sitios.

En II4 (default D4 spec § 10) los CSVs se leerán con un nodo Read CSV inicial y se inyectarán a las reglas vía variables de workflow. Pero en II2 mostramos primero el patrón "todo inline" para que el alumno entienda **qué hacen** las reglas antes de ver **dónde se inyectan los datos**.

---

## Gate F2 (criterio de cierre de la sesión)

✅ Las 8 POs del test set producen el output esperado:

- 8/8 con estado correcto
- 8/8 con prioridad correcta
- 8/8 con flag `duplicado` correcto
- alertas_count en banda esperada (±1)

Validado mediante simulación en Python con la misma lógica embebida en los Code nodes JS.

---

## Lo que NO hace este workflow (queda para II3, II4)

- ❌ Llamar al LLM para extraer líneas de un texto → II3.
- ❌ Validar contra el contenido real de `catalogo.csv` (este workflow usa mirrors hardcoded) → II4 con Read CSV.
- ❌ Notificar por Telegram → II4.
- ❌ Registrar en Sheets → II4 (también es donde R09 deja de ser stub).
- ❌ Recibir input desde Telegram → ese flujo está en II1.

II2 es el **núcleo determinista** del agente. Es la pieza que el LLM va a *envolver*, no a *reemplazar*.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Sesión II2*
