# II5 — Resiliencia y Arquitecturas Alternativas

**Sesión:** Parte 2 · Módulo II5
**Idea fuerza del módulo:** *"Workflow que funciona ≠ sistema operable."*
**PRDA:** lectura externa del sistema (gobernanza)
**Tiempo en clase:** 2,5 h

---

## ¿Qué se construye?

Tres bloques pedagógicos:

1. **Refactor n8n** del monolito II4 a master + 4 sub-workflows + Error Trigger global.
2. **Alternativa Nanobot/Python** (`nanobot_verbex.py`) que reproduce el mismo MVP en arquitectura Python pura, sin n8n.
3. **Checklist de gobernanza** para el agente en producción (seguridad, costes, retention, AS9100).

> Lo que se enseña es el **principio de modularidad** y **plausibilidad de arquitecturas alternativas**, no el detalle de cada implementación. El alumno se lleva el patrón, no las 26 líneas concretas.

---

## Bloque 1 · Refactor a sub-workflows

### Patrón

```
                    [Master workflow]
                           │
                ┌──────────┼──────────┐
                ▼          ▼          ▼
       [SUB-Ingesta]  [SUB-Cognitivo]  [SUB-Logica]  [SUB-Routing]
                           │
                  [Error Trigger Workflow]  (errorWorkflow setting)
```

### Ficheros entregados

- **`workflow_II5_master.json`** — master con `Telegram Trigger` + 4 nodos `Execute Workflow` (placeholders) + sticky notes documentando cada sub. Configurado con `errorWorkflow: PLACEHOLDER_ERROR_TRIGGER_ID`. Para hacerlo runnable, el alumno debe:
  1. Importarlo en n8n.
  2. Crear los 4 sub-workflows extrayéndolos de `workflow_II4.json` (ejercicio).
  3. Reemplazar los `PLACEHOLDER_*_ID` por los IDs reales tras importar cada sub.

- **`workflow_II5_error_trigger.json`** — workflow independiente con `Error Trigger` → Code "Formatear evento" → Sheets Append `Errores` → Telegram al operador. Importable y testeable de forma aislada (Settings → Test workflow simula un error).

### Cómo se hace el refactor (paso a paso para el alumno)

1. **Identificar capas** en `workflow_II4.json`:
   - Capa Ingesta: nodos 1–2 (Trigger + Set texto) — equivalente a II1.
   - Capa Cognitivo: nodos 3–5 (Construir body + HTTP + Validar JSON LLM) — II3.
   - Capa Lógica: nodos 6–10 (R04+R08 → R03) — II2 sin R09.
   - Capa Routing: nodos 11–26 (R09 lookup + IF + fan-out) — la nueva en II4.

2. **Crear 4 workflows nuevos** en n8n (uno por capa) y mover los nodos correspondientes.

3. **Conectar capas** vía `Execute Workflow` en el master, pasando `$json` entre subs.

4. **Configurar Error Workflow**: en cada sub + master, Settings → Error Workflow → seleccionar el workflow II5 Error Trigger.

5. **Validar** que el master ejecuta el mismo flujo que II4 monolítico produciendo el mismo output (criterio 10 spec § 8 adaptado).

### Beneficios del refactor

| Antes (II4 monolítico, 26 nodos) | Después (II5 modular, 1+4+1 workflows) |
|---|---|
| Cambiar el SOUL/SKILL afecta al workflow completo | Cambiar SOUL afecta sólo `SUB-Cognitivo` |
| Test de R02 requiere ejecutar todo el pipeline | `SUB-Logica` se testea aislado con datos simulados |
| Añadir un nuevo cliente: editar nodos en 5 sitios | Añadir cliente: editar `SUB-Ingesta` (lookup) |
| Error en SMTP escala todo el pipeline | Error en `SUB-Routing` no toca `SUB-Cognitivo` |
| Difícil reutilizar capas para otro caso de uso | `SUB-Cognitivo` es reutilizable: cambia el SOUL y sirve para otro dominio |

### Trade-offs

- ❌ Más overhead de gestión: 6 workflows en lugar de 1 → más imports/exports en migración.
- ❌ Latencia adicional por cada `Execute Workflow` (~50–100 ms cada uno).
- ✅ Reusabilidad y testabilidad mucho mejores.
- ✅ Bounded context por capa: decisiones de cambio se pueden razonar localmente.

---

## Bloque 2 · Alternativa Nanobot/Python

Mismo MVP, arquitectura distinta. Demuestra que la lógica del agente (`SUB-Cognitivo` + `SUB-Logica`) puede vivir fuera de n8n.

### Dos formas de "Nanobot/Python"

**A) Nanobot agent (loop conversacional con Telegram nativo)**

Ficheros: `nanobot/config.template.json` + `nanobot/workspace/{SOUL,SKILL,AGENTS,TOOLS,HEARTBEAT}.md`.

Nanobot es un framework agéntico que conecta directamente con Telegram, lee SOUL como system prompt, y permite tools del filesystem (read/write/glob/grep). El SOUL.md de VERBEX define el procedimiento numerado de normalización (§§ 1–6 del SOUL). Tras confirmación del usuario por Telegram, el agente escribe `pedido_output.json` en el directorio swap.

```bash
# Lanzar el agente
nanobot --config config.json
```

El alumno interactúa con el bot por Telegram (`/start`), pega texto de PO, el agente propone interpretación, alumno confirma, agente escribe el JSON. El JSON puede luego procesarse por las reglas R01–R09.

**B) Script Python standalone (sin Telegram)**

Fichero: `nanobot/nanobot_verbex.py`.

Reproduce el flujo II3 + R01–R09 en Python puro:

```bash
# Instalar dependencias
pip install -r nanobot/requirements_nanobot.txt

# Procesar una PO desde un fichero
python nanobot/nanobot_verbex.py < ../II1-Ingesta_Canal/payloads/payload_01_po_estandar.txt

# Procesar desde echo
echo "Purchase Order PO-2026-VECT-0142. Vectair Industries. HX7-ELV-220 x3 EA, Need Date 13/05/2026" \
  | python nanobot/nanobot_verbex.py
```

Output: JSON normalizado con todas las reglas aplicadas.

### Validación cruzada

Las reglas R01–R09 implementadas en `nanobot_verbex.py` se han verificado contra los 8 casos de `po_test_set.json` (II2). **8/8 producen el mismo output que el workflow_II2 n8n** (validado con script de simulación). Esto confirma criterio 13 spec § 8: *"nanobot_verbex.py reproduce flujo II3 completo en Python puro produciendo el mismo JSON"*.

### ¿Cuándo conviene cada arquitectura?

| Criterio | n8n (master + subs) | Nanobot/Python |
|---|---|---|
| **Audiencia técnica** | Operador no-code, ingeniero junior | Desarrollador con Python |
| **Edición del prompt** | UI visual, sin redeploy | Editar `.py`, redeploy |
| **Observabilidad** | Panel Executions visual | Logs textuales |
| **Test unitario** | Difícil (n8n no tiene unit tests) | Fácil (`pytest`) |
| **Versionado** | JSON exportado a git, diffs ruidosos | Diffs limpios en `.py` |
| **Latencia** | +50–100 ms por Execute Workflow | Mínima (todo en proceso) |
| **Coste de mantenimiento** | Bajo si lo mantiene operador | Bajo si lo mantiene equipo dev |
| **Recomendación curso** | Track A oficial COIIAOC | Material complementario, default D5 |

> **Default D5** (spec § 10): Nanobot alternativo es **complementario, no evaluable**. Se enseña, no se exige al alumno reproducirlo.

---

## Bloque 3 · Gobernanza

Fichero: [`gobernanza-checklist.md`](gobernanza-checklist.md). 9 secciones operables:

1. Seguridad de credenciales (7 ítems)
2. Control de costes de tokens (5 ítems)
3. Logging mínimo viable (5 ítems)
4. Retention de datos (6 ítems · AS9100 7 años para POs)
5. Trazabilidad AS9100 (7 ítems)
6. Continuidad operativa (5 ítems)
7. Acceso y autorización (6 ítems)
8. Validación operativa periódica (4 ítems)
9. Mejoras candidatas post-MVP (6 ítems)

Cada ítem es una caja de check. Se diligencia antes de pasar el agente a producción real (no en clase).

---

## IO/RE de la sesión

| | |
|---|---|
| **Inputs** | `workflow_II4.json` (monolítico) · entorno n8n con credenciales · Python 3.10+ con `requirements_nanobot.txt` instalado · Anthropic API Key |
| **Outputs** | Master + 4 subs + Error Trigger en n8n · `nanobot_verbex.py` runnable · checklist gobernanza diligenciable |
| **Reglas** | Cada capa = sub-workflow independiente · credenciales en variables de entorno · costes tokens monitorizados · logging mínimo en Sheets `Errores` |
| **Excepciones** | Error en cualquier capa → Error Trigger Workflow global → log + Telegram operador · sin propagación silenciosa |

---

## Cómo correr esta sesión

### 1. Refactor n8n (45 min)

1. Importar `workflow_II5_master.json` y `workflow_II5_error_trigger.json` en n8n.
2. Asignar credenciales (Telegram, Sheets, SMTP) — heredadas de II4.
3. **Ejercicio guiado:** dividir `workflow_II4.json` en 4 sub-workflows. El instructor hace en pizarra el corte de capas, el alumno crea los 4 workflows en su instancia n8n.
4. Reemplazar los `PLACEHOLDER_*_ID` del master por los IDs reales tras importar cada sub.
5. Configurar Error Workflow en master + 4 subs.
6. Probar: enviar PO al bot → debe llegar al final igual que en II4.

### 2. Alternativa Nanobot (45 min)

1. Instalar dependencias: `pip install -r nanobot/requirements_nanobot.txt`.
2. **Opción A** (Nanobot agent): copiar `config.template.json` → `config.json`, rellenar tokens, lanzar `nanobot --config config.json`. Probar interacción por Telegram.
3. **Opción B** (Python standalone): `python nanobot/nanobot_verbex.py < ../II1-Ingesta_Canal/payloads/payload_01_po_estandar.txt`. Verificar JSON output coincide con el de II3.
4. Discusión: ¿cuándo elegirías cada arquitectura para tu propio caso?

### 3. Checklist de gobernanza (30 min)

1. Lectura guiada de [`gobernanza-checklist.md`](gobernanza-checklist.md).
2. Cada alumno marca qué ítems aplican a su contexto y cuáles no.
3. Discusión: ¿cuál es el ítem más difícil de cumplir? ¿por qué?

---

## Gate F5 (criterios de cierre)

✅ **Refactor:**
- `workflow_II5_master.json` parseable: 10 nodos (5 ejecutables + 5 sticky notes), 4 conexiones.
- `workflow_II5_error_trigger.json` parseable: 5 nodos (4 ejecutables + 1 sticky), 3 conexiones.
- Master con `errorWorkflow` setting referencia el Error Trigger workflow.

✅ **Nanobot/Python:**
- `nanobot_verbex.py` AST válido (275 líneas, 5 funciones, 6 constantes globales).
- Las reglas R01–R09 implementadas en Python producen el mismo output que el workflow_II2 contra los 8 casos `po_test_set.json` (validado).

✅ **Gobernanza:**
- `gobernanza-checklist.md` con 48 ítems operables agrupados en 9 secciones.

**Pendiente funcional (no bloquea F6):**
- Refactor en n8n con credenciales reales (en clase con instancia del alumno).
- Llamada `nanobot_verbex.py` con `ANTHROPIC_API_KEY` activa contra los 5 ejemplos del SKILL.

---

## Lo que NO hace este módulo (queda para II6)

- ❌ Streamlit dashboard que lee Sheets en read-only → II6.
- ❌ Deploy Windows con Task Scheduler → II6.
- ❌ Brief del proyecto del alumno (otro dominio) → II6.

II5 es el **módulo bisagra**: convierte el MVP funcional de II4 en un sistema operable. II6 lo cierra con observabilidad y deploy.

---

## Lecturas complementarias (post-clase)

- **Patrón de sub-workflows en n8n:** [n8n.io/blog/sub-workflows](https://n8n.io/) — patrón formal documentado por el equipo n8n.
- **Error Workflows:** [docs.n8n.io/workflows/settings/#error-workflow](https://docs.n8n.io/) — configuración avanzada.
- **AS9100 retention:** estándar aeronáutico de retención documental — consultar manual de calidad VERBEX (ficticio).
- **Anthropic billing & limits:** [console.anthropic.com/billing](https://console.anthropic.com/) — configurar límites mensuales.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Sesión II5*
