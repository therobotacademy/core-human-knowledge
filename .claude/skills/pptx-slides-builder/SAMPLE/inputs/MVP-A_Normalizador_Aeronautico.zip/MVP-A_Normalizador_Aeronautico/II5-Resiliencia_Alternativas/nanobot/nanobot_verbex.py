"""
VERBEX · nanobot_verbex.py · Alternativa Python pura del flujo II3+R01-R09.

Reproduce el pipeline cognitivo completo SIN n8n: lee texto de PO en stdin,
llama a Claude API, valida JSON, aplica las reglas R01–R09 deterministas, e
imprime el JSON enriquecido en stdout.

Uso:
    python nanobot_verbex.py < ejemplo_po.txt
    cat po.txt | python nanobot_verbex.py
    echo "Purchase Order PO-2025-STRA-0847..." | python nanobot_verbex.py

Requiere:
    - ANTHROPIC_API_KEY en .env (de la raíz del proyecto MVP-A_Normalizador_Aeronautico)
    - pip install -r requirements_nanobot.txt

Demuestra el principio E5: el LLM extrae texto, Python aplica las reglas deterministas.
Es la alternativa de arquitectura al workflow n8n. Mismo MVP, dos caminos.
"""

import copy
import json
import os
import re
import sys
from datetime import date, datetime, timedelta

from anthropic import Anthropic
from dotenv import load_dotenv


load_dotenv()

# --- Mirrors in-memory (espejo de los CSV de data/) ----------------------------------------------

EQUIVALENCIAS_PN = {
    "ST9-HTP-RIB-047": "VBX-COMP-4471-B",
    "ST9-HTP-RIB-048": "VBX-COMP-4472-C",
    "HX7-FUS-PNL-331": "VBX-COMP-3301-A",
    "HX7-FUS-PNL-332": "VBX-COMP-3302-A",
    "HX7-BHD-332":     "VBX-COMP-3303-B",
    "ST9-LE-PNL-550":  "VBX-COMP-5501-A",
    "HX7-ELV-220":     "VBX-COMP-2201-C",
}

PNS_VALIDOS = {
    "VBX-COMP-4471-B", "VBX-COMP-4472-C", "VBX-COMP-3301-A", "VBX-COMP-3302-A",
    "VBX-COMP-3303-B", "VBX-COMP-5501-A", "VBX-COMP-5502-A", "VBX-COMP-2201-C",
    "VBX-COMP-2202-C", "VBX-COMP-6601-A", "VBX-COMP-6602-A", "VBX-COMP-7701-B",
    "VBX-COMP-7702-B", "VBX-COMP-8801-A", "VBX-COMP-9901-A", "VBX-COMP-9902-A",
}

CLIENTES_REGISTRADOS = {"STRA-001", "KAIRO-001", "KAIRO-002", "HELI-001", "VECT-001"}
UNIDADES_VALIDAS = {"EA", "KG", "ML", "M2"}
PEDIDOS_YA_PROCESADOS = {"PO-2025-STRA-9999"}  # En producción: lookup contra Sheets

# --- System prompt -------------------------------------------------------------------------------

SYSTEM_PROMPT = """Eres el agente de normalización de Purchase Orders de VERBEX COMPOSITES S.L. (Tier 2 composites, Sevilla). Recibes POs en texto libre de clientes Tier 1 (Stratos, Kairos) y OEMs (Helion, Vectair).

REGLAS ABSOLUTAS:
1. Nunca calculas fechas, días ni cantidades. Solo extraes lo escrito.
2. Nunca inventas Part Numbers. Si no reconoces un PN, part_number_proveedor: null y bajas la confianza.
3. Si detectas AOG, "Aircraft on Ground", "inmovilizado" o urgencia extrema, devuelves "aog": true.
4. Si el texto menciona "Rev.", "Amendment", añades alerta con numero_pedido original.
5. Devuelves SOLO el JSON. Sin explicaciones, sin markdown.
6. El idioma de los campos extraídos es el del documento original.
7. prioridad SIEMPRE "NORMAL" — Python recalcula con R01/R02.

CLIENTES (nombre → codigo_erp · tier · programa):
- Stratos Systems → STRA-001 · TIER_1 · ST900
- Kairos Aerospace → KAIRO-001 · TIER_1 · HX7
- Kairos Defense → KAIRO-002 · TIER_1 · HX7
- Helion Aircraft → HELI-001 · OEM · HX7
- Vectair Industries Iberia → VECT-001 · OEM · VX4

EQUIVALENCIAS PN cliente → PN proveedor:
ST9-HTP-RIB-047 → VBX-COMP-4471-B (Costilla HTP delantera, ST900, CoC)
ST9-HTP-RIB-048 → VBX-COMP-4472-C (Costilla HTP trasera, ST900, CoC)
HX7-FUS-PNL-331 → VBX-COMP-3301-A (Panel fuselaje central, HX7, CoC + EASA Form 1)
HX7-FUS-PNL-332 → VBX-COMP-3302-A (Panel fuselaje lateral, HX7, CoC + EASA Form 1)
HX7-BHD-332 → VBX-COMP-3303-B (Mamparo, HX7, CoC + EASA Form 1)
ST9-LE-PNL-550 → VBX-COMP-5501-A (Borde ataque ala, ST900, CoC)
HX7-ELV-220 → VBX-COMP-2201-C (Timón, RT55, CoC + EASA Form 1)

Si PN cliente NO en tabla: part_number_proveedor: null + confianza baja.

UNIDADES VÁLIDAS: EA | KG | ML | M2.

CONFIANZA:
0.95+ → texto estructurado (HelionLink CSV)
0.80-0.95 → texto libre estándar
0.60-0.80 → algún PN desconocido o campo ambiguo
< 0.60 → varios campos faltantes

SCHEMA: numero_pedido (string) · cliente {nombre, tier, codigo_erp} · lineas[{linea_id, part_number_cliente, part_number_proveedor, descripcion, cantidad, unidad, precio_unitario:null, fecha_entrega_requerida (YYYY-MM-DD|null), programa, prioridad:"NORMAL", requiere_coc, requiere_easa_form1}] · estado_normalizacion (COMPLETO|PARCIAL|ERROR) · confianza (0.0-1.0) · alertas[] · aog (bool).

NO PO: {"error":"no_pedido","mensaje":"descripción"}

DEVUELVE SOLO EL JSON. NADA MÁS.
"""


# --- Llamada al LLM ------------------------------------------------------------------------------

def call_claude(texto_po: str) -> str:
    """POST a /v1/messages con el system prompt + el texto de la PO."""
    client = Anthropic()
    resp = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1500,
        temperature=0.1,
        system=SYSTEM_PROMPT,
        messages=[
            {"role": "user", "content": f"Texto de la PO a normalizar:\n\n{texto_po}"}
        ],
    )
    return resp.content[0].text.strip()


# --- Parser anti-alucinación --------------------------------------------------------------------

def parse_llm_response(raw: str) -> dict:
    """Limpia code fences, parsea JSON, valida schema mínimo, fuerza PN proveedor a null si invento."""
    clean = re.sub(r"```json\s*", "", raw, flags=re.IGNORECASE)
    clean = re.sub(r"```\s*", "", clean).strip()

    try:
        po = json.loads(clean)
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON_PARSE_ERROR: {e} | Raw: {clean[:300]}") from e

    if po.get("error") == "no_pedido":
        return {
            **po,
            "estado_normalizacion": "ERROR",
            "alertas": [f"LLM clasificó como no_pedido: {po.get('mensaje', '')}"],
            "lineas": [],
            "aog": False,
            "confianza": 0,
        }

    if not po.get("lineas"):
        raise ValueError("SCHEMA_ERROR: lineas[] vacío o ausente")

    alertas = list(po.get("alertas", []))
    for linea in po["lineas"]:
        pn_prov = linea.get("part_number_proveedor")
        if pn_prov and pn_prov not in PNS_VALIDOS:
            alertas.append(
                f"PARSER: PN proveedor inventado por el LLM en línea {linea['linea_id']}: {pn_prov}. Forzado a null."
            )
            linea["part_number_proveedor"] = None
    po["alertas"] = alertas
    return po


# --- Reglas R01–R09 (deterministas) -------------------------------------------------------------

def apply_rules(po: dict, hoy: date | None = None) -> dict:
    """Aplica las 7 reglas del MVP en el orden documentado en II2."""
    po = copy.deepcopy(po)
    hoy = hoy or date.today()
    alertas = list(po.get("alertas", []))

    # R04 + R08
    estado_error = False
    for linea in po["lineas"]:
        if not EQUIVALENCIAS_PN.get(linea.get("part_number_cliente")):
            alertas.append(
                f"R04: PN cliente desconocido en línea {linea.get('linea_id')}: {linea.get('part_number_cliente')}"
            )
            estado_error = True
        if linea.get("cantidad", 0) <= 0:
            alertas.append(f"R08: cantidad inválida en línea {linea.get('linea_id')}: {linea.get('cantidad')}")
            estado_error = True
        if linea.get("unidad") not in UNIDADES_VALIDAS:
            alertas.append(f"R08: unidad no reconocida en línea {linea.get('linea_id')}: {linea.get('unidad')}")
            estado_error = True
    if estado_error:
        po["estado_normalizacion"] = "ERROR"

    # R07
    cod_erp = (po.get("cliente") or {}).get("codigo_erp")
    if not cod_erp or cod_erp not in CLIENTES_REGISTRADOS:
        alertas.append(f"R07: cliente no registrado (codigo_erp: {cod_erp or 'null'}). Pipeline continúa con flag.")
        if po.get("estado_normalizacion") == "COMPLETO":
            po["estado_normalizacion"] = "PARCIAL"
        po["cliente_no_registrado"] = True
    else:
        po["cliente_no_registrado"] = False

    # R01 + R02
    prioridad_global = "NORMAL"
    if po.get("aog"):
        prioridad_global = "AOG"
        alertas.append("R01: AOG detectado, prioridad escalada a AOG")

    for linea in po["lineas"]:
        if po.get("aog"):
            linea["prioridad"] = "AOG"
            continue
        fer = linea.get("fecha_entrega_requerida")
        if fer:
            fecha_entrega = date.fromisoformat(fer)
            diff_dias = (fecha_entrega - hoy).days
            if 0 <= diff_dias <= 7:
                linea["prioridad"] = "PRIORITARIO"
                if prioridad_global == "NORMAL":
                    prioridad_global = "PRIORITARIO"
                alertas.append(f"R02: línea {linea['linea_id']} a {diff_dias} días, prioridad PRIORITARIO")
    po["prioridad_calculada"] = prioridad_global

    # R05 + R06
    for linea in po["lineas"]:
        docs = []
        if linea.get("requiere_coc"):
            docs.append("CoC")
        if linea.get("requiere_easa_form1"):
            docs.append("EASA Form 1")
        if docs:
            linea["doc_requerida"] = docs

    # R03
    confianza = po.get("confianza")
    if isinstance(confianza, (int, float)) and confianza < 0.80:
        if po.get("estado_normalizacion") == "COMPLETO":
            po["estado_normalizacion"] = "PARCIAL"
        alertas.append(f"R03: confianza baja ({confianza:.2f} < 0.80), revisar manualmente")

    # R09 (stub: cache hardcoded; en producción → lookup en Sheets)
    if po.get("numero_pedido") in PEDIDOS_YA_PROCESADOS:
        alertas.append(f"R09: {po['numero_pedido']} ya procesado previamente. Marcado como duplicado, no se reenvía.")
        po["duplicado"] = True
    else:
        po["duplicado"] = False

    po["alertas"] = alertas
    return po


# --- Pipeline end-to-end -------------------------------------------------------------------------

def normalize_po(texto_po: str) -> dict:
    """Pipeline completo: Claude API → parser anti-alucinación → reglas R01–R09."""
    raw = call_claude(texto_po)
    po = parse_llm_response(raw)
    if po.get("error") == "no_pedido":
        return po
    enriched = apply_rules(po)
    return enriched


def main() -> int:
    if not os.getenv("ANTHROPIC_API_KEY"):
        sys.stderr.write("ERROR: falta ANTHROPIC_API_KEY en .env\n")
        return 1

    texto_po = sys.stdin.read().strip()
    if not texto_po:
        sys.stderr.write("ERROR: no se recibió texto en stdin\n")
        return 1

    try:
        result = normalize_po(texto_po)
    except Exception as e:
        sys.stderr.write(f"ERROR procesando PO: {e}\n")
        return 2

    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
