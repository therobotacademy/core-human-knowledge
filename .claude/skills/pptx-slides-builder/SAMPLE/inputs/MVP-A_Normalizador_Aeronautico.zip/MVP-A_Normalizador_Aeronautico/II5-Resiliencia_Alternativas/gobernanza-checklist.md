# Checklist de Gobernanza · MVP-A VERBEX

Diligenciar antes de poner el agente en producción. Cada ítem es operable y verificable.

---

## 1. Seguridad de credenciales

- [ ] `.env` excluido por `.gitignore` y nunca commiteado
- [ ] Service Account JSON guardado fuera del repositorio en ruta protegida (ej. `C:\verbex\service-account.json`)
- [ ] Telegram bot token rotado tras pruebas en clase
- [ ] SMTP usa App Password (Gmail 2FA), no contraseña principal de la cuenta
- [ ] Anthropic API Key con **límite mensual de gasto** configurado en console.anthropic.com
- [ ] Acceso al Google Sheet restringido al Service Account email — no compartido público ni "Anyone with link"
- [ ] Variables de entorno en n8n: nunca pegadas directamente en nodos

---

## 2. Control de costes de tokens

- [ ] Logging de `tokens_in` y `tokens_out` por ejecución (extraer de la respuesta Anthropic, columna en Sheets `Pedidos` o hoja dedicada)
- [ ] Límite mensual de gasto en Anthropic Console (recomendación inicial: 50 €/mes)
- [ ] Alerta automática si gasto diario > 5 €
- [ ] Revisión semanal del coste por PO promedio (target: < 0.02 €/PO)
- [ ] Cache de respuestas LLM para POs idénticas — **no implementado en MVP**, candidato para v2

> En MVP-A, el coste estimado es ~0.013 €/PO. Para 100 POs/día = ~40 €/mes.

---

## 3. Logging mínimo viable

- [ ] Cada PO procesada queda registrada en Sheets `Pedidos` (cabecera + total_lineas + alertas_count + texto_original truncado a 1 000 chars)
- [ ] Cada error queda en Sheets `Errores` con: timestamp · numero_pedido · tipo_error · error_raw · texto_original · nodo_origen
- [ ] Log de Nanobot persistido a archivo (`nanobot.log`)
- [ ] Logs de n8n disponibles en panel **Executions** (retention configurable)
- [ ] Log mínimo en cada Code node con `console.log` para debug — **NO** en producción (genera ruido)

---

## 4. Retention de datos

- [ ] **POs en Sheets**: retención **7 años** (cumplimiento AS9100)
- [ ] **Logs de errores**: retención mínima 1 año
- [ ] **`nanobot.log`**: rotación mensual con `logrotate` o equivalente Windows
- [ ] **Email confirmación al cliente**: copia automática en Sent Items del SMTP
- [ ] **Backups de Sheets**: descarga semanal manual o automatizada con Apps Script
- [ ] **Variables de entorno**: rotar credenciales cada 6 meses

---

## 5. Trazabilidad AS9100

- [ ] `timestamp` ISO 8601 en cada fila de Sheets (`Pedidos`, `Lineas`, `Errores`)
- [ ] `texto_original` preservado (auditoría: poder reconstruir qué llegó del cliente)
- [ ] `confianza` del LLM logueada (0.0–1.0) — permite auditar decisiones del agente
- [ ] `alertas_resumen` registra **qué reglas escalaron** y por qué
- [ ] PO original preservada antes de cualquier amendment (la fila Rev. A no se borra al recibir Rev. B)
- [ ] Cada `numero_pedido` único — la combinación numero_pedido + timestamp es la clave de auditoría
- [ ] Sin escritura silenciosa: cualquier modificación queda como nueva fila, no overwrite

---

## 6. Continuidad operativa

- [ ] **Backup diario de Sheets**: manual (descarga `.xlsx`) o automatizado
- [ ] **Procedimiento de fallback** si Nanobot/n8n caen: el operador puede procesar manualmente las POs y registrarlas a mano en Sheets
- [ ] **Procedimiento si Anthropic API no responde**: el operador procesa manualmente, marca con flag `procesamiento_manual: true`
- [ ] **Procedimiento si Google Sheets API rate limit excedido**: pausar 60s y retry. Si persiste, log local y reintentar al desbloquear
- [ ] **Documentación de arranque**: el operador puede arrancar todo el sistema (n8n + Nanobot + Streamlit) con doble clic en `start_verbex.bat` (II6)

---

## 7. Acceso y autorización

- [ ] **Lista de chat_ids autorizados** (`TELEGRAM_ALLOWED_CHAT_IDS`) revisada trimestralmente
- [ ] Solo personal autorizado de los 5 clientes (Stratos, Kairos x2, Helion, Vectair) en la lista
- [ ] Cliente nuevo → flag `cliente_no_registrado: true`, **no se procesa pedido** sin alta previa (D3 default)
- [ ] Operador VERBEX recibe alertas en `TELEGRAM_CHAT_ID_PRODUCCION`
- [ ] Responsable de calidad recibe alertas en `TELEGRAM_CHAT_ID_CALIDAD`
- [ ] Acceso al Google Sheet limitado a personal de back-office VERBEX

---

## 8. Validación operativa periódica

- [ ] **Smoke test semanal**: enviar PO de prueba al bot, verificar que llega a Sheets y email correctamente
- [ ] **Auditoría mensual**: revisar Sheets `Errores`, identificar patrones, ajustar SOUL/SKILL si hay PNs nuevos repetidos
- [ ] **Revisión de alertas R03**: ¿cuántas POs llegan con confianza < 0.80? Si es > 10%, mejorar few-shot del SKILL
- [ ] **Revisión de R09**: ¿cuántos duplicados se detectan? Patrón puede revelar problemas de comunicación con clientes

---

## 9. Mejoras candidatas (post-MVP)

- [ ] Cache LLM para POs textualmente idénticas (~30% menos tokens)
- [ ] Validación de fecha plausible (R10): rechazar fechas en pasado o > 2 años en futuro
- [ ] Detección semántica de Amendment con regex previo al LLM (~50% menos tokens)
- [ ] Integración real con HelionLink (no simulación por copy-paste)
- [ ] Webhook desde portal Kairos en lugar de email manual
- [ ] Dashboard métricas de rendimiento del agente (precisión por cliente, latencia, etc.)

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Checklist gobernanza II5*
