# Skill — Normalización de Purchase Orders VERBEX

El procedimiento completo está definido en `SOUL.md`.

Ver también:
- Schema JSON estricto: `../../II3-LLM_Semantico/prompts/SKILL_verbex.md` § "Schema JSON estricto"
- Tabla de catálogo VERBEX: `../../data/catalogo.csv`
- Tabla de equivalencias PN: `../../data/equivalencias_pn.csv`
- Tabla de clientes: `../../data/clientes.csv`

> En II3 el system prompt embebía catálogo + equivalencias + 5 ejemplos directamente. En el agente Nanobot esos datos viven en SOUL.md (procedural) o, si el modelo necesita verlos como datos, los puede leer del filesystem mediante el tool `read_file`.
