# Heartbeat Tasks

<!-- Tareas periódicas que el agente debe revisar/ejecutar.        -->
<!-- Una tarea por línea. Vacío por defecto en VERBEX.             -->
<!-- Ejemplo: "- Cada hora, comprobar que el SMTP responde."       -->
