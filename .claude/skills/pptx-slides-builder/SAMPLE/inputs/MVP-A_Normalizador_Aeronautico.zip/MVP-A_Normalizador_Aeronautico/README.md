# MVP-A · Normalizador de Pedidos B2B Aeronáutico — VERBEX COMPOSITES S.L.

**Curso:** Automatización de Procesos con Agentes Inteligentes · COIIAOC · Parte 2
**Caso ancla:** VERBEX COMPOSITES S.L. (empresa ficticia · Tier 2 composites · Sevilla)
**Patrón técnico:** texto libre → LLM + catálogo + reglas deterministas → JSON validado → Sheets + notificación

> Todos los nombres de empresa, programa y plataforma EDI son **ficticios** (VERBEX, Kairos, Stratos, Helion, HelionLink, HX-7, ST-900, RT-55, VX-4). La lógica de negocio y la terminología técnica (AOG, CoC, EASA Form 1, AS9100, PO, PN, FAL, EDI, HTP) son auténticas del sector aeronáutico andaluz. Tabla de correspondencia con términos reales en `CONTENT/PARTE2-Materiales/plan_desarrollo_mvp_A-aero.md` § A.

---

## ¿Qué es esto?

Proyecto vertebrador de la Parte 2 del curso. Un agente que:

1. Recibe Purchase Orders por **Telegram** (texto extraído de email/PDF/HelionLink CSV/portal web).
2. Identifica al cliente por `chat_id` y valida su alta.
3. Normaliza PN cliente → PN proveedor mediante el LLM (sólo extracción y mapeo, **nunca** cálculo).
4. Aplica reglas de negocio R01–R09 deterministas en n8n: AOG, urgencia por fecha, validación de catálogo, certificaciones (CoC, EASA Form 1).
5. Enruta según prioridad: **AOG** → Telegram inmediato a producción · **CoC/Form1** → alerta a calidad · **Normal** → sólo Sheets.
6. Registra en Google Sheets (Pedidos / Lineas / Errores / Clientes) y envía email confirmación HTML.

---

## Estructura del proyecto

```
MVP-A_Normalizador_Aeronautico/
├── README.md                       # este fichero
├── SETUP.md                        # instalación paso a paso
├── PLAN.md                         # plan operativo de desarrollo (fases F0–F7)
├── PROGRESS.md                     # estado vivo del desarrollo
├── .env.example                    # plantilla de variables de entorno
├── .gitignore
│
├── data/                           # datos del dominio
│   ├── catalogo.csv                # 16 referencias VBX-COMP
│   ├── clientes.csv                # 5 clientes Tier 1 / OEM
│   └── equivalencias_pn.csv        # mapping PN cliente ↔ PN proveedor
│
├── II1-Ingesta_Canal/              # Sesión II1 — Telegram → JSON normalizado (sin LLM)
├── II2-Logica_Determinista/        # Sesión II2 — reglas R01–R09 con datos simulados
├── II3-LLM_Semantico/              # Sesión II3 — Claude API + SOUL/SKILL + parser
├── II4-Routing_Notificacion/       # Sesión II4 — Sheets + Telegram + email
├── II5-Resiliencia_Alternativas/   # Sesión II5 — sub-workflows + Nanobot (Python)
└── II6-MVP_Completo/               # Sesión II6 — dashboard Streamlit + deploy Windows
```

Cada `IIn-*/` contiene `workflow_IIn.json` importable en n8n + `README_IIn.md` con instrucciones de la sesión.

---

## Trazabilidad II1–II6

Cada sesión del curso entrega un workflow incrementalmente más completo:

| Sesión | Idea fuerza | Entrega de código |
|---|---|---|
| **II1** | El agente busca datos él solo | Telegram → JSON normalizado (sin LLM) |
| **II2** | Los KPIs no los calcula el LLM (E5) | + Reglas R01–R09 deterministas |
| **II3** | El LLM recibe hechos verificables | + Claude API + parser anti-alucinación |
| **II4** | El análisis sin destinatario no vale | Pipeline end-to-end (Sheets + Telegram + email) |
| **II5** | Workflow ≠ sistema operable | + Sub-workflows + Error Trigger + alternativa Nanobot |
| **II6** | MVP autónomo | Dashboard + deploy Windows + brief alumno |

---

## Prerrequisitos

- **Python 3.10+** (para Streamlit dashboard y Nanobot alternativo)
- **Node.js 18+** (para n8n self-hosted)
- **Cuenta Anthropic** con créditos (`ANTHROPIC_API_KEY`)
- **Bot Telegram** creado vía @BotFather (token + dos `chat_id`: producción y calidad)
- **Google Sheet** con 4 hojas (Pedidos, Lineas, Errores, Clientes) + Service Account JSON
- **SMTP genérico** para email confirmación (host, puerto, user, pass)

Detalle paso a paso en [`SETUP.md`](SETUP.md).

---

## Cómo arrancar

```powershell
# 1. Clonar y entrar en el directorio
cd CONTENT\MVP-A_Normalizador_Aeronautico

# 2. Copiar plantilla de credenciales y rellenar
copy .env.example .env
# Editar .env con tus claves reales

# 3. Para correr una sesión concreta (ejemplo II1)
#    Importar II1-Ingesta_Canal\workflow_II1.json en n8n local
#    Lanzar uno de los payloads de II1-Ingesta_Canal\payloads\
#    Verificar el JSON output

# 4. Para correr el MVP completo (al cerrar F6)
deploy\start_verbex.bat
```

---

## Cómo se desarrolla este proyecto

- **Plan operativo:** [`PLAN.md`](PLAN.md) — fases F0–F7 con artefactos numerados, dependencias y gates.
- **Estado vivo:** [`PROGRESS.md`](PROGRESS.md) — tablero de los 44 artefactos + validación de 14 criterios.
- **Spec funcional madre:** [`../PARTE2-Materiales/plan_desarrollo_mvp_A-aero.md`](../PARTE2-Materiales/plan_desarrollo_mvp_A-aero.md)
- **Contexto del caso VERBEX:** [`../PARTE2-Materiales/ESCENARIO-AERO/7-contexto_MVP_VERBEX.md`](../PARTE2-Materiales/ESCENARIO-AERO/7-contexto_MVP_VERBEX.md)
- **Origen del 90% del código:** [`../_AGENT-EOI_Normalizador_Pedidos/`](../_AGENT-EOI_Normalizador_Pedidos/) (Manuel cárnicos → VERBEX composites)

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX*
