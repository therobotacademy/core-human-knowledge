# II4 — Routing y Notificación (pipeline end-to-end)

**Sesión:** Parte 2 · Módulo II4
**Idea fuerza del módulo:** *"El análisis que nadie recibe no tiene valor."*
**PRDA:** Actuar
**Tiempo en clase:** 2,5 h

---

## ¿Qué se construye?

Un workflow n8n con **26 nodos** que extiende II3 con la **capa de salida**: lookup real anti-spam contra Sheets, registro en hojas Pedidos/Lineas, routing por prioridad a dos canales Telegram distintos, alerta a calidad si la PO requiere certificación, y email HTML al cliente.

Es el **primer pipeline end-to-end del proyecto**: una PO en texto libre entra, sale notificada y registrada sin intervención humana.

```
[II3 chain] → R09 lookup Sheets → Evaluar duplicado → IF
                                                       ├─ true  → Telegram operador (duplicado)
                                                       └─ false → fan-out:
                                                                   ├─ Sheets Pedidos + Split + Sheets Lineas
                                                                   ├─ Switch prioridad → Telegram producción
                                                                   ├─ Filter cert → Telegram calidad
                                                                   └─ Render email → SMTP
```

---

## Anatomía del workflow (26 nodos)

### Cabecera (heredada de II3, 11 nodos)

Mismo pipeline que II3: Manual Trigger → Set texto → Construir body → Claude API → Validar JSON LLM → R04+R08 → R07 → R01+R02 → R05+R06 → R03.

> El system prompt está condensado vs II3 para reducir tamaño del workflow JSON. Si el alumno quiere los 5 ejemplos few-shot completos, los tiene en `prompts/SKILL_verbex.md` o en `workflow_II3.json`.

### R09 con lookup real (sustituye stub de II3)

| # | Nodo | Función |
|---|---|---|
| 11 | Sheets · Buscar PO existente | Lookup en hoja `Pedidos` filtrando por `numero_pedido` AND `estado_normalizacion=COMPLETO` |
| 12 | R09 · Evaluar duplicado | Si hay matches → `po.duplicado: true` + alerta. Si no → `po.duplicado: false` |

### Decisión IF

| # | Nodo | Función |
|---|---|---|
| 13 | ¿Es duplicado? | Bifurca: `true` → Telegram operador y para. `false` → fan-out a 4 ramas paralelas |
| 14 | Telegram · Operador (duplicado) | Notifica a producción que se ha intentado reprocesar la PO. **No** continúa el pipeline |

### Rama duplicado=false (fan-out paralelo, 4 caminos)

#### Camino 1: Registro en Sheets

| # | Nodo | Función |
|---|---|---|
| 15 | Preparar fila Pedidos | Aplana el PO en row con 15 columnas (ver `sheets-schema.md`) |
| 16 | Sheets · Append Pedidos | INSERT 1 fila en hoja `Pedidos` |
| 17 | Split · lineas[] | Expande array en N items, uno por línea |
| 18 | Preparar fila Linea | Por cada línea, prepara row con 14 columnas |
| 19 | Sheets · Append Lineas | INSERT N filas en hoja `Lineas` |

#### Camino 2: Switch por prioridad

| # | Nodo | Función |
|---|---|---|
| 20 | Switch · Routing por prioridad | 3 outputs: `AOG` / `PRIORITARIO` / `NORMAL` |
| 21 | Telegram · Producción AOG | 🚨 Mensaje urgente al jefe de producción |
| 22 | Telegram · Producción PRIORITARIO | ⚠ Mensaje normal al jefe de producción |

> El output 2 del Switch (caso `NORMAL`) **no** tiene nodo conectado — las POs normales solo van a Sheets, sin notificación push.

#### Camino 3: Certificaciones

| # | Nodo | Función |
|---|---|---|
| 23 | Filter · ¿Requiere certificación? | `lineas.some(l => l.requiere_coc \|\| l.requiere_easa_form1)` |
| 24 | Telegram · Calidad | 📋 Lista de líneas con doc_requerida al canal de calidad |

#### Camino 4: Email cliente

| # | Nodo | Función |
|---|---|---|
| 25 | Render email HTML | Genera HTML branded VERBEX inline (versión simplificada de `templates/email_confirmacion.html`) |
| 26 | Email · Enviar confirmación | SMTP a `cliente.email_contacto` con HTML |

---

## IO/RE de la sesión

| | |
|---|---|
| **Inputs** | Texto de PO · Anthropic API · Google Sheets API (Service Account) · SMTP · Telegram Bot |
| **Outputs** | Filas en Sheets `Pedidos`/`Lineas` · 0–2 mensajes Telegram (producción + calidad) · 1 email al cliente |
| **Reglas** | AOG → email + Telegram producción inmediato · CoC/Form1 → notificar a calidad · R09 evita duplicados · log siempre · descuentos visibles |
| **Excepciones** | Sheets API límite → retry · email rebota → error en n8n UI · Telegram fail → error en n8n UI · LLM timeout → `onError: continueErrorOutput` |

> **Nota sobre rama de error:** spec § 6.II4.a menciona "rama de error → Sheets `Errores` + Telegram al operador". En II4 simplificamos: cada nodo crítico tiene `onError: continueErrorOutput` pero no enrutamos a un Error Trigger global. **Esto entra en II5** con el refactor a sub-workflows.

---

## Prerrequisitos

1. **Anthropic API** (de II3): credencial `CREDENTIAL_ANTHROPIC`.
2. **Google Sheets** preparado: 4 hojas con cabeceras según [`sheets-schema.md`](sheets-schema.md).
3. **Service Account** con permiso Editor sobre el Sheet (ver `SETUP.md` § 5).
4. **SMTP** configurado (genérico — ver `SETUP.md` § 6 · default D1).
5. **Telegram Bot** con dos `chat_id` configurados:
   - `TELEGRAM_CHAT_ID_PRODUCCION` para AOG y PRIORITARIO
   - `TELEGRAM_CHAT_ID_CALIDAD` para CoC / EASA Form 1
6. **Variables de entorno** en n8n: `GOOGLE_SHEETS_ID`, `TELEGRAM_CHAT_ID_PRODUCCION`, `TELEGRAM_CHAT_ID_CALIDAD`, `SMTP_FROM`.

---

## Cómo correr esta sesión

### 1. Preparar el Google Sheet

Crear Sheet `VERBEX-Pedidos` con 4 hojas (`Pedidos`, `Lineas`, `Errores`, `Clientes`) y pegar las cabeceras de [`sheets-schema.md`](sheets-schema.md). Compartir con el email del Service Account.

Copiar el ID del Sheet a `.env` como `GOOGLE_SHEETS_ID`.

### 2. Importar el workflow

n8n: **Workflows** → **Import from File** → `workflow_II4.json`.

### 3. Asignar 4 credenciales

| Nodo afectado | Credencial |
|---|---|
| `Cognitivo · Llamada Claude API` | HTTP Header Auth con `x-api-key: $ANTHROPIC_API_KEY` |
| `R09 · Buscar PO existente`, `Sheets · Append Pedidos`, `Sheets · Append Lineas` | Google Sheets Service Account (subir JSON descargado) |
| Los 4 nodos `Telegram · ...` | Telegram Bot API con token de @BotFather |
| `Email · Enviar confirmación` | SMTP (host, port, user, pass) |

### 4. Configurar variables de entorno

n8n **Settings** → **Environment Variables**:

```
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_SHEETS_ID=...
TELEGRAM_CHAT_ID_PRODUCCION=...
TELEGRAM_CHAT_ID_CALIDAD=...
SMTP_FROM=pedidos@verbex.example
```

### 5. Probar el caso por defecto (PO Stratos estándar)

Click **Execute Workflow**. Resultado esperado:

- ✅ Fila en hoja `Pedidos` con `numero_pedido: PO-2025-STRA-0847`, estado `COMPLETO`, prioridad `NORMAL`.
- ✅ 1 fila en hoja `Lineas` con la línea ST9-HTP-RIB-047 → VBX-COMP-4471-B.
- ❌ NO se envía Telegram a producción (prioridad NORMAL).
- ✅ Telegram a calidad (CoC requerido).
- ✅ Email al cliente Stratos en `pedidos@stratos-systems.es`.

### 6. Probar otros casos

Edita el Set "Texto de prueba" con:

| Texto de PO | Resultado esperado |
|---|---|
| AOG urgente HX-7 (E3 SKILL) | Telegram producción AOG · Telegram calidad · email a destinatario fallback (sin cliente identificado) |
| HelionLink Kairos (E2 SKILL) | Telegram calidad (CoC + EASA Form 1) · email a `supply@kairos-aerospace.com` |
| Mismo PO repetido | Detección R09 → Telegram operador "duplicado" · pipeline para |

---

## Gate F4 (criterio de cierre de la sesión)

✅ **Estructural:** workflow JSON parseable, 26 nodos, 20 conexiones, 6 terminales, 4 placeholders de credenciales (validado en Python).

✅ **Funcional (en clase con credenciales reales):**

- AOG → Telegram a `TELEGRAM_CHAT_ID_PRODUCCION` en < 5 segundos (criterio 3 spec § 8)
- CoC/Form1 → Telegram a `TELEGRAM_CHAT_ID_CALIDAD` (criterio 9)
- POs registradas en `Pedidos` y `Lineas` (criterio 7)
- R09 evita duplicados: reenviar la misma `numero_pedido` no crea fila duplicada (criterio 8)
- Email confirmación HTML llega al cliente

---

## Decisiones de diseño en II4

### A. R09 con lookup real, no cache

El stub de R09 en II2/II3 (cache hardcoded `PO-2025-STRA-9999`) se sustituye por un Google Sheets node que filtra `Pedidos` por `numero_pedido` + `estado_normalizacion=COMPLETO`. Esto hace R09 verdaderamente persistente.

**Trade-off:** introduce latencia (~500ms por lookup) y dependencia de Sheets API. Se acepta porque:
- La cardinalidad de POs activas es baja (decenas/día)
- Sheets API tiene rate limits generosos para este patrón
- Alternativas (Redis, base de datos) requieren infraestructura adicional fuera del alcance del curso

### B. Switch por prioridad, no IF anidados

Para 3 ramas (AOG / PRIORITARIO / NORMAL) el Switch es más limpio que dos IF anidados. La salida `NORMAL` queda sin conectar — las POs normales no se notifican al móvil del jefe de producción, solo se registran en Sheets. Esto **es por diseño**: respetar el tiempo del operador.

### C. Filter de certificación independiente del Switch

CoC/Form1 puede aplicar a una PO normal, prioritaria o AOG. Por eso el Filter "¿Requiere certificación?" es un camino paralelo, no anidado dentro del Switch.

### D. Email branded vs `templates/email_confirmacion.html`

El Code node "Render email HTML" embebe una versión **simplificada** del template inline. La versión completa con paleta corporativa, espaciados optimizados y semántica HTML estricta vive en `templates/email_confirmacion.html` como referencia de diseño.

> En II5 esto se podría refactorizar para que el workflow lea el template del filesystem o lo cargue desde una variable de workflow. En II4 lo dejamos inline para no añadir más dependencias.

### E. Sin Error Trigger global (queda para II5)

El spec § 6.II4 menciona "rama de error → Sheets Errores + Telegram operador". Lo movemos a II5 porque requiere Error Trigger Workflow global, que es un concepto de arquitectura modular — no de routing.

---

## Lo que NO hace este workflow (queda para II5, II6)

- ❌ Sub-workflows (master + 4 sub-workflows independientes) → II5.
- ❌ Error Trigger Workflow global → II5.
- ❌ Retry logic configurable → II5.
- ❌ Alternativa Nanobot · misma lógica en Python → II5.
- ❌ Streamlit dashboard → II6.
- ❌ Deploy Windows con Task Scheduler → II6.

II4 es el **primer pipeline end-to-end funcional** del MVP. II5 lo refactoriza para que sea operable en producción.

---

## Coste por ejecución (PO normal)

| Componente | Coste aproximado |
|---|---|
| Anthropic Claude API (~2 200 in + 300 out) | ~0.013 € |
| Google Sheets (lookup + 2 append) | gratis |
| SMTP (1 email) | gratis (cuenta personal) |
| Telegram (0–2 mensajes) | gratis |
| **Total por PO** | **~0.013 €** |

A ratio de 50 POs/día = ~0.65 €/día = ~20 €/mes.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Sesión II4*
