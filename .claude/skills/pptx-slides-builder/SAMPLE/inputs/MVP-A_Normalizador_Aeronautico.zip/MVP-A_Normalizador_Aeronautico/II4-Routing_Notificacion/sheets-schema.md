# Esquema de Google Sheets · MVP-A VERBEX

Crear un Google Sheet llamado `VERBEX-Pedidos` con **4 hojas** con exactamente estos nombres: `Pedidos`, `Lineas`, `Errores`, `Clientes`.

> Nombres exactos importan: el workflow II4 escribe contra estos nombres literales.

---

## Hoja: Pedidos

Una fila por PO procesada (cabecera del pedido).

| Columna | Tipo | Descripción |
|---|---|---|
| `timestamp` | DateTime | ISO 8601 — momento de procesamiento (UTC) |
| `numero_pedido` | String | Identificador único de la PO (clave anti-duplicado para R09) |
| `cliente_nombre` | String | Nombre extraído del texto |
| `codigo_erp` | String | Código ERP del cliente (`STRA-001`, `KAIRO-001`, etc.) |
| `tier` | String | `TIER_1` / `OEM` / `null` |
| `estado_normalizacion` | String | `COMPLETO` / `PARCIAL` / `ERROR` |
| `prioridad_calculada` | String | `AOG` / `PRIORITARIO` / `NORMAL` |
| `confianza` | Number | 0.0 – 1.0 |
| `aog` | Boolean | Detección AOG por el LLM |
| `total_lineas` | Number | Número de líneas en la PO |
| `alertas_count` | Number | Número de alertas en `alertas[]` |
| `cliente_no_registrado` | Boolean | Flag de R07 (cliente no en `clientes.csv`) |
| `duplicado` | Boolean | Flag de R09 (PO ya procesada previamente) |
| `texto_original` | String | Mensaje completo recibido (primeros 1000 chars) |
| `alertas_resumen` | String | `alertas[]` joined con ` · ` |

**Cabecera exacta (fila 1) — copiar a Sheets:**

```
timestamp	numero_pedido	cliente_nombre	codigo_erp	tier	estado_normalizacion	prioridad_calculada	confianza	aog	total_lineas	alertas_count	cliente_no_registrado	duplicado	texto_original	alertas_resumen
```

---

## Hoja: Lineas

Una fila por línea de producto. La clave para join con `Pedidos` es `numero_pedido` + `linea_id`.

| Columna | Tipo | Descripción |
|---|---|---|
| `timestamp` | DateTime | Mismo valor que en `Pedidos` (mismo procesamiento) |
| `numero_pedido` | String | FK → `Pedidos.numero_pedido` |
| `linea_id` | Number | Identificador de línea dentro de la PO |
| `part_number_cliente` | String | PN tal como lo envía el cliente |
| `part_number_proveedor` | String | PN VERBEX (`VBX-COMP-...`) o vacío si no mapeable |
| `descripcion` | String | Descripción del componente |
| `cantidad` | Number | Cantidad solicitada |
| `unidad` | String | `EA` / `KG` / `ML` / `M2` |
| `fecha_entrega_requerida` | Date | ISO `YYYY-MM-DD` o vacío |
| `programa` | String | `HX7` / `ST900` / `RT55` / `VX4` / `OTRO` |
| `prioridad` | String | Prioridad de la línea (puede diferir de la PO si sólo una línea está urgente) |
| `requiere_coc` | Boolean | Certificate of Conformance |
| `requiere_easa_form1` | Boolean | Certificado EASA Form 1 |
| `doc_requerida` | String | `[CoC]` / `[CoC, EASA Form 1]` / vacío |

**Cabecera exacta (fila 1) — copiar a Sheets:**

```
timestamp	numero_pedido	linea_id	part_number_cliente	part_number_proveedor	descripcion	cantidad	unidad	fecha_entrega_requerida	programa	prioridad	requiere_coc	requiere_easa_form1	doc_requerida
```

---

## Hoja: Errores

Una fila por error de procesamiento (escritura desde II5 con Error Trigger global; en II4 se rellena sólo manualmente o desde casos específicos).

| Columna | Tipo | Descripción |
|---|---|---|
| `timestamp` | DateTime | Momento del error |
| `numero_pedido` | String | PO que disparó el error (si disponible) |
| `tipo_error` | String | Clasificación: `LLM_API_ERROR` / `JSON_PARSE_ERROR` / `SCHEMA_ERROR` / `SHEETS_ERROR` / `SMTP_ERROR` / `TELEGRAM_ERROR` |
| `error_raw` | String | Mensaje técnico (primeros 500 chars) |
| `texto_original` | String | Mensaje del cliente que causó el error (primeros 1000 chars) |
| `nodo_origen` | String | Nombre del nodo n8n donde se disparó el error |

**Cabecera exacta (fila 1):**

```
timestamp	numero_pedido	tipo_error	error_raw	texto_original	nodo_origen
```

---

## Hoja: Clientes

Sincronización del fichero `data/clientes.csv`. Se rellena **manualmente** copiando el CSV (botón "File → Import" en Google Sheets, separador coma).

| Columna | Tipo | Descripción |
|---|---|---|
| `codigo_erp` | String | Identificador único interno VERBEX |
| `nombre` | String | Razón social |
| `tier` | String | `TIER_1` / `OEM` |
| `programa_principal` | String | Programa aeronáutico principal |
| `canal_preferente` | String | `email_pdf` / `helionlink_csv` / `portal_web` |
| `email_contacto` | String | Email para confirmaciones SMTP |

**Cabecera exacta (fila 1):**

```
codigo_erp	nombre	tier	programa_principal	canal_preferente	email_contacto
```

---

## Cómo obtener el `GOOGLE_SHEETS_ID`

La URL del Sheet tiene este formato:

```
https://docs.google.com/spreadsheets/d/[GOOGLE_SHEETS_ID]/edit#gid=0
```

El `GOOGLE_SHEETS_ID` es la cadena entre `/d/` y `/edit`. Cópialo a `.env` como `GOOGLE_SHEETS_ID`.

---

## Permisos del Service Account

El email del Service Account (formato `xxx@xxx.iam.gserviceaccount.com`) debe tener permiso de **Editor** sobre el Sheet:

1. Abrir el Sheet en Google Drive.
2. Botón **Share** → introducir el email del Service Account → permiso **Editor** → **Send**.
3. **Google Drive API** y **Google Sheets API** deben estar habilitadas en el proyecto del Service Account (ver `SETUP.md` § 5.2).

---

## Plantilla del Sheet (opción 1: importar)

Para acelerar el setup, los alumnos pueden:

1. Crear un Sheet vacío.
2. En cada hoja, pegar la fila de cabecera correspondiente (sección "Cabecera exacta" arriba).
3. Verificar que los nombres de las hojas son exactamente `Pedidos`, `Lineas`, `Errores`, `Clientes` (sin tildes ni espacios).

> Si las hojas tienen otros nombres, el workflow falla con `Sheet not found`. n8n no crea hojas automáticamente.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Schema de Google Sheets*
