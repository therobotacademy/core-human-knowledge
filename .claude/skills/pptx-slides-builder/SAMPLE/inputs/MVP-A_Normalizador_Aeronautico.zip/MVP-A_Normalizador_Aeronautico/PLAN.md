# PLAN.md — Plan de desarrollo del código · MVP-A aeronáutico VERBEX

**Branch:** `dev/mvp-a-code`
**Base:** `master @ fadc166`
**Spec madre:** `CONTENT/PARTE2-Materiales/plan_desarrollo_mvp_A-aero.md`
**Contexto del caso:** `CONTENT/PARTE2-Materiales/ESCENARIO-AERO/7-contexto_MVP_VERBEX.md`
**Reuso EOI:** `CONTENT/_AGENT-EOI_Normalizador_Pedidos/`

---

## 1 · Objetivo

Generar el árbol de código completo bajo `CONTENT/MVP-A_Normalizador_Aeronautico/` siguiendo la especificación de `plan_desarrollo_mvp_A-aero.md`. Producir entregables coherentes con la trazabilidad II1→II6 y los 14 criterios de aceptación de la spec § 8.

Este documento es **operativo**: orden de fases, dependencias entre artefactos, gates de validación. La spec es el contrato funcional; el PLAN es cómo se ejecuta.

---

## 2 · Principios de ejecución

- **Code-first.** No se produce ningún PPTX/DOCX/HTML didáctico hasta que el código esté validado.
- **Spec inmutable.** Si surge una desviación necesaria, se registra en `PROGRESS.md § Decisiones de implementación` y se cita la sección de la spec afectada — no se edita la spec sin previa decisión.
- **Independencia por sesión.** Cada `workflow_IIn.json` debe ser importable y ejecutable en n8n de forma autónoma — el alumno no debe necesitar todos los anteriores para correr uno.
- **Defaults D1–D5 aplican** salvo decisión explícita registrada.
- **Logs en español, código y JSON keys en `snake_case` español.**
- **Modelo Claude:** `claude-sonnet-4-20250514 · temperature 0.1 · max_tokens 1500` (spec § 7).
- **Sin secrets en código.** `.env.example` es el único fichero de credenciales. `config.template.json` para Nanobot. `.gitignore` blinda los reales.

---

## 3 · Fases de desarrollo

Las fases son secuenciales cuando hay dependencia, paralelas cuando no. Cada fase termina con un **gate** verificable.

### Fase 0 · Bootstrap del proyecto (~30 min)

Sin dependencias. Crea cimientos compartidos por todas las fases siguientes.

| # | Artefacto | Origen / construcción |
|---|---|---|
| 0.1 | `README.md` raíz | Nuevo · introduce VERBEX, estructura, prerequisitos, cómo correr cada IIn |
| 0.2 | `SETUP.md` | Adaptado de EOI `SETUP.md` · añade GOOGLE_SERVICE_ACCOUNT_JSON, doble chat_id Telegram |
| 0.3 | `.env.example` | Variables de spec § 7 |
| 0.4 | `.gitignore` | `.env`, `**/config.json`, `**/service-account-*.json`, `**/nanobot.log`, `**/*.log` |
| 0.5 | `data/catalogo.csv` | Spec § 4.1 (16 referencias VBX-COMP) |
| 0.6 | `data/clientes.csv` | Spec § 4.2 (5 clientes Tier 1 / OEM) |
| 0.7 | `data/equivalencias_pn.csv` | Spec § 4.3 (mapping PN cliente↔proveedor) |

**Gate F0:** los 3 CSV son válidos UTF-8 con BOM y abren en Excel sin errores. `.env.example` cubre todas las variables de spec § 7.

---

### Fase 1 · II1 Ingesta y Conectividad (~45 min)

Depende de F0.

| # | Artefacto | Origen / construcción |
|---|---|---|
| 1.1 | `II1-Ingesta_Canal/workflow_II1.json` | Adaptado de `_AGENT-EOI/modulo-5-n8n/workflow.json` nodos `node-telegram-trigger` + `node-filter-auth` + `node-preprocess`. Delta spec § 6.II1.c |
| 1.2 | `II1-Ingesta_Canal/payloads/payload_01_po_estandar.txt` | Spec § 6.II1.e |
| 1.3 | `II1-Ingesta_Canal/payloads/payload_02_helionlink_csv.txt` | Spec § 6.II1.e |
| 1.4 | `II1-Ingesta_Canal/payloads/payload_03_aog_alert.txt` | Spec § 6.II1.e |
| 1.5 | `II1-Ingesta_Canal/payloads/payload_04_amendment.txt` | Spec § 6.II1.e |
| 1.6 | `II1-Ingesta_Canal/README_II1.md` | Qué se construye, prerrequisitos, IO/RE, paso a paso |

**Gate F1:** workflow importable en n8n local. Procesa los 4 payloads y devuelve JSON con `{texto_limpio, chat_id, codigo_erp_detectado, canal_detectado, ...}` sin LLM.

---

### Fase 2 · II2 Lógica Determinista (~60 min)

Depende de F0 + F1 (extiende workflow_II1).

| # | Artefacto | Origen / construcción |
|---|---|---|
| 2.1 | `II2-Logica_Determinista/datos_simulados/po_test_set.json` | 8 POs cubriendo: estándar · AOG · Amendment · PN desconocido · cliente nuevo · fecha urgente · cantidad inválida · PO ya procesada |
| 2.2 | `II2-Logica_Determinista/workflow_II2.json` | Extiende workflow_II1 + nodos R01–R09 deterministas (spec § 6.II2.a) |
| 2.3 | `II2-Logica_Determinista/README_II2.md` | Doc reglas + cómo ejecutar con `po_test_set.json` |

**Gate F2:** workflow importable y procesa las 8 POs simuladas. Cada una produce el `estado_normalizacion`, `prioridad_calculada`, `doc_requerida` y `alertas[]` esperados según spec § 4.5. **Sin llamar al LLM.** Esto valida E5.

---

### Fase 3 · II3 LLM Semántico (~75 min)

Depende de F0 + F2.

| # | Artefacto | Origen / construcción |
|---|---|---|
| 3.1 | `II3-LLM_Semantico/prompts/SOUL_verbex.md` | Adaptado de `_AGENT-EOI/modulo-2/SOUL.md` + spec § 7 contexto VERBEX |
| 3.2 | `II3-LLM_Semantico/prompts/SKILL_verbex.md` | 5 ejemplos few-shot completos según contexto VERBEX § 7 (PO estándar · HelionLink CSV · AOG · Amendment · PN desconocido) |
| 3.3 | `II3-LLM_Semantico/workflow_II3.json` | Reemplaza inyección simulada de F2 por HTTP Request a Anthropic + parser anti-alucinación |
| 3.4 | `II3-LLM_Semantico/README_II3.md` | Doc del prompt engineering + cómo correr con `ANTHROPIC_API_KEY` |

**Gate F3:** los 5 ejemplos del SKILL producen el JSON esperado sin modificación manual del prompt (criterio 14 spec § 8). Confianza ≥ 0.95 en HelionLink CSV (criterio 2). AOG detectado correctamente con `aog: true` (criterio 3).

---

### Fase 4 · II4 Routing y Notificación (~75 min)

Depende de F3.

| # | Artefacto | Origen / construcción |
|---|---|---|
| 4.1 | `II4-Routing_Notificacion/sheets-schema.md` | 4 hojas: Pedidos / Lineas / Errores / Clientes |
| 4.2 | `II4-Routing_Notificacion/templates/email_confirmacion.html` | Plantilla HTML branded VERBEX |
| 4.3 | `II4-Routing_Notificacion/workflow_II4.json` | Extiende workflow_II3 + Switch routing por prioridad + Sheets append + SMTP email |
| 4.4 | `II4-Routing_Notificacion/README_II4.md` | Doc canales + setup Sheets + setup SMTP |

**Gate F4:** AOG → Telegram a `TELEGRAM_CHAT_ID_PRODUCCION` en < 5 s. CoC/Form1 → Telegram a `TELEGRAM_CHAT_ID_CALIDAD`. Sheets `Pedidos` y `Lineas` se rellenan correctamente. R09 evita duplicados (criterios 3, 7, 8, 9 spec § 8).

---

### Fase 5 · II5 Resiliencia y Alternativas (~90 min)

Depende de F4.

| # | Artefacto | Origen / construcción |
|---|---|---|
| 5.1 | `II5-Resiliencia_Alternativas/workflow_II5_refactor.json` | Refactor de F4 en master + 4 sub-workflows + Error Trigger global |
| 5.2 | `II5-Resiliencia_Alternativas/nanobot/config.template.json` | Adaptado de EOI con dos `chat_id` (producción + calidad) |
| 5.3 | `II5-Resiliencia_Alternativas/nanobot/workspace/SOUL.md` | Adaptado de EOI workspace SOUL al dominio VERBEX |
| 5.4 | `II5-Resiliencia_Alternativas/nanobot/workspace/SKILL.md` | Adaptado de EOI workspace SKILL |
| 5.5 | `II5-Resiliencia_Alternativas/nanobot/workspace/AGENTS.md` | Idéntico a EOI |
| 5.6 | `II5-Resiliencia_Alternativas/nanobot/workspace/TOOLS.md` | Idéntico a EOI |
| 5.7 | `II5-Resiliencia_Alternativas/nanobot/workspace/HEARTBEAT.md` | Vacío con placeholder |
| 5.8 | `II5-Resiliencia_Alternativas/nanobot/nanobot_verbex.py` | Script Python independiente que reproduce flujo II3 sin n8n |
| 5.9 | `II5-Resiliencia_Alternativas/nanobot/requirements_nanobot.txt` | nanobot-ai, anthropic, python-dotenv |
| 5.10 | `II5-Resiliencia_Alternativas/gobernanza-checklist.md` | Spec § 6.II5.a punto 3 |
| 5.11 | `II5-Resiliencia_Alternativas/README_II5.md` | Doc de las dos arquitecturas + cuándo usar cada una |

**Gate F5:** master + 4 sub-workflows reproducen el output de F4 monolítico (criterio 10 spec § 8 adaptado). Error Trigger captura un fallo simulado y lo enruta a Sheets `Errores` (criterio 11). Nanobot reproduce el flujo II3 produciendo el mismo JSON (criterio 13).

---

### Fase 6 · II6 MVP Completo (~60 min)

Depende de F5.

| # | Artefacto | Origen / construcción |
|---|---|---|
| 6.1 | `II6-MVP_Completo/workflow_II6_mvp.json` | Idéntico a F5 si todos los gates pasan, o con ajustes finales |
| 6.2 | `II6-MVP_Completo/dashboard/app.py` | Adaptado de `_AGENT-EOI/modulo-1/solucion/app.py` con gspread en lugar de pandas-csv |
| 6.3 | `II6-MVP_Completo/dashboard/requirements.txt` | streamlit, gspread, pandas, python-dotenv |
| 6.4 | `II6-MVP_Completo/deploy/start_verbex.bat` | 3 procesos: n8n, Nanobot opcional, Streamlit |
| 6.5 | `II6-MVP_Completo/deploy/task-scheduler.md` | Adaptado de `_AGENT-EOI/modulo-6/task-scheduler.md` |
| 6.6 | `II6-MVP_Completo/deploy/README_deploy.md` | Operación diaria + troubleshooting |
| 6.7 | `II6-MVP_Completo/proyecto-alumno/README.md` | Brief del proyecto del alumno (adaptar MVP a otro dominio aeronáutico) |
| 6.8 | `II6-MVP_Completo/proyecto-alumno/checklist.md` | Criterios de evaluación del proyecto |
| 6.9 | `II6-MVP_Completo/README_II6.md` | Doc integración + cómo arrancar el MVP completo |

**Gate F6:** dashboard muestra las últimas 50 POs con filtro por programa y estado (criterio 10). `start_verbex.bat` arranca los 3 procesos con doble clic (criterio 12).

---

### Fase 7 · Validación final contra criterios spec § 8 (~30 min)

Depende de F0–F6.

Pasar los 14 checks de la spec § 8 uno por uno. Marcar en `PROGRESS.md § Validación` con resultado, payload usado y notas.

**Gate F7:** 14/14 criterios verde. Si alguno no pasa → registrar en `PROGRESS.md § Bloqueos` y proponer remediación antes de cerrar la fase.

---

## 4 · Mapa de dependencias entre artefactos

```
F0 (data + env)
 ├─→ F1 (workflow_II1 usa clientes.csv para chat_id mapping)
 │    └─→ F2 (workflow_II2 extiende workflow_II1 + usa catalogo + equivalencias)
 │         └─→ F3 (workflow_II3 reemplaza simulación por LLM real, mismo schema)
 │              └─→ F4 (workflow_II4 + sheets-schema + email)
 │                   └─→ F5 (refactor n8n + nanobot Python alternativo)
 │                        └─→ F6 (dashboard lee Sheets de F4 + deploy)
 │                             └─→ F7 (validación 14 criterios)
 └─→ F0 también alimenta directamente F2, F3, F5, F6 vía catalogo/clientes/equivalencias

Ruta crítica: F0 → F1 → F2 → F3 → F4 → F5 → F6 → F7 (~7 horas estimadas)
```

---

## 5 · Convenciones operativas (esta fase)

- **Naming workflows:** `workflow_IIn[_descripcion].json`. Spec § 7.
- **Naming nodos n8n:** `[Capa] · [Acción concreta]` — `Ingesta · Filtro chat_id` · `Semántico · Validar JSON LLM`. Spec § 7.
- **Credenciales en JSON workflows:** placeholders `CREDENTIAL_TELEGRAM`, `CREDENTIAL_ANTHROPIC`, `CREDENTIAL_SHEETS`, `CREDENTIAL_SMTP`.
- **Comentarios:** mínimos. Sólo "por qué" no obvio.
- **Commits granulares por fase.** Mensaje pattern: `feat(IIn): <breve>` o `feat(bootstrap): ...`. Co-author Claude Opus.
- **Validación al cierre de cada fase.** Sin gate verde no se pasa a la siguiente.
- **PROGRESS.md se actualiza al inicio y al fin de cada artefacto.** Estado: ⬜ → 🔄 → ✅ (o ⛔ si bloqueado).

---

## 6 · Defaults aplicables (spec § 10)

| ID | Default aplicado |
|---|---|
| D1 | SMTP genérico (no Gmail OAuth) |
| D2 | Streamlit dashboard read-only |
| D3 | Cliente desconocido → auto-flag `cliente_no_registrado: true`, no rechaza |
| D4 | Catálogo: lectura del CSV en cada ejecución |
| D5 | Nanobot alternativo: complementario, no evaluable |

Si Bernardo confirma alguno con ajuste durante el desarrollo, se registra en `PROGRESS.md § Decisiones de implementación` y se sobreescribe el default.

---

## 7 · Cómo trabajar con `PROGRESS.md`

- Estado vivo, no histórico fosilizado: actualizar **a medida** que se trabaja.
- 3 estados: ⬜ pendiente · 🔄 en curso · ✅ hecho · ⛔ bloqueado.
- Cada artefacto tiene una línea con: estado · ruta · timestamp último cambio · nota corta si aplica.
- Decisiones puntuales (deltas vs spec, defaults sobreescritos) van a `§ Decisiones de implementación`.
- Bloqueos a `§ Bloqueos / pendientes` con causa y propuesta.
- Resultados de validación final a `§ Validación criterios spec § 8`.

---

## 8 · Salida esperada al cerrar el desarrollo

- Árbol completo en `CONTENT/MVP-A_Normalizador_Aeronautico/` con todos los artefactos de § 3.
- `PROGRESS.md` con 14/14 criterios spec § 8 en verde.
- Workflow II1 importable en n8n y validado con un payload real (al menos uno de los 4 de F1).
- Branch `dev/mvp-a-code` lista para PR a `master` con título `feat(MVP-A): código del proyecto vertebrador VERBEX`.

---

*COIIAOC · Parte 2 · MVP-A aeronáutico VERBEX · Plan operativo de desarrollo*
*Generado: 2026-05-08 · branch `dev/mvp-a-code`*
